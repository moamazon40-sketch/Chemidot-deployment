# Total Users Count API Usage

This documentation explains how to retrieve the total users count from the API using the provided utilities.

## Available Methods

### 1. usersService.getTotalUsersCount()

Returns detailed user count information including total users, admins, and project owners.

```javascript
import { usersService } from '@/services/api/usersService';

// Get full user count details
const result = await usersService.getTotalUsersCount();

// Result structure:
{
  success: boolean,
  totalCount: number,        // Total users count
  totalAdmins: number,       // Number of admin users
  totalProjectOwners: number, // Number of project owners
  error?: string             // Error message if failed
}
```

### 2. usersService.getTotalUsersCountOnly()

Returns just the total users count as a number.

```javascript
// Get just the total count number
const totalCount = await usersService.getTotalUsersCountOnly();
console.log(totalCount); // e.g., 1250
```

## React Hook: useTotalUsersCount()

For React components, use the provided hook for easy state management:

```jsx
import { useTotalUsersCount } from '@/hooks/use-total-users-count';

function MyComponent() {
  const {
    totalUsersCount,
    totalAdmins,
    totalProjectOwners,
    loading,
    error,
    refetch
  } = useTotalUsersCount();

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div>
      <p>Total Users: {totalUsersCount}</p>
      <p>Admins: {totalAdmins}</p>
      <p>Project Owners: {totalProjectOwners}</p>
      <button onClick={refetch}>Refresh</button>
    </div>
  );
}
```

## Pre-built Components

### 1. TotalUsersDisplay

A complete display component with cards showing all user counts:

```jsx
import { TotalUsersDisplay } from '@/components/users/total-users-display';

function Dashboard() {
  return (
    <div>
      <h1>Dashboard</h1>
      <TotalUsersDisplay />
    </div>
  );
}
```

### 2. UsersStatsCard

A compact card for dashboard statistics:

```jsx
import { UsersStatsCard } from '@/components/dashboard/users-stats-card';

function Dashboard() {
  return (
    <div className="grid gap-4 md:grid-cols-4">
      <UsersStatsCard />
      {/* Other stat cards */}
    </div>
  );
}
```

## API Response Structure

The API endpoint `GetAllAdminAndProjectOwners` returns the following relevant fields:

```json
{
  "success": true,
  "Users": [...],
  "AllUsersCount": 1250,     // or "TotalUsersCount"
  "TotalAdmins": 15,
  "TotalProjectOwners": 85
}
```

## Error Handling

All methods include proper error handling:

- Network errors are caught and logged
- Failed requests return default values (0 for counts)
- Error messages are provided in the response
- The React hook includes error state for UI feedback

## Performance Notes

- The `getTotalUsersCount()` method uses minimal page size (1) to efficiently get just the count
- Results are not cached by default to ensure fresh data
- For frequent updates, consider implementing your own caching strategy

## Usage Examples

### In a Dashboard Component

```jsx
import { useTotalUsersCount } from '@/hooks/use-total-users-count';

export function AdminDashboard() {
  const { totalUsersCount, loading } = useTotalUsersCount();

  return (
    <div>
      <h1>Admin Dashboard</h1>
      <div className="stats">
        <div className="stat-card">
          <h3>Total Users</h3>
          <p>{loading ? 'Loading...' : totalUsersCount.toLocaleString()}</p>
        </div>
      </div>
    </div>
  );
}
```

### Manual API Call

```javascript
// In an async function
async function updateUserStats() {
  try {
    const userStats = await usersService.getTotalUsersCount();
    if (userStats.success) {
      console.log('Total users:', userStats.totalCount);
      console.log('Admins:', userStats.totalAdmins);
      console.log('Project owners:', userStats.totalProjectOwners);
    } else {
      console.error('Failed to fetch user stats:', userStats.error);
    }
  } catch (error) {
    console.error('Error:', error);
  }
}
```