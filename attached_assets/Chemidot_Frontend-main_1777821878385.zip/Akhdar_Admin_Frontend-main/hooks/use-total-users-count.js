import { useState, useEffect } from 'react';
import { usersService } from '@/services/api/usersService';

export function useTotalUsersCount() {
  const [totalUsersCount, setTotalUsersCount] = useState(0);
  const [totalAdmins, setTotalAdmins] = useState(0);
  const [totalProjectOwners, setTotalProjectOwners] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchTotalUsersCount = async () => {
    try {
      setLoading(true);
      setError(null);

      const result = await usersService.getTotalUsersCount();

      if (result.success) {
        setTotalUsersCount(result.totalCount);
        setTotalAdmins(result.totalAdmins || 0);
        setTotalProjectOwners(result.totalProjectOwners || 0);
      } else {
        setError(result.error || 'Failed to fetch total users count');
      }
    } catch (err) {
      console.error('Error in useTotalUsersCount:', err);
      setError(err.message || 'Failed to fetch total users count');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTotalUsersCount();
  }, []);

  return {
    totalUsersCount,
    totalAdmins,
    totalProjectOwners,
    loading,
    error,
    refetch: fetchTotalUsersCount
  };
}