const fs = require('fs');
const path = require('path');

// S3 Post-build script to create catch-all routing for dynamic routes
console.log('Creating S3-compatible routing files...');

const outDir = path.join(__dirname, '..', 'out');

// Copy fallback pages to handle any dynamic route
const copyFallbackPage = (sourcePath, targetPattern) => {
  const sourceFile = path.join(outDir, sourcePath);

  if (fs.existsSync(sourceFile)) {
    const content = fs.readFileSync(sourceFile, 'utf8');

    // Create the target directory if it doesn't exist
    const targetDir = path.dirname(path.join(outDir, targetPattern));
    if (!fs.existsSync(targetDir)) {
      fs.mkdirSync(targetDir, { recursive: true });
    }

    // Write the fallback file
    fs.writeFileSync(path.join(outDir, targetPattern), content);
    console.log(`Created: ${targetPattern}`);
  } else {
    console.warn(`Source file not found: ${sourcePath}`);
  }
};

// Create routing instruction file for S3
const s3Instructions = `# S3 Static Website Configuration

## Option 1: S3 Routing Rules (Recommended)
Add these routing rules to your S3 bucket's static website hosting configuration:

\`\`\`json
[
  {
    "Condition": {
      "KeyPrefixEquals": "admin/projects/",
      "HttpErrorCodeReturnedEquals": "404"
    },
    "Redirect": {
      "ReplaceKeyWith": "admin/projects/fallback/index.html"
    }
  },
  {
    "Condition": {
      "KeyPrefixEquals": "owner/projects/",
      "HttpErrorCodeReturnedEquals": "404"
    },
    "Redirect": {
      "ReplaceKeyWith": "owner/projects/fallback/index.html"
    }
  }
]
\`\`\`

## Option 2: CloudFront Distribution (Better)
Use CloudFront in front of S3 with these behaviors:
- Path pattern: /admin/projects/* → Origin: S3, Error pages: 404 → /admin/projects/fallback/index.html
- Path pattern: /owner/projects/* → Origin: S3, Error pages: 404 → /owner/projects/fallback/index.html

## Option 3: Use Query Parameters (Simplest)
Change your links to use:
- /admin/projects/?id=PROJECT_ID instead of /admin/projects/PROJECT_ID
- /owner/projects/?id=PROJECT_ID instead of /owner/projects/PROJECT_ID

The components will automatically read the ID from the URL parameters.
`;

fs.writeFileSync(path.join(outDir, 'S3_ROUTING_SETUP.md'), s3Instructions);
console.log('Created: S3_ROUTING_SETUP.md');

console.log('✅ S3 post-build setup complete!');