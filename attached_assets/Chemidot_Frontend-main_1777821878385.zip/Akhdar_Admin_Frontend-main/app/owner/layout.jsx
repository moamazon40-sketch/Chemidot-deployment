import RequireAuth from "@/components/auth/RequireAuth";
import { OwnerLayout } from "@/components/layout/owner-layout";

export const metadata = {
  title: "Project Owner Dashboard",
};

export default function OwnerLayoutWrapper({ children }) {
  return (
    <RequireAuth>
      <OwnerLayout>{children}</OwnerLayout>
    </RequireAuth>
  );
}