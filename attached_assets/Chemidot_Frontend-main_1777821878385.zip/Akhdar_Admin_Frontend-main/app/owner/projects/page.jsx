"use client";

import { FilterBar } from "@/components/projects/filter-bar";
import { Button } from "@/components/ui/button";
import { Download, Plus } from "lucide-react";
import Link from "next/link";
import { ProjectsTable } from "@/components/projects/projects-table";
import { ProjectDetail } from "@/components/projects/project-detail";
import { useState, useRef, Suspense } from "react";
import { projectsService } from "@/services/api/projectsService";
import { toast } from "sonner";
import { useSearchParams } from "next/navigation";
import { useSelector } from "react-redux";

function OwnerProjectsContent() {
  const [appliedFilters, setAppliedFilters] = useState(null);
  const [exportLoading, setExportLoading] = useState(false);
  const projectsTableRef = useRef();
  const searchParams = useSearchParams();
  const projectId = searchParams.get('id');
  const userData = useSelector((state) => state.user.userData);

  const handleFiltersChange = (filters, shouldApply = false) => {
    console.log("handleFiltersChange called with:", { filters, shouldApply });
    if (shouldApply) {
      console.log("Applying filters in page:", filters);
      setAppliedFilters(filters);
      // Trigger table refresh with new filters
      if (projectsTableRef.current?.applyFilters) {
        projectsTableRef.current.applyFilters(filters);
      }
    }
  };

  const handleExport = async () => {
    try {
      setExportLoading(true);
      console.log("Exporting with filters:", appliedFilters);

      await projectsService.exportProjects({
        pageNumber: 1,
        pageSize: 1000,
        filters: appliedFilters
      });

      toast.success("Projects exported successfully!");
    } catch (error) {
      console.error("Export failed:", error);
      toast.error("Failed to export projects. Please try again.");
    } finally {
      setExportLoading(false);
    }
  };

  // If there's a project ID in query params, show project detail
  if (projectId) {
    return <ProjectDetail projectId={projectId} isOwnerView={true} />;
  }

  // Otherwise show the projects table
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-balance">My Projects</h1>
          <p className="text-muted-foreground">
            View your carbon credit projects
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-2">
          <Link href="/add-project">
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Create Project
            </Button>
          </Link>
          <Button
            variant="outline"
            onClick={handleExport}
            disabled={exportLoading}
          >
            <Download className="h-4 w-4 mr-2" />
            {exportLoading ? "Exporting..." : "Export"}
          </Button>
        </div>
      </div>

      <FilterBar onFiltersChange={handleFiltersChange} isOwnerView={true} />
      <ProjectsTable ref={projectsTableRef} appliedFilters={appliedFilters} isOwnerView={true} />
    </div>
  );
}

export default function OwnerProjectsPage() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <OwnerProjectsContent />
    </Suspense>
  );
}
