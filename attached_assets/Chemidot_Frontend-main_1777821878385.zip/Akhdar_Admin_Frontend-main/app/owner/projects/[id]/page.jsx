import { OwnerProjectDetail } from "@/components/owner/owner-project-detail";

export default function OwnerProjectDetailPage({ params }) {
  return <OwnerProjectDetail projectId={params.id} />;
}

export async function generateStaticParams() {
  try {
    if (process.env.NODE_ENV === 'development') {
      return [];
    }
    return [{ id: "fallback" }];
  } catch (error) {
    return [];
  }
}
