import { ProjectSubmissionForm } from "@/components/owner/project-submission-form";

export default function NewProjectPage() {
  return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-balance">
            Submit New Project
          </h1>
          <p className="text-muted-foreground">
            Submit your carbon credit project for review and approval
          </p>
        </div>

        <ProjectSubmissionForm />
      </div>
  );
}
