"use client";
import { useEffect } from "react";
import { useRouter } from "next/navigation";

export default function OwnerDashboardPage() {
  const router = useRouter();

  useEffect(() => {
    // Dashboard removed — redirect to Owner Projects
    router.replace("/owner/projects");
  }, [router]);

  return (
    <div className="flex items-center justify-center h-32">
      <p>Redirecting to projects...</p>
    </div>
  );
}