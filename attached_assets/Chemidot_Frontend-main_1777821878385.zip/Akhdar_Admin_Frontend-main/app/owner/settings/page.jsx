"use client";

import { UnifiedProfileSettings as OwnerProfileSettings } from "@/components/settings/unified-profile-settings";

export default function OwnerSettingsPage() {
  return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-balance">
            Settings
          </h1>
          <p className="text-muted-foreground">
            Manage your profile and company settings
          </p>
        </div>

        <OwnerProfileSettings />
      </div>
  );
}