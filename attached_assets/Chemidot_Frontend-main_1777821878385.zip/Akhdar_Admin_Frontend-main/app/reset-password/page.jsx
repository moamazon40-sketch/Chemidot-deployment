"use client";

import { Suspense, useEffect } from "react";
import { ResetPasswordForm } from "@/components/auth/reset-password-form";
import { useSearchParams, useRouter } from "next/navigation";

function ResetPasswordContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const resetToken = searchParams.get('ResetToken');
  const email = searchParams.get('email');

  console.log("Reset Password - resetToken:", resetToken, "email:", email);

  // Official S3 trailing slash fix for URLs without trailing slash
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const currentUrl = window.location.href;

      // Check if URL has query params but no trailing slash before them
      if (currentUrl.includes('?') && !currentUrl.includes('/?')) {
        // Fix the URL by adding trailing slash before query params
        const fixedUrl = currentUrl.replace('?', '/?');
        console.log('Fixing S3 URL from:', currentUrl, 'to:', fixedUrl);

        // Replace current URL with fixed version (this preserves query params on S3)
        window.location.replace(fixedUrl);
        return;
      }
    }
  }, []);

  // If there's a reset token in query params, show reset password form
  if (resetToken) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-md w-full space-y-8">
          <div className="bg-white p-8 rounded-lg shadow-md">
            <ResetPasswordForm resetToken={resetToken} email={email} />
          </div>
        </div>
      </div>
    );
  }

  // Otherwise show a message (exactly like projects shows table when no projectId)
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div className="bg-white p-8 rounded-lg shadow-md">
          <div className="text-center">
            <h2 className="text-2xl font-bold">Reset Password</h2>
            <p className="text-gray-600 mt-2">
              Please use a valid reset password link.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function ResetPasswordPage() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <ResetPasswordContent />
    </Suspense>
  );
}