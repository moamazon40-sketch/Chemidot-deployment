"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useSelector } from "react-redux";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, AlertCircle, Eye, EyeOff, Lock, Shield } from "lucide-react";
import { AdminChangePassword } from "@/services/auth/authService";
import { toast } from "sonner";
import { useDispatch } from "react-redux";
import { setUserData } from "@/store/userSlice";
import { setAuthData, getAuthData } from "@/utils/authStorage";

export default function ChangePasswordPage() {
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [isCheckingAuth, setIsCheckingAuth] = useState(true);

  const router = useRouter();
  const dispatch = useDispatch();
  const userData = useSelector((state) => state.user.userData);

  useEffect(() => {
    const checkAuthAndRedirect = async () => {
      try {
        // Check if user is authenticated
        let currentUserData = userData;

        // If no userData in Redux, try to get from storage
        if (!currentUserData) {
          const storageData = getAuthData();
          if (storageData) {
            currentUserData = storageData;
          }
        }

        if (!currentUserData || !currentUserData.token) {
          console.log("No authentication found, redirecting to login");
          router.replace("/");
          return;
        }

        // Check if user is NOT using temporary password
        if (!currentUserData.IsUsingTemporaryPassword &&
            !currentUserData.session?.isUsingTemporaryPassword) {
          console.log("User is not using temporary password, redirecting to dashboard");

          // Redirect based on UserType
          const userType = currentUserData.UserType;
          if (userType === "SuperAdmin" || userType === "Admin") {
            router.replace("/admin/projects");
          } else if (userType === "ProjectOwner") {
            router.replace("/owner/projects");
          } else {
            router.replace("/");
          }
          return;
        }

        console.log("User needs to change temporary password");

        // Auto-fill current password if available from login
        const tempPassword = sessionStorage.getItem("tempCurrentPassword");
        if (tempPassword) {
          setCurrentPassword(tempPassword);
          // Clean up the temporary storage
          sessionStorage.removeItem("tempCurrentPassword");
        }

        setIsCheckingAuth(false);
      } catch (error) {
        console.error("Error checking auth:", error);
        router.replace("/");
      }
    };

    checkAuthAndRedirect();
  }, [userData, router]);

  const validatePassword = (password) => {
    const errors = [];

    if (password.length < 8) {
      errors.push("at least 8 characters");
    }
    if (!/[A-Z]/.test(password)) {
      errors.push("one uppercase letter");
    }
    if (!/[a-z]/.test(password)) {
      errors.push("one lowercase letter");
    }
    if (!/[0-9]/.test(password)) {
      errors.push("one number");
    }
    if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) {
      errors.push("one special character");
    }

    return errors;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");

    // Validation
    if (!currentPassword) {
      setError("Please enter your current password.");
      setIsLoading(false);
      return;
    }

    if (!newPassword) {
      setError("Please enter a new password.");
      setIsLoading(false);
      return;
    }

    const passwordErrors = validatePassword(newPassword);
    if (passwordErrors.length > 0) {
      setError(`Password must contain ${passwordErrors.join(", ")}.`);
      setIsLoading(false);
      return;
    }

    if (newPassword !== confirmPassword) {
      setError("New passwords do not match.");
      setIsLoading(false);
      return;
    }

    if (newPassword === currentPassword) {
      setError("New password must be different from current password.");
      setIsLoading(false);
      return;
    }

    try {
      console.log("Attempting to change password...");

      await AdminChangePassword({
        currentPassword: currentPassword,
        newPassword: newPassword,
      });

      toast.success("Password changed successfully! Welcome to the system.");

      // Update user data to indicate password is no longer temporary
      let currentUserData = userData;
      if (!currentUserData) {
        currentUserData = getAuthData();
      }

      const updatedUserData = {
        ...currentUserData,
        IsUsingTemporaryPassword: false,
        session: {
          ...currentUserData.session,
          isUsingTemporaryPassword: false,
        }
      };

      // Save to Redux store
      dispatch(setUserData(updatedUserData));

      // Save to storage
      setAuthData(updatedUserData, updatedUserData.RememberMe || false);

      // Navigate based on UserType
      const userType = currentUserData.UserType;
      console.log("Password changed successfully. UserType:", userType);

      setTimeout(() => {
        if (userType === "SuperAdmin" || userType === "Admin") {
          console.log("Redirecting to admin dashboard");
          router.replace("/admin/projects");
        } else if (userType === "ProjectOwner") {
          console.log("Redirecting to owner dashboard");
          router.replace("/owner/projects");
        } else {
          console.log("Unknown UserType, redirecting to home");
          router.replace("/");
        }
      }, 1000);

    } catch (error) {
      console.error("Password change error:", error);
      setError(error.message || "Failed to change password. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  if (isCheckingAuth) {
    return (
      <div className="min-h-screen bg-[#f2f7f2] flex items-center justify-center">
        <div className="flex items-center space-x-2">
          <Loader2 className="h-6 w-6 animate-spin" />
          <span>Verifying authentication...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f2f7f2] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full">
        <Card>
          <CardHeader className="text-center">
            <div className="mx-auto w-12 h-12 bg-[#7CE495] rounded-full flex items-center justify-center mb-4">
              <Lock className="h-6 w-6 text-white" />
            </div>
            <CardTitle className="text-2xl text-[#2B5A3E]">Change Your Password</CardTitle>
            <CardDescription className="text-center">
              You are using a temporary password. Please set a new password to continue using the system.
            </CardDescription>
          </CardHeader>

          <CardContent>
            <div className="mb-6">
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <div className="flex items-start">
                  <Shield className="h-5 w-5 text-yellow-600 mt-0.5 mr-3 flex-shrink-0" />
                  <div>
                    <p className="text-sm text-yellow-800 font-medium">Security Requirement</p>
                    <p className="text-sm text-yellow-700 mt-1">
                      For security reasons, you must change your temporary password before accessing the system.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <Label htmlFor="currentPassword">Current Password</Label>
                <div className="relative">
                  <Input
                    id="currentPassword"
                    type={showCurrentPassword ? "text" : "password"}
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    placeholder="Enter your current password"
                    required
                    className="pr-10"
                  />
                  <button
                    type="button"
                    className="absolute inset-y-0 right-0 pr-3 flex items-center"
                    onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                  >
                    {showCurrentPassword ? (
                      <EyeOff className="h-4 w-4 text-gray-400" />
                    ) : (
                      <Eye className="h-4 w-4 text-gray-400" />
                    )}
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="newPassword">New Password</Label>
                <div className="relative">
                  <Input
                    id="newPassword"
                    type={showNewPassword ? "text" : "password"}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Enter your new password"
                    required
                    className="pr-10"
                  />
                  <button
                    type="button"
                    className="absolute inset-y-0 right-0 pr-3 flex items-center"
                    onClick={() => setShowNewPassword(!showNewPassword)}
                  >
                    {showNewPassword ? (
                      <EyeOff className="h-4 w-4 text-gray-400" />
                    ) : (
                      <Eye className="h-4 w-4 text-gray-400" />
                    )}
                  </button>
                </div>
                <p className="text-xs text-gray-500">
                  Password must contain at least 8 characters including uppercase, lowercase, number, and special character.
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Confirm New Password</Label>
                <div className="relative">
                  <Input
                    id="confirmPassword"
                    type={showConfirmPassword ? "text" : "password"}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Confirm your new password"
                    required
                    className="pr-10"
                  />
                  <button
                    type="button"
                    className="absolute inset-y-0 right-0 pr-3 flex items-center"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  >
                    {showConfirmPassword ? (
                      <EyeOff className="h-4 w-4 text-gray-400" />
                    ) : (
                      <Eye className="h-4 w-4 text-gray-400" />
                    )}
                  </button>
                </div>
              </div>

              <Button
                type="submit"
                className="w-full bg-[#7CE495] hover:bg-[#6BD485] text-white"
                disabled={isLoading}
              >
                {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Change Password & Continue
              </Button>
            </form>

            <div className="mt-6 text-center">
              <p className="text-xs text-gray-500">
                You cannot access other parts of the system until you change your password.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}