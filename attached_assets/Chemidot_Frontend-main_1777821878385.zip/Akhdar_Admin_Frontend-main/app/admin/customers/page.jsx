"use client";

import { CustomersTable } from "@/components/customers/customers-table";
import { CustomerFilters } from "@/components/customers/customer-filters";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import { useState, useRef } from "react";
import { customersService } from "@/services/api/customersService";
import { toast } from "sonner";

export default function AdminCustomersPage() {
  const [appliedFilters, setAppliedFilters] = useState(null);
  const [exportLoading, setExportLoading] = useState(false);
  const customersTableRef = useRef();

  const handleFiltersChange = (filters, shouldApply = false) => {
    console.log("handleFiltersChange called with:", { filters, shouldApply });
    if (shouldApply) {
      console.log("Applying customer filters in page:", filters);
      setAppliedFilters(filters);
      // Trigger table refresh with new filters
      if (customersTableRef.current?.applyFilters) {
        customersTableRef.current.applyFilters(filters);
      }
    }
  };

  const handleExport = async () => {
    try {
      setExportLoading(true);
      console.log("Exporting customers with filters:", appliedFilters);

      await customersService.exportCustomers({
        pageNumber: 1,
        pageSize: 1000, // Export more records
        filters: appliedFilters
      });

      toast.success("Customers exported successfully!");
    } catch (error) {
      console.error("Export failed:", error);
      toast.error("Failed to export customers. Please try again.");
    } finally {
      setExportLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-balance">Customers</h1>
          <p className="text-muted-foreground">
            Manage individual and company customer accounts, view their activities and carbon offset purchases
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-2">
          <Button
            variant="outline"
            onClick={handleExport}
            disabled={exportLoading}
            className="flex items-center gap-2"
          >
            <Download className="h-4 w-4" />
            {exportLoading ? "Exporting..." : "Export Customers"}
          </Button>
        </div>
      </div>


      <CustomerFilters onFiltersChange={handleFiltersChange} />

      <CustomersTable ref={customersTableRef} appliedFilters={appliedFilters} />
    </div>
  );
}