"use client";

import { ESGFormsFilters } from "@/components/esg-forms/esg-forms-filters";
import { ESGFormsTable } from "@/components/esg-forms/esg-forms-table";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import { useState, useRef } from "react";
import { esgFormsService } from "@/services/api/esgFormsService";
import { toast } from "sonner";

export default function FormDataPage() {
  const [appliedFilters, setAppliedFilters] = useState(null);
  const [exportLoading, setExportLoading] = useState(false);
  const esgFormsTableRef = useRef();

  const handleFiltersChange = (filters, shouldApply = false) => {
    console.log("handleFiltersChange called with:", { filters, shouldApply });
    if (shouldApply) {
      console.log("Applying ESG forms filters in page:", filters);
      setAppliedFilters(filters);
      // Trigger table refresh with new filters
      if (esgFormsTableRef.current?.applyFilters) {
        esgFormsTableRef.current.applyFilters(filters);
      }
    }
  };

  const handleExport = async () => {
    try {
      setExportLoading(true);
      console.log("Exporting ESG forms with filters:", appliedFilters);

      await esgFormsService.exportESGForms({
        pageNumber: 1,
        pageSize: 1000, // Export more records
        filters: appliedFilters
      });

      toast.success("ESG Forms exported successfully!");
    } catch (error) {
      console.error("Export failed:", error);
      toast.error("Failed to export ESG forms. Please try again.");
    } finally {
      setExportLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-balance">ESG Form data</h1>
          <p className="text-muted-foreground">
            Manage and monitor all ESG form submissions
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-2">
          <Button
            variant="outline"
            onClick={handleExport}
            disabled={exportLoading}
          >
            <Download className="h-4 w-4 mr-2" />
            {exportLoading ? "Exporting..." : "Export ESG Form data"}
          </Button>
        </div>
      </div>

      <ESGFormsFilters onFiltersChange={handleFiltersChange} />

      <ESGFormsTable ref={esgFormsTableRef} appliedFilters={appliedFilters} />
    </div>
  );
}