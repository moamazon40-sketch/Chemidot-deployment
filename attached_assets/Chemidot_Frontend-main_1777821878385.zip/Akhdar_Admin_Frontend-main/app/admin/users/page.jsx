"use client";

import { UsersTable } from "@/components/users/users-table";
import { UserInviteModal } from "@/components/users/user-invite-modal";
import { UserFilters } from "@/components/users/user-filters";
import { Button } from "@/components/ui/button";
import { UserPlus, Download } from "lucide-react";
import { useState, useRef } from "react";
import { useSelector } from "react-redux";
import { usersService } from "@/services/api/usersService";
import { toast } from "sonner";

export default function AdminUsersPage() {
  const [inviteModalOpen, setInviteModalOpen] = useState(false);
  const [appliedFilters, setAppliedFilters] = useState(null);
  const [exportLoading, setExportLoading] = useState(false);
  const usersTableRef = useRef();
  const userData = useSelector((state) => state.user.userData);

  // Only SuperAdmin can invite admins
  const canInviteAdmin = userData?.UserType === "SuperAdmin";

  const handleFiltersChange = (filters, shouldApply = false) => {
    console.log("handleFiltersChange called with:", { filters, shouldApply });
    if (shouldApply) {
      console.log("Applying user filters in page:", filters);
      setAppliedFilters(filters);
      // Trigger table refresh with new filters
      if (usersTableRef.current?.applyFilters) {
        usersTableRef.current.applyFilters(filters);
      }
    }
  };

  const handleExport = async () => {
    try {
      setExportLoading(true);
      console.log("Exporting users with filters:", appliedFilters);

      await usersService.exportUsers({
        pageNumber: 1,
        pageSize: 1000, // Export more records
        filters: appliedFilters
      });

      toast.success("Users exported successfully!");
    } catch (error) {
      console.error("Export failed:", error);
      toast.error("Failed to export users. Please try again.");
    } finally {
      setExportLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-balance">Users & Owners</h1>
          <p className="text-muted-foreground">
            Manage user accounts, roles, and permissions
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-2">
          <Button
            variant="outline"
            onClick={handleExport}
            disabled={exportLoading}
          >
            <Download className="h-4 w-4 mr-2" />
            {exportLoading ? "Exporting..." : "Export Users"}
          </Button>

          {canInviteAdmin && (
            <Button onClick={() => setInviteModalOpen(true)}>
              <UserPlus className="h-4 w-4 mr-2" />
              Invite Admin
            </Button>
          )}
        </div>
      </div>

      <UserFilters onFiltersChange={handleFiltersChange} />

      <UsersTable ref={usersTableRef} appliedFilters={appliedFilters} />

      {canInviteAdmin && (
        <UserInviteModal
          open={inviteModalOpen}
          onOpenChange={setInviteModalOpen}
        />
      )}
    </div>
  );
}
