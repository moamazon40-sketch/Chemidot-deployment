"use client";

import { ContactUsFilters } from "@/components/contact-us/contact-us-filters";
import { ContactUsTable } from "@/components/contact-us/contact-us-table";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import { useState, useRef } from "react";
import { contactUsService } from "@/services/api/contactUsService";
import { toast } from "sonner";

export default function CustomerDataPage() {
  const [appliedFilters, setAppliedFilters] = useState(null);
  const [exportLoading, setExportLoading] = useState(false);
  const contactUsTableRef = useRef();

  const handleFiltersChange = (filters, shouldApply = false) => {
    console.log("handleFiltersChange called with:", { filters, shouldApply });
    if (shouldApply) {
      console.log("Applying contact us filters in page:", filters);
      setAppliedFilters(filters);
      // Trigger table refresh with new filters
      if (contactUsTableRef.current?.applyFilters) {
        contactUsTableRef.current.applyFilters(filters);
      }
    }
  };

  const handleExport = async () => {
    try {
      setExportLoading(true);
      console.log("Exporting contact us requests with filters:", appliedFilters);

      await contactUsService.exportContactUsRequests({
        pageNumber: 1,
        pageSize: 1000, // Export more records
        filters: appliedFilters
      });

      toast.success("Contact Us requests exported successfully!");
    } catch (error) {
      console.error("Export failed:", error);
      toast.error("Failed to export contact requests. Please try again.");
    } finally {
      setExportLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-balance">contactUs form data</h1>
          <p className="text-muted-foreground">
            Manage and monitor all contact us form submissions
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-2">
          <Button
            variant="outline"
            onClick={handleExport}
            disabled={exportLoading}
          >
            <Download className="h-4 w-4 mr-2" />
            {exportLoading ? "Exporting..." : "Export contactUs form data"}
          </Button>
        </div>
      </div>

      <ContactUsFilters onFiltersChange={handleFiltersChange} />

      <ContactUsTable ref={contactUsTableRef} appliedFilters={appliedFilters} />
    </div>
  );
}