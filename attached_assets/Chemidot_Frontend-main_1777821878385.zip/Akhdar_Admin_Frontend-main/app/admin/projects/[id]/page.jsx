import { ProjectDetail } from "@/components/projects/project-detail";

export default function ProjectDetailPage({ params }) {
  return <ProjectDetail projectId={params.id} />;
}

export async function generateStaticParams() {
  // For S3 static hosting, we only generate a fallback route
  // Real project IDs should use query parameters: /admin/projects?id=PROJECT_ID
  return [{ id: "fallback" }];
}
