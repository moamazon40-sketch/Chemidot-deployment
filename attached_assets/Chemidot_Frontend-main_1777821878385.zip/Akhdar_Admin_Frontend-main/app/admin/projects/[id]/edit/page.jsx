import EditProjectFormWrapper from "./page-wrapper";

export default function EditProjectPage({ params }) {
  return <EditProjectFormWrapper projectId={params.id} />;
}

export async function generateStaticParams() {
  // For S3 static hosting, we only generate a fallback route
  // Real project IDs should use query parameters: /admin/projects?id=PROJECT_ID
  return [{ id: "fallback" }];
}