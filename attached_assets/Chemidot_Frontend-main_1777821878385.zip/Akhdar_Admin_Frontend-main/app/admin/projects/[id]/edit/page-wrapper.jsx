"use client";

import React, { useState, useEffect } from "react";
import { useForm, Controller, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { ChevronDown, Plus, Minus, X, Upload, Download, Loader2, Eye } from "lucide-react";
import { toast, Toaster } from "sonner";
import { apiInstance } from "@/services/api/apiInstance";
import { CARBON_OFFSET_URLS } from "@/services/api/apiConfig";
import { projectsService } from "@/services/api/projectsService";
import { useRouter } from "next/navigation";

// Countries grouped by region
const countryGroups = {
  "Asia": [
    "Bangladesh", "Cambodia", "China", "India", "Indonesia", "KSA", "Myanmar", "Thailand", "Turkey", "Vietnam"
  ],
  "Africa": [
    "Congo, the Democratic Republic of the", "Egypt", "Kenya", "Malawi", "Mozambique", "Rwanda", "Sierra Leone", "South Africa", "Uganda", "Zambia"
  ],
  "North America": [
    "Antigua and Barbuda", "Canada", "Dominican Republic", "El Salvador", "Mexico", "United States of America"
  ],
  "South America": [
    "Argentina", "Brazil", "Chile", "Colombia", "Peru"
  ],
  "Europe": [
    "Germany", "Iceland", "Italy", "Romania", "Spain", "Switzerland", "Ukraine"
  ]
};

// Country to Alpha-2 ISO code mapping
const countryISOMap = {
  "Bangladesh": "BD",
  "Cambodia": "KH",
  "China": "CN",
  "India": "IN",
  "Indonesia": "ID",
  "KSA": "SA",
  "Myanmar": "MM",
  "Thailand": "TH",
  "Turkey": "TR",
  "Vietnam": "VN",
  "Congo, the Democratic Republic of the": "CD",
  "Egypt": "EG",
  "Kenya": "KE",
  "Malawi": "MW",
  "Mozambique": "MZ",
  "Rwanda": "RW",
  "Sierra Leone": "SL",
  "South Africa": "ZA",
  "Uganda": "UG",
  "Zambia": "ZM",
  "Antigua and Barbuda": "AG",
  "Canada": "CA",
  "Dominican Republic": "DO",
  "El Salvador": "SV",
  "Mexico": "MX",
  "United States of America": "US",
  "Argentina": "AR",
  "Brazil": "BR",
  "Chile": "CL",
  "Colombia": "CO",
  "Peru": "PE",
  "Germany": "DE",
  "Iceland": "IS",
  "Italy": "IT",
  "Romania": "RO",
  "Spain": "ES",
  "Switzerland": "CH",
  "Ukraine": "UA"
};

const projectKinds = [
  { value: "Carbon Removal", label: "Carbon Removal" },
  { value: "Avoidance", label: "Avoidance" },
  { value: "Reduction", label: "Reduction" },
  { value: "Sequestration", label: "Sequestration" },
];

const standardTypes = [
  { value: "CDM Standard", label: "CDM Standard" },
  { value: "VCS", label: "VCS" },
  { value: "Isometric Standard", label: "Isometric Standard" },
  { value: "Gold Standard", label: "Gold Standard" },
  { value: "CerCarbono", label: "CerCarbono" },
  { value: "Puro Standard", label: "Puro Standard" },
  { value: "ICR Standard", label: "ICR Standard" },
  { value: "MITECO", label: "MITECO" },
  { value: "City Forest Credits", label: "City Forest Credits" },
  { value: "CAR Standard", label: "CAR Standard" },
  { value: "ACR Standard", label: "ACR Standard" },
  { value: "Trinity Natural Capital Markets", label: "Trinity Natural Capital Markets" },
  { value: "ISO 14064-2", label: "ISO 14064-2" },
  { value: "Hemp Carbon Standard", label: "Hemp Carbon Standard" },
  { value: "Regen Standard (Regenerative Standard)", label: "Regen Standard (Regenerative Standard)" },
  { value: "Biotrust", label: "Biotrust" },
  { value: "ACR", label: "ACR" },
  { value: "BCR Standard", label: "BCR Standard" },
];

const registries = [
  { value: "CDM Registry", label: "CDM Registry" },
  { value: "Non registered", label: "Non registered" },
  { value: "Verra Registry", label: "Verra Registry" },
  { value: "Isometric Registry", label: "Isometric Registry" },
  { value: "GSF Registry", label: "GSF Registry" },
  { value: "EcoRegistry", label: "EcoRegistry" },
  { value: "Puro Registry", label: "Puro Registry" },
  { value: "ICR (International Carbon Registry)", label: "ICR (International Carbon Registry)" },
  { value: "MITECO", label: "MITECO" },
  { value: "City Forest Registry", label: "City Forest Registry" },
  { value: "The Reserve", label: "The Reserve" },
  { value: "Evident", label: "Evident" },
  { value: "ACR", label: "ACR" },
  { value: "Trinity Natural Capital Markets Registry", label: "Trinity Natural Capital Markets Registry" },
  { value: "Pina.Earth", label: "Pina.Earth" },
  { value: "Trusted Carbon", label: "Trusted Carbon" },
  { value: "Regen Standard (Regenerative Standard)", label: "Regen Standard (Regenerative Standard)" },
  { value: "BioTrust", label: "BioTrust" },
  { value: "BioCarbon Registry", label: "BioCarbon Registry" },
];

const mechanisms = [
  { value: "Avoidance", label: "Avoidance" },
  { value: "Removal", label: "Removal" },
];

const sdgOptions = [
  { value: "1. No poverty", label: "1. No poverty" },
  { value: "2. Zero hunger", label: "2. Zero hunger" },
  { value: "3. Good health and well-being", label: "3. Good health and well-being" },
  { value: "4. Quality Education", label: "4. Quality Education" },
  { value: "5. Gender Equality", label: "5. Gender Equality" },
  { value: "6. Clean water and sanitation", label: "6. Clean water and sanitation" },
  { value: "7. Affordable and clean energy", label: "7. Affordable and clean energy" },
  { value: "8. Decent work and economic growth", label: "8. Decent work and economic growth" },
  { value: "9. Industry, innovation and infrastructure", label: "9. Industry, innovation and infrastructure" },
  { value: "10. Reduced inequalities", label: "10. Reduced inequalities" },
  { value: "11. Sustainable cities and communities", label: "11. Sustainable cities and communities" },
  { value: "12. Responsible consumption and production", label: "12. Responsible consumption and production" },
  { value: "13. Climate action", label: "13. Climate action" },
  { value: "14. Life below water", label: "14. Life below water" },
  { value: "15. Life on land", label: "15. Life on land" },
  { value: "16. Peace, justice and strong institution", label: "16. Peace, justice and strong institution" },
  { value: "17. Partnerships for the goals", label: "17. Partnerships for the goals" },
];

const projectTypes = [
  { value: "Sustainable Agriculture", label: "Sustainable Agriculture" },
  { value: "Afforestation, Reforestation & Revegetation (ARR)", label: "Afforestation, Reforestation & Revegetation (ARR)" },
  { value: "Improved Forest Management (IFM)", label: "Improved Forest Management (IFM)" },
  { value: "Agroforestry", label: "Agroforestry" },
  { value: "Regenerative Agriculture", label: "Regenerative Agriculture" },
  { value: "Forestry Management - MX", label: "Forestry Management - MX" },
  { value: "Livestock Methane Reduction", label: "Livestock Methane Reduction" },
  { value: "REDD+ (Reducing Emissions from Deforestation and Forest Degradation)", label: "REDD+ (Reducing Emissions from Deforestation and Forest Degradation)" },
];

const projectImpacts = [
  { value: "Avoid Deforestation", label: "Avoid Deforestation" },
  { value: "Change Lives", label: "Change Lives" },
  { value: "Displace Harmful Fuels", label: "Displace Harmful Fuels" },
  { value: "Eliminate Poverty", label: "Eliminate Poverty" },
  { value: "Employment Opportunities", label: "Employment Opportunities" },
  { value: "Promote Gender Equality", label: "Promote Gender Equality" },
  { value: "Protect Biodiversity", label: "Protect Biodiversity" },
  { value: "Protect the Planet", label: "Protect the Planet" },
  { value: "Protect Wildlife", label: "Protect Wildlife" },
  { value: "Regional Economic Development", label: "Regional Economic Development" },
  { value: "Remove CO2 from the Atmosphere", label: "Remove CO2 from the Atmosphere" },
  { value: "Save Forests", label: "Save Forests" },
];

const statusOptions = [
  { value: "Active", label: "Active" },
  { value: "Suspended", label: "Suspended" },
  { value: "Rejected", label: "Rejected" },
  { value: "Pending", label: "Pending" },
];

const editProjectSchema = z.object({
  ProjectName: z.string().min(1, "Project name is required"),
  Description: z.string().min(1, "Description is required"),
  ProjectKind: z.string().min(1, "Project kind is required"),
  Country: z.string().min(1, "Country is required"),
  CountryISOCode: z.string().min(1, "Country ISO code is required"),
  Latitude: z.number().min(-90).max(90, "Valid latitude required"),
  Longitude: z.number().min(-180).max(180, "Valid longitude required"),
  Vintages: z.array(z.object({
    Year: z.number().min(1900, "Valid year required"),
    CarbonPricePerTon: z.number().min(0.01, "Price must be greater than 0").optional()
  })).optional(),
  DefaultCarbonPricePerTon: z.number().min(0.01, "Default price must be greater than 0").optional().nullable(),
  AvailableStock: z.number().min(1, "Available stock must be at least 1"),
  MinimumPurchaseAmount: z.number().min(1, "Minimum purchase amount must be at least 1"),
  StandardType: z.string().min(1, "Standard type is required"),
  Registry: z.string().min(1, "Registry is required"),
  Mechanism: z.string().min(1, "Mechanism is required"),
  ProjectOwner: z.object({
    firstName: z.string().min(1, "First name is required"),
    lastName: z.string().min(1, "Last name is required"),
    CompanyName: z.string().min(1, "Company name is required"),
    Email: z.string().email("Valid email required"),
    PhoneNumber: z.string().min(1, "Phone number is required")
  }),
  SDGs: z.array(z.string()).min(1, "At least one SDG is required"),
  ProjectType: z.string().min(1, "Project type is required"),
  ProjectImpact: z.string().min(1, "Project impact is required"),
  ProjectStatus: z.string().optional(),
});

const ErrorMessage = ({ message }) => {
  return message ? <p className="text-red-500 text-sm mt-1">{message}</p> : null;
};

// Interactive Map Component (simplified for editing)
const InteractiveMap = ({ latitude, longitude, onLocationSelect }) => {
  const mapRef = React.useRef(null);
  const mapInstanceRef = React.useRef(null);
  const markerRef = React.useRef(null);

  React.useEffect(() => {
    // Load Leaflet CSS and JS dynamically
    if (!document.querySelector('link[href*="leaflet"]')) {
      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
      document.head.appendChild(link);
    }

    if (!window.L) {
      const script = document.createElement('script');
      script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
      script.onload = () => initializeMap();
      document.head.appendChild(script);
    } else {
      initializeMap();
    }

    function initializeMap() {
      // Ensure we have a DOM element and it's not already being used
      if (!mapRef.current) return;

      // Clean up any existing map instance
      if (mapInstanceRef.current) {
        try {
          mapInstanceRef.current.remove();
          mapInstanceRef.current = null;
        } catch (error) {
          console.warn('Error cleaning up map:', error);
        }
      }

      // Clear the container content to ensure it's clean
      mapRef.current.innerHTML = '';

      try {
        const map = window.L.map(mapRef.current).setView([latitude || 24.7136, longitude || 46.6753], latitude && longitude ? 10 : 6);

        window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          attribution: '© OpenStreetMap contributors'
        }).addTo(map);

        map.on('click', function(e) {
          const { lat, lng } = e.latlng;
          if (markerRef.current) {
            map.removeLayer(markerRef.current);
          }
          markerRef.current = window.L.marker([lat, lng]).addTo(map);
          onLocationSelect(lat, lng);
        });

        if (latitude && longitude) {
          markerRef.current = window.L.marker([latitude, longitude]).addTo(map);
        }

        mapInstanceRef.current = map;
      } catch (error) {
        console.error('Error initializing map:', error);
      }
    }

    return () => {
      if (mapInstanceRef.current) {
        try {
          mapInstanceRef.current.remove();
          mapInstanceRef.current = null;
        } catch (error) {
          console.warn('Error cleaning up map on unmount:', error);
        }
      }
    };
  }, []);

  React.useEffect(() => {
    if (mapInstanceRef.current && latitude && longitude) {
      if (markerRef.current) {
        mapInstanceRef.current.removeLayer(markerRef.current);
      }
      markerRef.current = window.L.marker([latitude, longitude]).addTo(mapInstanceRef.current);
      mapInstanceRef.current.setView([latitude, longitude], 10);
    }
  }, [latitude, longitude]);

  return (
    <div className="relative w-full">
      <div className="relative w-full h-64">
        <div ref={mapRef} className="w-full h-full rounded-lg overflow-hidden border border-gray-300"></div>
        <div className="absolute top-2 left-2 bg-white/90 px-2 py-1 rounded text-xs text-gray-600 z-[1000]">
          Click on the map to update project location
        </div>
      </div>
    </div>
  );
};

const EditProjectFormWrapper = ({ projectId }) => {
  const [loading, setLoading] = useState(false);
  const [initialLoading, setInitialLoading] = useState(true);
  const [originalData, setOriginalData] = useState(null);
  const [projectData, setProjectData] = useState(null);
  const [hasChanges, setHasChanges] = useState(false);
  const [projectImage, setProjectImage] = useState(null);
  const [projectGallery, setProjectGallery] = useState([]);
  const [documents, setDocuments] = useState([]);
  const [currentProjectImages, setCurrentProjectImages] = useState([]);
  const [currentProjectDocuments, setCurrentProjectDocuments] = useState([]);
  const router = useRouter();

  const {
    register,
    handleSubmit,
    control,
    formState: { errors },
    reset,
    watch,
    setValue,
    getValues,
  } = useForm({
    resolver: zodResolver(editProjectSchema),
    defaultValues: {
      ProjectName: "",
      Description: "",
      ProjectKind: "",
      Country: "",
      CountryISOCode: "",
      Latitude: null,
      Longitude: null,
      ProjectStatus: "Active",
      AvailableStock: 1,
      MinimumPurchaseAmount: 1,
      StandardType: "",
      Registry: "",
      Mechanism: "",
      ProjectOwner: {
        firstName: "",
        lastName: "",
        CompanyName: "",
        Email: "",
        PhoneNumber: ""
      },
      ProjectType: "",
      ProjectImpact: "",
      SDGs: [],
      Vintages: [],
      DefaultCarbonPricePerTon: null,
    },
  });

  const { fields: vintageFields, append: appendVintage, remove: removeVintage } = useFieldArray({
    control,
    name: "Vintages"
  });

  // SDG state management
  const [selectedSDGs, setSelectedSDGs] = useState([]);

  const country = watch("Country");
  const vintages = watch("Vintages") || [];

  // Auto-set ISO code when country changes
  React.useEffect(() => {
    if (country) {
      const isoCode = countryISOMap[country] || "";
      setValue("CountryISOCode", isoCode);
    }
  }, [country, setValue]);

  // Auto-set default price when vintages become empty
  React.useEffect(() => {
    if (vintages.length === 0 && originalData) {
      const currentDefaultPrice = getValues("DefaultCarbonPricePerTon");

      // If no default price is set, set a default value
      if (!currentDefaultPrice && currentDefaultPrice !== 0) {
        setValue("DefaultCarbonPricePerTon", originalData.DefaultCarbonPricePerTon || 0);
        forceChangeCheck(); // Trigger change detection
      }
    }
  }, [vintages.length, originalData, getValues, setValue]);

  // Watch all form values to detect changes
  const formValues = watch();

  // Force change detection trigger
  const [changeCounter, setChangeCounter] = useState(0);
  const forceChangeCheck = () => setChangeCounter(prev => prev + 1);

  // Load project data on mount
  useEffect(() => {
    const loadProjectData = async () => {
      try {
        setInitialLoading(true);
        console.log("Loading project data for ID:", projectId);

        const response = await apiInstance.get(
          `${CARBON_OFFSET_URLS.GET_PROJECT_BY_ID}?ProjectID=${projectId}`
        );

        console.log("API Response:", response);
        const responseProjectData = response.data.data || response.data;
        const userData = responseProjectData.user || response.data.user;
        console.log("Project data:", responseProjectData);
        console.log("ProjectOwner data:", responseProjectData.ProjectOwner);
        console.log("User data:", userData);

        // Store project data in state
        setProjectData(responseProjectData);

        // Process SDGs
        const processSDGs = (sdgData) => {
          console.log("Processing SDGs:", sdgData, typeof sdgData);
          if (!sdgData) return [];

          let sdgList = [];
          if (Array.isArray(sdgData)) {
            sdgList = sdgData.filter(sdg => sdg != null && sdg.toString().trim() !== '');
          } else if (typeof sdgData === 'string' && sdgData.trim() !== '') {
            // If it's a comma-separated string, split it
            sdgList = sdgData.split(',')
              .map(item => item.trim())
              .filter(item => item !== '');
          }

          console.log("Raw SDG list:", sdgList);

          // Map API SDGs to our option objects for badge display
          const mappedSDGs = sdgList.map(sdg => {
            const sdgString = sdg.toString().trim();

            // Try to match by label (new API format sends names like "Clean Water and Sanitation")
            const labelMatch = sdgOptions.find(option =>
              option.label === sdgString ||
              option.label.includes(sdgString) ||
              sdgString.includes(option.label)
            );
            if (labelMatch) {
              console.log("Label match found for:", sdgString, "->", labelMatch);
              return labelMatch; // Return the full option object
            }

            // Try to map number to SDG option (fallback for old format)
            const sdgNumber = parseInt(sdgString);
            if (!isNaN(sdgNumber) && sdgNumber >= 1 && sdgNumber <= 17) {
              const numberBasedMatch = sdgOptions[sdgNumber - 1];
              if (numberBasedMatch) {
                console.log("Number match found for:", sdgString, "->", numberBasedMatch);
                return numberBasedMatch; // Return the full option object
              }
            }

            console.log("No match found for SDG:", sdgString);
            return null;
          }).filter(Boolean); // Remove null values

          console.log("Mapped SDGs:", mappedSDGs);
          return mappedSDGs;
        };

        const initialFormData = {
          ProjectName: responseProjectData.ProjectName || "",
          Description: responseProjectData.Description || responseProjectData.ProjectDescription || "",
          ProjectKind: responseProjectData.ProjectKind || "",
          Country: responseProjectData.Country || "",
          CountryISOCode: responseProjectData.CountryISOCode || "",
          Latitude: responseProjectData.Latitude || null,
          Longitude: responseProjectData.Longitude || null,
          ProjectStatus: responseProjectData.Status || responseProjectData.ProjectStatus || "Active",
          AvailableStock: responseProjectData.AvailableStock || 1,
          MinimumPurchaseAmount: responseProjectData.MinimumPurchaseAmount || 1,
          StandardType: responseProjectData.StandardType || "",
          Registry: responseProjectData.Registry || "",
          Mechanism: responseProjectData.Mechanism || "",
          ProjectOwner: {
            firstName: (userData?.FirstName ||
                       responseProjectData.ProjectOwner?.firstName ||
                       responseProjectData.ProjectOwner?.FirstName ||
                       responseProjectData.firstName ||
                       responseProjectData.FirstName ||
                       ""),
            lastName: (userData?.LastName ||
                      responseProjectData.ProjectOwner?.lastName ||
                      responseProjectData.ProjectOwner?.LastName ||
                      responseProjectData.lastName ||
                      responseProjectData.LastName ||
                      ""),
            CompanyName: (userData?.CompanyName ||
                         responseProjectData.ProjectOwner?.CompanyName ||
                         responseProjectData.CompanyName ||
                         ""),
            Email: (userData?.Email ||
                   responseProjectData.ProjectOwner?.Email ||
                   responseProjectData.ProjectOwner?.email ||
                   responseProjectData.Email ||
                   responseProjectData.email ||
                   ""),
            PhoneNumber: (userData?.PhoneNumber ||
                         responseProjectData.ProjectOwner?.PhoneNumber ||
                         responseProjectData.ProjectOwner?.phoneNumber ||
                         responseProjectData.ProjectOwner?.phone ||
                         responseProjectData.PhoneNumber ||
                         responseProjectData.phoneNumber ||
                         responseProjectData.phone ||
                         "")
          },
          ProjectType: responseProjectData.ProjectType || "",
          ProjectImpact: responseProjectData.ProjectImpact || "",
          SDGs: processSDGs(responseProjectData.SDGs).map(sdg => sdg.label), // Store original SDG names for comparison
          Vintages: responseProjectData.Vintages || [],
          DefaultCarbonPricePerTon: responseProjectData.DefaultCarbonPricePerTon || null
        };

        // Store original data for comparison
        setOriginalData(initialFormData);

        console.log("Final extracted ProjectOwner data:", {
          firstName: userData?.FirstName,
          lastName: userData?.LastName,
          CompanyName: userData?.CompanyName,
          Email: userData?.Email,
          PhoneNumber: userData?.PhoneNumber
        });

        // Reset the entire form
        console.log("Resetting form with data:", initialFormData);
        console.log("ProjectOwner form data:", initialFormData.ProjectOwner);

        // Try resetting with a delay to ensure form is ready
        setTimeout(() => {
          reset(initialFormData);

          // Also try setting individual fields
          setValue("ProjectOwner.firstName", initialFormData.ProjectOwner.firstName);
          setValue("ProjectOwner.lastName", initialFormData.ProjectOwner.lastName);
          setValue("ProjectOwner.CompanyName", initialFormData.ProjectOwner.CompanyName);
          setValue("ProjectOwner.Email", initialFormData.ProjectOwner.Email);
          setValue("ProjectOwner.PhoneNumber", initialFormData.ProjectOwner.PhoneNumber);

          console.log("Form values after reset:", getValues());
          console.log("ProjectOwner values after reset:", getValues("ProjectOwner"));
        }, 100);

        // Set SDGs in state for badge display
        const sdgBadges = processSDGs(responseProjectData.SDGs);
        console.log("Setting SDG badges:", sdgBadges);
        setSelectedSDGs(sdgBadges);

        // Set current images and documents
        if (responseProjectData.ProjectImageURL) {
          setProjectImage({
            preview: responseProjectData.ProjectImageURL,
            url: responseProjectData.ProjectImageURL,
            isExisting: true
          });
        }

        if (responseProjectData.ProjectGallery) {
          setCurrentProjectImages(responseProjectData.ProjectGallery);
          setProjectGallery(responseProjectData.ProjectGallery.map(img => ({
            preview: img.url,
            url: img.url,
            originalName: img.originalName,
            isExisting: true
          })));
        }

        if (responseProjectData.Documents) {
          setCurrentProjectDocuments(responseProjectData.Documents);
          setDocuments(responseProjectData.Documents.map(doc => ({
            name: doc.originalName,
            url: doc.url,
            size: doc.size,
            type: doc.mimeType,
            isExisting: true
          })));
        }

      } catch (error) {
        console.error("Error loading project:", error);
        toast.error("Failed to load project data");
      } finally {
        setInitialLoading(false);
      }
    };

    if (projectId) {
      loadProjectData();
    }
  }, [projectId, reset]);

  // Additional useEffect to ensure ProjectOwner fields are set
  useEffect(() => {
    if (projectData && !initialLoading) {
      const userData = projectData.user;
      if (userData) {
        console.log("Setting ProjectOwner fields explicitly:", {
          firstName: userData.FirstName,
          lastName: userData.LastName,
          CompanyName: userData.CompanyName,
          Email: userData.Email,
          PhoneNumber: userData.PhoneNumber
        });

        setValue("ProjectOwner.firstName", userData.FirstName || "");
        setValue("ProjectOwner.lastName", userData.LastName || "");
        setValue("ProjectOwner.CompanyName", userData.CompanyName || "");
        setValue("ProjectOwner.Email", userData.Email || "");
        setValue("ProjectOwner.PhoneNumber", userData.PhoneNumber || "");
      }
    }
  }, [projectData, initialLoading, setValue]);

  // File upload handlers
  const handleProjectImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setProjectImage({
          file,
          preview: e.target.result,
          name: file.name,
          isExisting: false
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleProjectGalleryChange = (e) => {
    const files = Array.from(e.target.files);
    const newImages = [];

    files.forEach((file) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        newImages.push({
          file,
          preview: e.target.result,
          name: file.name,
          isExisting: false
        });
        if (newImages.length === files.length) {
          setProjectGallery([...projectGallery, ...newImages]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const handleDocumentsChange = (e) => {
    const files = Array.from(e.target.files);
    const newDocs = files.map(file => ({
      file,
      name: file.name,
      size: file.size,
      type: file.type,
      isExisting: false
    }));
    setDocuments([...documents, ...newDocs]);
  };

  const removeProjectImage = () => {
    setProjectImage(null);
  };

  const removeGalleryImage = (index) => {
    setProjectGallery(projectGallery.filter((_, i) => i !== index));
  };

  const removeDocument = (index) => {
    setDocuments(documents.filter((_, i) => i !== index));
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  // Check for changes whenever form values change
  useEffect(() => {
    if (!originalData) {
      setHasChanges(false);
      return;
    }

    // Check SDG changes from state
    const originalSDGNames = originalData.SDGs || [];
    const currentSDGNames = selectedSDGs.map(sdg => sdg.label);
    const sdgChanged = JSON.stringify(originalSDGNames.sort()) !== JSON.stringify(currentSDGNames.sort());

    // Explicit vintage change detection (critical for deletions)
    const originalVintagesCount = (originalData.Vintages || []).length;
    const currentVintagesCount = (formValues.Vintages || []).length;
    const originalVintagesArray = originalData.Vintages || [];
    const currentVintagesArray = formValues.Vintages || [];

    const vintageCountChanged = originalVintagesCount !== currentVintagesCount;
    const vintageContentChanged = JSON.stringify(originalVintagesArray) !== JSON.stringify(currentVintagesArray);
    const vintagesChanged = vintageCountChanged || vintageContentChanged;

    if (vintagesChanged) {
      console.log(`🔥 VINTAGES CHANGED: Count ${originalVintagesCount} -> ${currentVintagesCount}, Content: ${vintageContentChanged}`);
      console.log("Original:", originalVintagesArray);
      console.log("Current:", currentVintagesArray);
    }

    const hasFormChanges = sdgChanged || vintagesChanged || Object.keys(originalData).some(key => {
      if (key === "SDGs") {
        // Already handled above
        return false;
      }
      if (key === "ProjectOwner") {
        const originalOwner = originalData[key] || {};
        const currentOwner = formValues[key] || {};
        return Object.keys(originalOwner).some(ownerKey =>
          originalOwner[ownerKey] !== currentOwner[ownerKey]
        );
      }
      if (key === "Vintages") {
        const originalVintages = originalData[key] || [];
        const currentVintages = formValues[key] || [];

        // Check length first (catches deletions/additions)
        if (originalVintages.length !== currentVintages.length) {
          return true;
        }

        // Then check content
        return JSON.stringify(originalVintages) !== JSON.stringify(currentVintages);
      }
      // Handle null/undefined comparisons properly
      const originalValue = originalData[key];
      const currentValue = formValues[key];

      if (key === "DefaultCarbonPricePerTon") {
        // Only compare default price if no current vintages
        const currentVintages = formValues.Vintages || [];
        const originalVintages = originalData.Vintages || [];

        // If we had vintages before but don't now, treat as a change
        if (originalVintages.length > 0 && currentVintages.length === 0) {
          return true;
        }

        // If no current vintages, compare default price
        if (currentVintages.length === 0) {
          return originalValue !== currentValue;
        }

        return false; // Ignore default price changes when vintages exist
      }

      if (originalValue === null || originalValue === undefined) {
        return currentValue !== null && currentValue !== undefined && currentValue !== "";
      }
      if (currentValue === null || currentValue === undefined) {
        return originalValue !== null && originalValue !== undefined && originalValue !== "";
      }

      return originalValue !== currentValue;
    });

    // Check for image/document changes
    const hasFileChanges = projectImage?.isExisting === false ||
      projectGallery.some(img => !img.isExisting) ||
      documents.some(doc => !doc.isExisting) ||
      (originalData.projectImage && !projectImage) ||
      projectGallery.length !== currentProjectImages.length ||
      documents.length !== currentProjectDocuments.length;

    setHasChanges(hasFormChanges || hasFileChanges);
  }, [formValues, originalData, selectedSDGs, projectImage, projectGallery, documents, currentProjectImages, currentProjectDocuments, vintageFields, changeCounter]);

  const onSubmit = async (data) => {
    try {
      setLoading(true);

      // Add validation for SDGs
      if (selectedSDGs.length === 0) {
        toast.error("Please select at least one SDG");
        setLoading(false);
        return;
      }

      // Build update payload with only changed data
      const updatePayload = {};

      // Handle SDGs from state
      const originalSDGNames = originalData.SDGs || [];
      const currentSDGNames = selectedSDGs.map(sdg => sdg.label);

      if (JSON.stringify(originalSDGNames.sort()) !== JSON.stringify(currentSDGNames.sort())) {
        updatePayload.SDGs = currentSDGNames;
      }

      // Handle pricing logic: vintages OR default price (not both)
      const currentVintages = data.Vintages || [];
      const originalVintages = originalData.Vintages || [];

      // Check if vintages changed (including going from something to empty)
      const vintagesChanged = JSON.stringify(originalVintages) !== JSON.stringify(currentVintages);

      if (vintagesChanged) {
        // Always send vintages if they changed (even if empty to clear them)
        updatePayload.Vintages = currentVintages;
        console.log(`🔥 VINTAGES CHANGED: ${originalVintages.length} -> ${currentVintages.length}`);
      }

      // If we now have NO vintages, also send default price
      if (currentVintages.length === 0) {
        const originalPrice = originalData.DefaultCarbonPricePerTon;
        const currentPrice = data.DefaultCarbonPricePerTon;

        // If we went from vintages to no vintages, or price changed
        if (originalVintages.length > 0 || originalPrice !== currentPrice) {
          updatePayload.DefaultCarbonPricePerTon = currentPrice;
          console.log(`🔥 SWITCHING TO DEFAULT PRICE: ${currentPrice}`);
        }
      }

      // Map other form fields to API expected field names and check for changes
      const fieldMapping = {
        ProjectName: 'ProjectName',
        Description: 'Description',
        ProjectKind: 'ProjectKind',
        Country: 'Country',
        CountryISOCode: 'CountryISOCode',
        Latitude: 'Latitude',
        Longitude: 'Longitude',
        ProjectStatus: 'ProjectStatus',
        AvailableStock: 'AvailableStock',
        MinimumPurchaseAmount: 'MinimumPurchaseAmount',
        StandardType: 'StandardType',
        Registry: 'Registry',
        Mechanism: 'Mechanism',
        ProjectType: 'ProjectType',
        ProjectImpact: 'ProjectImpact'
      };

      // Check each field for changes
      Object.keys(fieldMapping).forEach(formKey => {
        const apiKey = fieldMapping[formKey];
        const originalValue = originalData[formKey];
        const currentValue = data[formKey];

        if (originalValue !== currentValue) {
          updatePayload[apiKey] = currentValue;
        }
      });

      // Handle ProjectOwner changes (but API might not accept this in edit)
      if (originalData.ProjectOwner) {
        const originalOwner = originalData.ProjectOwner || {};
        const currentOwner = data.ProjectOwner || {};

        const changedOwnerFields = {};
        Object.keys(currentOwner).forEach(ownerKey => {
          if (originalOwner[ownerKey] !== currentOwner[ownerKey]) {
            changedOwnerFields[ownerKey] = currentOwner[ownerKey];
          }
        });

        if (Object.keys(changedOwnerFields).length > 0) {
          updatePayload.ProjectOwner = changedOwnerFields;
        }
      }

      // Check for file changes
      const hasNewProjectImage = projectImage && !projectImage.isExisting;
      const hasGalleryChanges = projectGallery.some(img => !img.isExisting) ||
                                projectGallery.length !== currentProjectImages.length;
      const hasDocumentChanges = documents.some(doc => !doc.isExisting) ||
                                 documents.length !== currentProjectDocuments.length;

      // Handle gallery changes - send URLs for existing items
      if (hasGalleryChanges) {
        const galleryUrls = projectGallery
          .filter(img => img.isExisting)
          .map(img => img.url);
        updatePayload.ProjectGallery = galleryUrls;
      }

      // Handle document changes - send URLs for existing items
      if (hasDocumentChanges) {
        const documentUrls = documents
          .filter(doc => doc.isExisting)
          .map(doc => ({ url: doc.url, name: doc.name }));
        updatePayload.Documents = documentUrls;
      }

      console.log("Changed fields:", Object.keys(updatePayload));
      console.log("Has new files:", { hasNewProjectImage, hasGalleryChanges, hasDocumentChanges });
      console.log("Update payload:", updatePayload);

      // Ensure we have changes to send
      const hasDataChanges = Object.keys(updatePayload).length > 0;
      const hasFileChanges = hasNewProjectImage ||
                            projectGallery.some(img => !img.isExisting) ||
                            documents.some(doc => !doc.isExisting);

      if (!hasDataChanges && !hasFileChanges) {
        toast.error("No changes detected");
        setLoading(false);
        return;
      }

      let result;

      // If we have new files, use FormData; otherwise use JSON
      if (hasFileChanges) {
        const formData = new FormData();

        // Add all update data as JSON string or individual fields
        Object.keys(updatePayload).forEach(key => {
          if (Array.isArray(updatePayload[key]) || typeof updatePayload[key] === 'object') {
            formData.append(key, JSON.stringify(updatePayload[key]));
          } else {
            formData.append(key, updatePayload[key].toString());
          }
        });

        // Add new files
        if (hasNewProjectImage) {
          formData.append('ProjectImage', projectImage.file);
        }

        // Add new gallery images
        projectGallery.filter(img => !img.isExisting).forEach((image, index) => {
          formData.append('ProjectGallery', image.file);
        });

        // Add new documents
        documents.filter(doc => !doc.isExisting).forEach((doc, index) => {
          formData.append('Documents', doc.file);
        });

        console.log("Sending FormData with files");
        result = await projectsService.updateProject(projectId, formData);
      } else {
        // Pure JSON update - no new files
        console.log("Sending JSON update");
        result = await projectsService.updateProjectJSON(projectId, updatePayload);
      }

      if (result.success) {
        toast.success(result.message || "Project updated successfully!");
        setTimeout(() => {
          router.push("/admin/projects");
        }, 1000);
      } else {
        throw new Error(result.message || "Update failed");
      }
    } catch (error) {
      console.error("Update error:", error);
      toast.error(`Failed to update project: ${error.message || 'Please try again.'}`);
    } finally {
      setLoading(false);
    }
  };

  if (initialLoading) {
    return (
      <div className="flex items-center justify-center h-32">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#7CE495] mx-auto mb-4"></div>
          <p className="text-gray-600">Loading project data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-balance">Edit Project</h1>
          <p className="text-muted-foreground">
            Update project information and settings
          </p>
        </div>
      </div>

      <div className="bg-white rounded-lg border shadow-sm">
        <div className="p-6">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-[#2B5A3E] mb-2">Edit Project</h1>
            <p className="text-gray-600">Update project information and settings</p>
          </div>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">

            {/* 1 - Project Owner Information */}
            <div>
              <h2 className="text-lg font-semibold text-[#2B5A3E] mb-6 flex items-center">
                <span className="bg-[#7CE495] text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mx-2">
                  1
                </span>
                Project Owner Information
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                    First Name *
                  </label>
                  <input
                    type="text"
                    placeholder="First name"
                    value={projectData?.user?.FirstName || projectData?.ProjectOwner?.firstName || projectData?.ProjectOwner?.FirstName || ""}
                    readOnly
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg bg-gray-100 text-gray-600 cursor-not-allowed"
                  />
                  <ErrorMessage message={errors.ProjectOwner?.firstName?.message} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                    Last Name *
                  </label>
                  <input
                    type="text"
                    placeholder="Last name"
                    value={projectData?.user?.LastName || projectData?.ProjectOwner?.lastName || projectData?.ProjectOwner?.LastName || ""}
                    readOnly
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg bg-gray-100 text-gray-600 cursor-not-allowed"
                  />
                  <ErrorMessage message={errors.ProjectOwner?.lastName?.message} />
                </div>
              </div>

              <div className="mb-4">
                <div>
                  <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                    Company Name *
                  </label>
                  <input
                    type="text"
                    placeholder="Company name"
                    value={projectData?.user?.CompanyName || projectData?.ProjectOwner?.CompanyName || ""}
                    readOnly
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg bg-gray-100 text-gray-600 cursor-not-allowed"
                  />
                  <ErrorMessage message={errors.ProjectOwner?.CompanyName?.message} />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                <div>
                  <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                    Email *
                  </label>
                  <input
                    type="email"
                    placeholder="Email address"
                    value={projectData?.user?.Email || projectData?.ProjectOwner?.Email || ""}
                    readOnly
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg bg-gray-100 text-gray-600 cursor-not-allowed"
                  />
                  <ErrorMessage message={errors.ProjectOwner?.Email?.message} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                    Phone Number *
                  </label>
                  <input
                    type="tel"
                    placeholder="Phone number"
                    value={projectData?.user?.PhoneNumber || projectData?.ProjectOwner?.PhoneNumber || ""}
                    readOnly
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg bg-gray-100 text-gray-600 cursor-not-allowed"
                  />
                  <ErrorMessage message={errors.ProjectOwner?.PhoneNumber?.message} />
                </div>
              </div>
            </div>

            {/* 2 - Basic Project Information */}
            <div>
              <h2 className="text-lg font-semibold text-[#2B5A3E] mb-6 flex items-center">
                <span className="bg-[#7CE495] text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mx-2">
                  2
                </span>
                Basic Project Information
              </h2>

              <div className="mb-4">
                <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                  Project Name *
                </label>
                <input
                  {...register("ProjectName")}
                  type="text"
                  placeholder="Enter project name"
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all bg-gray-50"
                />
                <ErrorMessage message={errors.ProjectName?.message} />
              </div>

              <div className="mb-4">
                <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                  Description *
                </label>
                <textarea
                  {...register("Description")}
                  rows={4}
                  placeholder="Detailed description of the project"
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all bg-gray-50"
                />
                <ErrorMessage message={errors.Description?.message} />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                <div>
                  <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                    Project Kind *
                  </label>
                  <Controller
                    name="ProjectKind"
                    control={control}
                    render={({ field }) => (
                      <div className="relative">
                        <select
                          {...field}
                          className="w-full px-10 py-3 bg-[#F2F7F2] border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all appearance-none font-medium text-[#2B5A3E]"
                        >
                          <option value="">Select Project Kind</option>
                          {projectKinds.map((kind) => (
                            <option key={kind.value} value={kind.value}>
                              {kind.label}
                            </option>
                          ))}
                        </select>
                        <ChevronDown className="absolute right-4 top-1/2 transform -translate-y-1/2 text-[#7CE495] pointer-events-none h-4 w-4" />
                      </div>
                    )}
                  />
                  <ErrorMessage message={errors.ProjectKind?.message} />
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                    Country *
                  </label>
                  <Controller
                    name="Country"
                    control={control}
                    render={({ field }) => (
                      <div className="relative">
                        <select
                          {...field}
                          className="w-full px-10 py-3 bg-[#F2F7F2] border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all appearance-none font-medium text-[#2B5A3E]"
                        >
                          <option value="">Select Country</option>
                          {Object.entries(countryGroups).map(([region, countries]) => (
                            <optgroup key={region} label={region}>
                              {countries.map((country) => (
                                <option key={country} value={country}>
                                  {country}
                                </option>
                              ))}
                            </optgroup>
                          ))}
                        </select>
                        <ChevronDown className="absolute right-4 top-1/2 transform -translate-y-1/2 text-[#7CE495] pointer-events-none h-4 w-4" />
                      </div>
                    )}
                  />
                  <ErrorMessage message={errors.Country?.message} />
                </div>
              </div>

              <div className="mb-4">
                <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                  Country ISO Code
                </label>
                <input
                  {...register("CountryISOCode")}
                  type="text"
                  placeholder="Auto-filled based on country"
                  readOnly
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg bg-gray-100 text-gray-600 cursor-not-allowed"
                />
                <p className="text-xs text-gray-500 mt-1">Automatically filled when country is selected</p>
              </div>

              {/* Interactive Map with Coordinates */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                  Project Location *
                </label>
                <div className="bg-gray-100 border border-gray-200 rounded-lg p-4">
                  <InteractiveMap
                    latitude={watch("Latitude")}
                    longitude={watch("Longitude")}
                    onLocationSelect={(lat, lng) => {
                      setValue("Latitude", lat);
                      setValue("Longitude", lng);
                    }}
                  />
                </div>
                <p className="text-sm text-gray-600 mt-2 mb-4">
                  <strong>Required:</strong> Click on the map to set the project coordinates.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                      Latitude *
                    </label>
                    <input
                      {...register("Latitude", { valueAsNumber: true })}
                      type="number"
                      step="any"
                      placeholder="Click on map to set latitude"
                      readOnly
                      className="w-full px-4 py-3 border border-gray-200 rounded-lg bg-gray-100 text-gray-600 cursor-not-allowed"
                    />
                    <ErrorMessage message={errors.Latitude?.message} />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                      Longitude *
                    </label>
                    <input
                      {...register("Longitude", { valueAsNumber: true })}
                      type="number"
                      step="any"
                      placeholder="Click on map to set longitude"
                      readOnly
                      className="w-full px-4 py-3 border border-gray-200 rounded-lg bg-gray-100 text-gray-600 cursor-not-allowed"
                    />
                    <ErrorMessage message={errors.Longitude?.message} />
                  </div>
                </div>
              </div>
            </div>

            {/* 3 - Project Standards & Pricing */}
            <div>
              <h2 className="text-lg font-semibold text-[#2B5A3E] mb-6 flex items-center">
                <span className="bg-[#7CE495] text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mx-2">
                  3
                </span>
                Standards & Settings
              </h2>

              {/* Vintages */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                  Vintages (Year & Price)
                </label>
                {vintageFields.map((field, index) => (
                  <div key={field.id} className="grid grid-cols-2 gap-4 mb-3 items-end">
                    <div>
                      <label className="block text-xs font-medium text-[#2B5A3E] mb-1">
                        Year
                      </label>
                      <input
                        {...register(`Vintages.${index}.Year`, { valueAsNumber: true })}
                        type="number"
                        placeholder="Year"
                        className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all bg-gray-50"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-[#2B5A3E] mb-1">
                        Price per tCO₂e (SAR)
                      </label>
                      <div className="flex gap-2 items-end">
                        <input
                          {...register(`Vintages.${index}.CarbonPricePerTon`, { valueAsNumber: true })}
                          type="number"
                          step="0.01"
                          min="0"
                          placeholder="0.00"
                          className="flex-1 px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all bg-gray-50"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            removeVintage(index);
                            forceChangeCheck();
                          }}
                          className="px-3 py-3 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        >
                          <Minus className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
                <button
                  type="button"
                  onClick={() => appendVintage({ Year: new Date().getFullYear(), CarbonPricePerTon: null })}
                  className="flex items-center text-[#7CE495] hover:text-[#6BD485] transition-colors"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add Vintage
                </button>
              </div>

              {/* Standard Type & Registry */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                <div>
                  <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                    Standard Type *
                  </label>
                  <Controller
                    name="StandardType"
                    control={control}
                    render={({ field }) => (
                      <div className="relative">
                        <select
                          {...field}
                          className="w-full px-10 py-3 bg-[#F2F7F2] border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all appearance-none font-medium text-[#2B5A3E]"
                        >
                          <option value="">Select Standard Type</option>
                          {standardTypes.map((standard) => (
                            <option key={standard.value} value={standard.value}>
                              {standard.label}
                            </option>
                          ))}
                        </select>
                        <ChevronDown className="absolute right-4 top-1/2 transform -translate-y-1/2 text-[#7CE495] pointer-events-none h-4 w-4" />
                      </div>
                    )}
                  />
                  <ErrorMessage message={errors.StandardType?.message} />
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                    Registry *
                  </label>
                  <Controller
                    name="Registry"
                    control={control}
                    render={({ field }) => (
                      <div className="relative">
                        <select
                          {...field}
                          className="w-full px-10 py-3 bg-[#F2F7F2] border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all appearance-none font-medium text-[#2B5A3E]"
                        >
                          <option value="">Select Registry</option>
                          {registries.map((registry) => (
                            <option key={registry.value} value={registry.value}>
                              {registry.label}
                            </option>
                          ))}
                        </select>
                        <ChevronDown className="absolute right-4 top-1/2 transform -translate-y-1/2 text-[#7CE495] pointer-events-none h-4 w-4" />
                      </div>
                    )}
                  />
                  <ErrorMessage message={errors.Registry?.message} />
                </div>
              </div>

              {/* Mechanism */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                  Mechanism *
                </label>
                <Controller
                  name="Mechanism"
                  control={control}
                  render={({ field }) => (
                    <div className="relative">
                      <select
                        {...field}
                        className="w-full px-10 py-3 bg-[#F2F7F2] border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all appearance-none font-medium text-[#2B5A3E]"
                      >
                        <option value="">Select Mechanism</option>
                        {mechanisms.map((mechanism) => (
                          <option key={mechanism.value} value={mechanism.value}>
                            {mechanism.label}
                          </option>
                        ))}
                      </select>
                      <ChevronDown className="absolute right-4 top-1/2 transform -translate-y-1/2 text-[#7CE495] pointer-events-none h-4 w-4" />
                    </div>
                  )}
                />
                <ErrorMessage message={errors.Mechanism?.message} />
              </div>

              {/* Status */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                  Project Status
                </label>
                <Controller
                  name="ProjectStatus"
                  control={control}
                  render={({ field }) => (
                    <div className="relative">
                      <select
                        {...field}
                        className="w-full px-10 py-3 bg-[#F2F7F2] border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all appearance-none font-medium text-[#2B5A3E]"
                      >
                        {statusOptions.map((status) => (
                          <option key={status.value} value={status.value}>
                            {status.label}
                          </option>
                        ))}
                      </select>
                      <ChevronDown className="absolute right-4 top-1/2 transform -translate-y-1/2 text-[#7CE495] pointer-events-none h-4 w-4" />
                    </div>
                  )}
                />
              </div>
            </div>

            {/* 4 - Stock & Availability */}
            <div>
              <h2 className="text-lg font-semibold text-[#2B5A3E] mb-6 flex items-center">
                <span className="bg-[#7CE495] text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mx-2">
                  4
                </span>
                Stock & Availability
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                <div>
                  <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                    Available Stock *
                  </label>
                  <input
                    {...register("AvailableStock", { valueAsNumber: true })}
                    type="number"
                    placeholder="Available stock units"
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all bg-gray-50"
                  />
                  <ErrorMessage message={errors.AvailableStock?.message} />
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                    Minimum Purchase Amount *
                  </label>
                  <input
                    {...register("MinimumPurchaseAmount", { valueAsNumber: true })}
                    type="number"
                    placeholder="Minimum purchase amount"
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all bg-gray-50"
                  />
                  <ErrorMessage message={errors.MinimumPurchaseAmount?.message} />
                </div>
              </div>

              {/* Default Carbon Price (only when no vintages) */}
              {vintages.length === 0 && (
                <div className="mb-6">
                  <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                    Default Carbon Price per tCO₂e (SAR) *
                  </label>
                  <input
                    {...register("DefaultCarbonPricePerTon", { valueAsNumber: true })}
                    type="number"
                    step="0.01"
                    min="0"
                    placeholder="0.00"
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all bg-gray-50"
                  />
                  <ErrorMessage message={errors.DefaultCarbonPricePerTon?.message} />
                  <p className="text-xs text-gray-500 mt-1">
                    This is the carbon price per tCO₂e for this project
                  </p>
                </div>
              )}
            </div>

            {/* 5 - Additional Information */}
            <div>
              <h2 className="text-lg font-semibold text-[#2B5A3E] mb-6 flex items-center">
                <span className="bg-[#7CE495] text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mx-2">
                  5
                </span>
                Additional Information
              </h2>

              {/* Project Type */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                  Project Type *
                </label>
                <Controller
                  name="ProjectType"
                  control={control}
                  render={({ field }) => (
                    <div className="relative">
                      <select
                        {...field}
                        className="w-full px-10 py-3 bg-[#F2F7F2] border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all appearance-none font-medium text-[#2B5A3E]"
                      >
                        <option value="">Select Project Type</option>
                        {projectTypes.map((type) => (
                          <option key={type.value} value={type.value}>
                            {type.label}
                          </option>
                        ))}
                      </select>
                      <ChevronDown className="absolute right-4 top-1/2 transform -translate-y-1/2 text-[#7CE495] pointer-events-none h-4 w-4" />
                    </div>
                  )}
                />
                <ErrorMessage message={errors.ProjectType?.message} />
              </div>

              {/* SDGs */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                  Sustainable Development Goals (SDGs) *
                </label>

                {/* SDG Dropdown */}
                <div className="mb-4">
                  <div className="relative">
                    <select
                      onChange={(e) => {
                        if (e.target.value) {
                          const selectedOption = sdgOptions.find(opt => opt.value === e.target.value);
                          if (selectedOption && !selectedSDGs.find(sdg => sdg.value === selectedOption.value)) {
                            setSelectedSDGs(prev => [...prev, selectedOption]);
                          }
                          e.target.value = ""; // Reset dropdown
                        }
                      }}
                      className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all appearance-none bg-white"
                    >
                      <option value="">Select SDG to add</option>
                      {sdgOptions
                        .filter(sdg => !selectedSDGs.find(selected => selected.value === sdg.value))
                        .map((sdg) => (
                          <option key={sdg.value} value={sdg.value}>
                            {sdg.label}
                          </option>
                        ))}
                    </select>
                    <ChevronDown className="absolute right-4 top-1/2 transform -translate-y-1/2 text-[#7CE495] pointer-events-none h-4 w-4" />
                  </div>
                </div>

                {/* Selected SDG Badges */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {selectedSDGs.map((sdg) => (
                    <div
                      key={sdg.value}
                      className="inline-flex items-center gap-2 bg-[#7CE495] text-white px-3 py-1 rounded-full text-sm font-medium"
                    >
                      <span>{sdg.label}</span>
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedSDGs(prev => prev.filter(s => s.value !== sdg.value));
                        }}
                        className="hover:bg-white hover:text-[#7CE495] rounded-full p-1 transition-colors"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </div>
                  ))}
                </div>

                {selectedSDGs.length === 0 && (
                  <p className="text-gray-500 text-sm italic mb-4">No SDGs selected yet. Please select at least one.</p>
                )}

                {selectedSDGs.length > 0 && (
                  <p className="text-gray-600 text-sm mb-4">
                    {selectedSDGs.length} SDG{selectedSDGs.length !== 1 ? 's' : ''} selected
                  </p>
                )}

                {selectedSDGs.length === 0 && (
                  <p className="text-red-500 text-sm mt-1">At least one SDG is required</p>
                )}
              </div>

              {/* Project Impact */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                  Project Impact *
                </label>
                <Controller
                  name="ProjectImpact"
                  control={control}
                  render={({ field }) => (
                    <div className="relative">
                      <select
                        {...field}
                        className="w-full px-10 py-3 bg-[#F2F7F2] border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all appearance-none font-medium text-[#2B5A3E]"
                      >
                        <option value="">Select Project Impact</option>
                        {projectImpacts.map((impact) => (
                          <option key={impact.value} value={impact.value}>
                            {impact.label}
                          </option>
                        ))}
                      </select>
                      <ChevronDown className="absolute right-4 top-1/2 transform -translate-y-1/2 text-[#7CE495] pointer-events-none h-4 w-4" />
                    </div>
                  )}
                />
                <ErrorMessage message={errors.ProjectImpact?.message} />
              </div>

              {/* File Uploads */}
              <div className="space-y-6">
                {/* Project Image */}
                <div>
                  <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                    Main Project Image
                  </label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                    {projectImage ? (
                      <div className="relative">
                        <img
                          src={projectImage.preview}
                          alt="Project preview"
                          className="mx-auto h-48 w-auto rounded-lg shadow-md"
                        />
                        <div className="mt-2 text-sm text-gray-600">
                          {projectImage.name || "Current image"}
                          {projectImage.isExisting && (
                            <span className="ml-2 text-blue-600">(Current)</span>
                          )}
                        </div>
                        <button
                          type="button"
                          onClick={removeProjectImage}
                          className="mt-2 text-red-600 hover:text-red-800 text-sm underline"
                        >
                          Remove image
                        </button>
                      </div>
                    ) : (
                      <div>
                        <Upload className="mx-auto h-12 w-12 text-gray-400" />
                        <div className="mt-2">
                          <label className="cursor-pointer">
                            <span className="text-[#7CE495] font-medium hover:text-[#2B5A3E]">
                              Click to upload
                            </span>
                            <span className="text-gray-500"> or drag and drop</span>
                            <input
                              type="file"
                              accept="image/*"
                              onChange={handleProjectImageChange}
                              className="hidden"
                            />
                          </label>
                        </div>
                        <p className="text-xs text-gray-500 mt-1">PNG, JPG, GIF up to 10MB</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Project Gallery */}
                <div>
                  <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                    Project Gallery (Multiple Images)
                  </label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6">
                    {projectGallery.length > 0 ? (
                      <div className="space-y-4">
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                          {projectGallery.map((image, index) => (
                            <div key={index} className="relative group">
                              <img
                                src={image.preview}
                                alt={`Gallery ${index + 1}`}
                                className="h-24 w-24 object-cover rounded-lg shadow-md"
                              />
                              <button
                                type="button"
                                onClick={() => removeGalleryImage(index)}
                                className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full h-6 w-6 flex items-center justify-center text-xs opacity-0 group-hover:opacity-100 transition-opacity"
                              >
                                ×
                              </button>
                              <div className="text-xs text-gray-600 mt-1 truncate">
                                {image.name || image.originalName}
                                {image.isExisting && (
                                  <span className="text-blue-600"> (Current)</span>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                        <div className="text-center">
                          <label className="cursor-pointer text-[#7CE495] font-medium hover:text-[#2B5A3E]">
                            Add more images
                            <input
                              type="file"
                              accept="image/*"
                              multiple
                              onChange={handleProjectGalleryChange}
                              className="hidden"
                            />
                          </label>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center">
                        <Upload className="mx-auto h-12 w-12 text-gray-400" />
                        <div className="mt-2">
                          <label className="cursor-pointer">
                            <span className="text-[#7CE495] font-medium hover:text-[#2B5A3E]">
                              Click to upload images
                            </span>
                            <span className="text-gray-500"> or drag and drop</span>
                            <input
                              type="file"
                              accept="image/*"
                              multiple
                              onChange={handleProjectGalleryChange}
                              className="hidden"
                            />
                          </label>
                        </div>
                        <p className="text-xs text-gray-500 mt-1">Multiple PNG, JPG, GIF files</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Documents */}
                <div>
                  <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                    Project Documents (Multiple Files)
                  </label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6">
                    {documents.length > 0 ? (
                      <div className="space-y-4">
                        <div className="space-y-2">
                          {documents.map((doc, index) => (
                            <div key={index} className="flex items-center justify-between bg-gray-50 p-3 rounded-lg">
                              <div className="flex items-center space-x-3">
                                <div className="h-8 w-8 bg-[#7CE495] rounded flex items-center justify-center">
                                  <span className="text-white text-xs font-bold">
                                    {doc.name?.split('.').pop()?.toUpperCase() || 'DOC'}
                                  </span>
                                </div>
                                <div>
                                  <div className="text-sm font-medium text-gray-900 truncate max-w-xs">
                                    {doc.name}
                                    {doc.isExisting && (
                                      <span className="ml-2 text-blue-600 text-xs">(Current)</span>
                                    )}
                                  </div>
                                  <div className="text-xs text-gray-500">
                                    {formatFileSize(doc.size || 0)}
                                  </div>
                                </div>
                              </div>
                              <div className="flex items-center space-x-2">
                                {doc.isExisting && doc.url && (
                                  <a
                                    href={doc.url}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="text-blue-600 hover:text-blue-800 text-sm"
                                  >
                                    <Download className="h-4 w-4" />
                                  </a>
                                )}
                                <button
                                  type="button"
                                  onClick={() => removeDocument(index)}
                                  className="text-red-600 hover:text-red-800 text-sm"
                                >
                                  Remove
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                        <div className="text-center">
                          <label className="cursor-pointer text-[#7CE495] font-medium hover:text-[#2B5A3E]">
                            Add more documents
                            <input
                              type="file"
                              multiple
                              onChange={handleDocumentsChange}
                              className="hidden"
                            />
                          </label>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center">
                        <Upload className="mx-auto h-12 w-12 text-gray-400" />
                        <div className="mt-2">
                          <label className="cursor-pointer">
                            <span className="text-[#7CE495] font-medium hover:text-[#2B5A3E]">
                              Click to upload documents
                            </span>
                            <span className="text-gray-500"> or drag and drop</span>
                            <input
                              type="file"
                              multiple
                              onChange={handleDocumentsChange}
                              className="hidden"
                            />
                          </label>
                        </div>
                        <p className="text-xs text-gray-500 mt-1">PDF, DOC, XLS, TXT files</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <div className="flex justify-center pt-4 space-x-4">
              <button
                type="button"
                onClick={() => router.push("/admin/projects")}
                className="flex-1 bg-gray-500 hover:bg-gray-600 text-white font-semibold py-4 px-6 rounded-2xl transition-all duration-200"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={loading || !hasChanges}
                className="flex-1 bg-[#7CE495] hover:bg-[#6BD485] text-white font-semibold py-4 px-6 rounded-2xl transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed text-lg shadow-lg flex items-center justify-center min-h-[56px]"
              >
                {loading ? (
                  <>
                    <Loader2 className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2" />
                    Updating Project...
                  </>
                ) : hasChanges ? (
                  "Update Project"
                ) : (
                  "No Changes to Save"
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default EditProjectFormWrapper;