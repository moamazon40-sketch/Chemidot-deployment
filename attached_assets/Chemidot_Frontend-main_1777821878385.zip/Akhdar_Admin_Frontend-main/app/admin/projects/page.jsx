"use client";

import { FilterBar } from "@/components/projects/filter-bar";
import { Button } from "@/components/ui/button";
import { Plus, Download } from "lucide-react";
import { ProjectsTable } from "@/components/projects/projects-table";
import { ProjectDetail } from "@/components/projects/project-detail";
import EditProjectFormWrapper from "./[id]/edit/page-wrapper";
import { useState, useRef, Suspense } from "react";
import { projectsService } from "@/services/api/projectsService";
import { toast } from "sonner";
import { useRouter, useSearchParams } from "next/navigation";

function AdminProjectsContent() {
  const [appliedFilters, setAppliedFilters] = useState(null);
  const [exportLoading, setExportLoading] = useState(false);
  const projectsTableRef = useRef();
  const router = useRouter();
  const searchParams = useSearchParams();
  const projectId = searchParams.get('id');
  const mode = searchParams.get('mode');

  console.log("Admin Projects - projectId:", projectId, "mode:", mode);

  const handleFiltersChange = (filters, shouldApply = false) => {
    console.log("handleFiltersChange called with:", { filters, shouldApply });
    if (shouldApply) {
      console.log("Applying filters in page:", filters);
      setAppliedFilters(filters);
      // Trigger table refresh with new filters
      if (projectsTableRef.current?.applyFilters) {
        projectsTableRef.current.applyFilters(filters);
      }
    }
  };

  const handleExport = async () => {
    try {
      setExportLoading(true);
      console.log("Exporting with filters:", appliedFilters);

      await projectsService.exportProjects({
        pageNumber: 1,
        pageSize: 1000, // Export more records
        filters: appliedFilters
      });

      toast.success("Projects exported successfully!");
    } catch (error) {
      console.error("Export failed:", error);
      toast.error("Failed to export projects. Please try again.");
    } finally {
      setExportLoading(false);
    }
  };

  // If there's a project ID in query params, show project detail or edit
  if (projectId) {
    if (mode === 'edit') {
      return <EditProjectFormWrapper projectId={projectId} />;
    }
    return <ProjectDetail projectId={projectId} />;
  }

  // Otherwise show the projects table
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-balance">Projects</h1>
          <p className="text-muted-foreground">
            Manage carbon credit projects and submissions
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-2">
          <Button
            variant="outline"
            onClick={handleExport}
            disabled={exportLoading}
          >
            <Download className="h-4 w-4 mr-2" />
            {exportLoading ? "Exporting..." : "Export"}
          </Button>

          <Button onClick={() => router.push('/add-project')}>
            <Plus className="h-4 w-4 mr-2" />
            Add Project
          </Button>
        </div>
      </div>

      <FilterBar onFiltersChange={handleFiltersChange} />
      <ProjectsTable ref={projectsTableRef} appliedFilters={appliedFilters} />
    </div>
  );
}

export default function AdminProjectsPage() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <AdminProjectsContent />
    </Suspense>
  );
}
