import RequireAuth from "@/components/auth/RequireAuth";
import { AdminLayout } from "@/components/layout/admin-layout";

export const metadata = {
  title: "Akhdar Portal",
};

export default function AdminLayoutWrapper({ children }) {
  return (
    <RequireAuth>
      <AdminLayout>{children}</AdminLayout>
    </RequireAuth>
  );
}
