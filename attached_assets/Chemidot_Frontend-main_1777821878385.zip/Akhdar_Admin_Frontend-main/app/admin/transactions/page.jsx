"use client";

import { TransactionFilters } from "@/components/transactions/transaction-filters";
import { TransactionsTable } from "@/components/transactions/transactions-table";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import { useState, useRef } from "react";
import { transactionsService } from "@/services/api/transactionsService";
import { toast } from "sonner";

export default function AdminTransactionsPage() {
  const [appliedFilters, setAppliedFilters] = useState(null);
  const [exportLoading, setExportLoading] = useState(false);
  const transactionsTableRef = useRef();

  const handleFiltersChange = (filters, shouldApply = false) => {
    console.log("handleFiltersChange called with:", { filters, shouldApply });
    if (shouldApply) {
      console.log("Applying transaction filters in page:", filters);
      setAppliedFilters(filters);
      // Trigger table refresh with new filters
      if (transactionsTableRef.current?.applyFilters) {
        transactionsTableRef.current.applyFilters(filters);
      }
    }
  };

  const handleExport = async () => {
    try {
      setExportLoading(true);
      console.log("Exporting transactions with filters:", appliedFilters);

      await transactionsService.exportTransactions({
        pageNumber: 1,
        pageSize: 1000, // Export more records
        filters: appliedFilters
      });

      toast.success("Transactions exported successfully!");
    } catch (error) {
      console.error("Export failed:", error);
      toast.error("Failed to export transactions. Please try again.");
    } finally {
      setExportLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-balance">Transactions</h1>
          <p className="text-muted-foreground">
            Monitor and manage all carbon credit transactions
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-2">
          <Button
            variant="outline"
            onClick={handleExport}
            disabled={exportLoading}
          >
            <Download className="h-4 w-4 mr-2" />
            {exportLoading ? "Exporting..." : "Export Transactions"}
          </Button>
        </div>
      </div>

      <TransactionFilters onFiltersChange={handleFiltersChange} />

      <TransactionsTable ref={transactionsTableRef} appliedFilters={appliedFilters} />
    </div>
  );
}
