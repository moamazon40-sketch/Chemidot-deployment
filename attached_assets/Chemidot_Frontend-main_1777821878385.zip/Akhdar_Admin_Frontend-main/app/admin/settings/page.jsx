"use client";

import { UnifiedProfileSettings } from "@/components/settings/unified-profile-settings";

export default function AdminSettingsPage() {
  return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-balance">
            Settings
          </h1>
          <p className="text-muted-foreground">
            Manage your profile settings and account security
          </p>
        </div>

        <UnifiedProfileSettings />
      </div>
  );
}
