import { GeistSans } from "geist/font/sans";
import { GeistMono } from "geist/font/mono";
import { Analytics } from "@vercel/analytics/next";
import { Toaster } from "sonner";
import "./globals.css";
import ReduxProvider from "../components/providers/ReduxProvider";
import TemporaryPasswordProtection from "../components/auth/TemporaryPasswordProtection";
export const metadata = {
  title: "Akhdar Portal",
  description: "Akhdar Environmental Platform",
  icons: {
    icon: "/favicon.ico",
  },
};
export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className={`font-sans ${GeistSans.variable} ${GeistMono.variable}`}>
        <ReduxProvider>
          <TemporaryPasswordProtection>
            {children}
          </TemporaryPasswordProtection>
          <Toaster position="top-right" />
        </ReduxProvider>
        <Analytics />
      </body>
    </html>
  );
}
