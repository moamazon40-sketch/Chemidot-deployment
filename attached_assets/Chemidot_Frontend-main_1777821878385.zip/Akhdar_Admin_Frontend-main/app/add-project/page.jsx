"use client";

import React, { useState, useEffect } from "react";
import { useForm, Controller, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Eye, EyeOff, ChevronDown, Plus, Minus, Upload } from "lucide-react";
import { useSelector } from "react-redux";
// Countries grouped by region
const countryGroups = {
  "Asia": [
    "Bangladesh", "Cambodia", "China", "India", "Indonesia", "KSA", "Myanmar", "Thailand", "Turkey", "Vietnam"
  ],
  "Africa": [
    "Congo, the Democratic Republic of the", "Egypt", "Kenya", "Malawi", "Mozambique", "Rwanda", "Sierra Leone", "South Africa", "Uganda", "Zambia"
  ],
  "North America": [
    "Antigua and Barbuda", "Canada", "Dominican Republic", "El Salvador", "Mexico", "United States of America"
  ],
  "South America": [
    "Argentina", "Brazil", "Chile", "Colombia", "Peru"
  ],
  "Europe": [
    "Germany", "Iceland", "Italy", "Romania", "Spain", "Switzerland", "Ukraine"
  ]
};

// Country to Alpha-2 ISO code mapping
const countryISOMap = {
  "Bangladesh": "BD",
  "Cambodia": "KH",
  "China": "CN",
  "India": "IN",
  "Indonesia": "ID",
  "KSA": "SA",
  "Myanmar": "MM",
  "Thailand": "TH",
  "Turkey": "TR",
  "Vietnam": "VN",
  "Congo, the Democratic Republic of the": "CD",
  "Egypt": "EG",
  "Kenya": "KE",
  "Malawi": "MW",
  "Mozambique": "MZ",
  "Rwanda": "RW",
  "Sierra Leone": "SL",
  "South Africa": "ZA",
  "Uganda": "UG",
  "Zambia": "ZM",
  "Antigua and Barbuda": "AG",
  "Canada": "CA",
  "Dominican Republic": "DO",
  "El Salvador": "SV",
  "Mexico": "MX",
  "United States of America": "US",
  "Argentina": "AR",
  "Brazil": "BR",
  "Chile": "CL",
  "Colombia": "CO",
  "Peru": "PE",
  "Germany": "DE",
  "Iceland": "IS",
  "Italy": "IT",
  "Romania": "RO",
  "Spain": "ES",
  "Switzerland": "CH",
  "Ukraine": "UA"
};
import { toast, Toaster } from "sonner";
import { apiInstance } from "@/services/api/apiInstance";
import { AdminGetCurrentUserProfile } from "@/services/auth/authService";

const projectKinds = [
  { value: "Carbon Removal", label: "Carbon Removal" },
  { value: "Avoidance", label: "Avoidance" },
  { value: "Reduction", label: "Reduction" },
  { value: "Sequestration", label: "Sequestration" },
];

const standardTypes = [
  { value: "CDM Standard", label: "CDM Standard" },
  { value: "VCS", label: "VCS" },
  { value: "Isometric Standard", label: "Isometric Standard" },
  { value: "Gold Standard", label: "Gold Standard" },
  { value: "CerCarbono", label: "CerCarbono" },
  { value: "Puro Standard", label: "Puro Standard" },
  { value: "ICR Standard", label: "ICR Standard" },
  { value: "MITECO", label: "MITECO" },
  { value: "City Forest Credits", label: "City Forest Credits" },
  { value: "CAR Standard", label: "CAR Standard" },
  { value: "ACR Standard", label: "ACR Standard" },
  { value: "Trinity Natural Capital Markets", label: "Trinity Natural Capital Markets" },
  { value: "ISO 14064-2", label: "ISO 14064-2" },
  { value: "Hemp Carbon Standard", label: "Hemp Carbon Standard" },
  { value: "Regen Standard (Regenerative Standard)", label: "Regen Standard (Regenerative Standard)" },
  { value: "Biotrust", label: "Biotrust" },
  { value: "ACR", label: "ACR" },
  { value: "BCR Standard", label: "BCR Standard" },
];

const registries = [
  { value: "CDM Registry", label: "CDM Registry" },
  { value: "Non registered", label: "Non registered" },
  { value: "Verra Registry", label: "Verra Registry" },
  { value: "Isometric Registry", label: "Isometric Registry" },
  { value: "GSF Registry", label: "GSF Registry" },
  { value: "EcoRegistry", label: "EcoRegistry" },
  { value: "Puro Registry", label: "Puro Registry" },
  { value: "ICR (International Carbon Registry)", label: "ICR (International Carbon Registry)" },
  { value: "MITECO", label: "MITECO" },
  { value: "City Forest Registry", label: "City Forest Registry" },
  { value: "The Reserve", label: "The Reserve" },
  { value: "Evident", label: "Evident" },
  { value: "ACR", label: "ACR" },
  { value: "Trinity Natural Capital Markets Registry", label: "Trinity Natural Capital Markets Registry" },
  { value: "Pina.Earth", label: "Pina.Earth" },
  { value: "Trusted Carbon", label: "Trusted Carbon" },
  { value: "Regen Standard (Regenerative Standard)", label: "Regen Standard (Regenerative Standard)" },
  { value: "BioTrust", label: "BioTrust" },
  { value: "BioCarbon Registry", label: "BioCarbon Registry" },
  { value: "630::The Reserve::The Reserve", label: "630::The Reserve::The Reserve" },
  { value: "629::BioCarbon Registry::BioCarbon Registry", label: "629::BioCarbon Registry::BioCarbon Registry" },
  { value: "636::Verra Registry::Verra Registry", label: "636::Verra Registry::Verra Registry" },
  { value: "632::EcoRegistry::EcoRegistry", label: "632::EcoRegistry::EcoRegistry" },
  { value: "634::GSF Registry::GSF Registry", label: "634::GSF Registry::GSF Registry" },
  { value: "633::GCC Registry::GCC Registry", label: "633::GCC Registry::GCC Registry" },
];

const mechanisms = [
  { value: "Avoidance", label: "Avoidance" },
  { value: "Removal", label: "Removal" },
];

const sdgOptions = [
  { value: "1. No poverty", label: "1. No poverty" },
  { value: "2. Zero hunger", label: "2. Zero hunger" },
  { value: "3. Good health and well-being", label: "3. Good health and well-being" },
  { value: "4. Quality Education", label: "4. Quality Education" },
  { value: "5. Gender Equality", label: "5. Gender Equality" },
  { value: "6. Clean water and sanitation", label: "6. Clean water and sanitation" },
  { value: "7. Affordable and clean energy", label: "7. Affordable and clean energy" },
  { value: "8. Decent work and economic growth", label: "8. Decent work and economic growth" },
  { value: "9. Industry, innovation and infrastructure", label: "9. Industry, innovation and infrastructure" },
  { value: "10. Reduced inequalities", label: "10. Reduced inequalities" },
  { value: "11. Sustainable cities and communities", label: "11. Sustainable cities and communities" },
  { value: "12. Responsible consumption and production", label: "12. Responsible consumption and production" },
  { value: "13. Climate action", label: "13. Climate action" },
  { value: "14. Life below water", label: "14. Life below water" },
  { value: "15. Life on land", label: "15. Life on land" },
  { value: "16. Peace, justice and strong institution", label: "16. Peace, justice and strong institution" },
  { value: "17. Partnerships for the goals", label: "17. Partnerships for the goals" },
];

const projectTypes = [
  { value: "Sustainable Agriculture", label: "Sustainable Agriculture" },
  { value: "Afforestation, Reforestation & Revegetation (ARR)", label: "Afforestation, Reforestation & Revegetation (ARR)" },
  { value: "Improved Forest Management (IFM)", label: "Improved Forest Management (IFM)" },
  { value: "Agroforestry", label: "Agroforestry" },
  { value: "Regenerative Agriculture", label: "Regenerative Agriculture" },
  { value: "Forestry Management - MX", label: "Forestry Management - MX" },
  { value: "Livestock Methane Reduction", label: "Livestock Methane Reduction" },
  { value: "REDD+ (Reducing Emissions from Deforestation and Forest Degradation)", label: "REDD+ (Reducing Emissions from Deforestation and Forest Degradation)" },
];

const projectImpacts = [
  { value: "Avoid Deforestation", label: "Avoid Deforestation" },
  { value: "Change Lives", label: "Change Lives" },
  { value: "Displace Harmful Fuels", label: "Displace Harmful Fuels" },
  { value: "Eliminate Poverty", label: "Eliminate Poverty" },
  { value: "Employment Opportunities", label: "Employment Opportunities" },
  { value: "Promote Gender Equality", label: "Promote Gender Equality" },
  { value: "Protect Biodiversity", label: "Protect Biodiversity" },
  { value: "Protect the Planet", label: "Protect the Planet" },
  { value: "Protect Wildlife", label: "Protect Wildlife" },
  { value: "Regional Economic Development", label: "Regional Economic Development" },
  { value: "Remove CO2 from the Atmosphere", label: "Remove CO2 from the Atmosphere" },
  { value: "Save Forests", label: "Save Forests" },
];



const projectSchema = z.object({
  ProjectName: z.string().min(1, "Project name is required"),
  Description: z.string().min(1, "Description is required"),
  ProjectKind: z.string().min(1, "Project kind is required"),
  Country: z.string().min(1, "Country is required"),
  CountryISOCode: z.string().min(1, "Country ISO code is required"),
  Latitude: z.number().min(-90).max(90, "Valid latitude required"),
  Longitude: z.number().min(-180).max(180, "Valid longitude required"),
  Vintages: z.array(z.object({
    Year: z.number().min(1900, "Valid year required")
  })).optional(),
  AvailableStock: z.number().min(1, "Available stock must be at least 1"),
  MinimumPurchaseAmount: z.number().min(1, "Minimum purchase amount must be at least 1"),
  StandardType: z.string().min(1, "Standard type is required"),
  Registry: z.string().min(1, "Registry is required"),
  Mechanism: z.string().min(1, "Mechanism is required"),
  ProjectOwner: z.object({
    firstName: z.string().min(1, "First name is required"),
    lastName: z.string().min(1, "Last name is required"),
    CompanyName: z.string().min(1, "Company name is required"),
    Email: z.string().email("Valid email required"),
    PhoneNumber: z.string().min(1, "Phone number is required")
  }),
  SDGs: z.array(z.string()).min(1, "At least one SDG is required"),
  ProjectType: z.string().min(1, "Project type is required"),
  ProjectImpact: z.string().min(1, "Project impact is required"),
  ProjectImage: z.any().optional(),
  ProjectGallery: z.array(z.any()).optional(),
  Documents: z.array(z.any()).optional(),
});

const ErrorMessage = ({ message }) => {
  if (!message) return null;
  return <div className="text-red-500 text-sm mt-1">{message}</div>;
};

// Real Interactive Map Component using Leaflet
const InteractiveMap = ({ latitude, longitude, onLocationSelect }) => {
  const mapRef = React.useRef(null);
  const mapInstanceRef = React.useRef(null);
  const markerRef = React.useRef(null);
  const [searchQuery, setSearchQuery] = React.useState('');
  const [searchResults, setSearchResults] = React.useState([]);
  const [isSearching, setIsSearching] = React.useState(false);

  const searchLocation = async (query) => {
    if (!query.trim()) {
      setSearchResults([]);
      return;
    }

    setIsSearching(true);
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=10`
      );
      const results = await response.json();
      setSearchResults(results);
    } catch (error) {
      console.error('Search error:', error);
      setSearchResults([]);
    } finally {
      setIsSearching(false);
    }
  };

  const handleSearchSelect = (result) => {
    const lat = parseFloat(result.lat);
    const lng = parseFloat(result.lon);

    if (mapInstanceRef.current) {
      // Remove existing marker
      if (markerRef.current) {
        mapInstanceRef.current.removeLayer(markerRef.current);
      }

      // Add new marker and center map
      markerRef.current = window.L.marker([lat, lng]).addTo(mapInstanceRef.current);
      mapInstanceRef.current.setView([lat, lng], 15);

      // Update coordinates
      onLocationSelect(lat, lng);
    }

    setSearchQuery(result.display_name);
    setSearchResults([]);
  };

  React.useEffect(() => {
    // Load Leaflet CSS and JS dynamically
    if (!document.querySelector('link[href*="leaflet"]')) {
      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
      document.head.appendChild(link);
    }

    if (!window.L) {
      const script = document.createElement('script');
      script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
      script.onload = () => initializeMap();
      document.head.appendChild(script);
    } else {
      initializeMap();
    }

    function initializeMap() {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
      }

      const map = window.L.map(mapRef.current).setView([latitude || 24.7136, longitude || 46.6753], latitude && longitude ? 10 : 6);

      window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
      }).addTo(map);

      // Add click event to map
      map.on('click', function(e) {
        const { lat, lng } = e.latlng;

        // Remove existing marker
        if (markerRef.current) {
          map.removeLayer(markerRef.current);
        }

        // Add new marker
        markerRef.current = window.L.marker([lat, lng]).addTo(map);

        // Update coordinates
        onLocationSelect(lat, lng);
      });

      // Add initial marker if coordinates exist
      if (latitude && longitude) {
        markerRef.current = window.L.marker([latitude, longitude]).addTo(map);
      }

      mapInstanceRef.current = map;
    }

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
      }
    };
  }, []);

  // Update marker when coordinates change
  React.useEffect(() => {
    if (mapInstanceRef.current && latitude && longitude) {
      if (markerRef.current) {
        mapInstanceRef.current.removeLayer(markerRef.current);
      }
      markerRef.current = window.L.marker([latitude, longitude]).addTo(mapInstanceRef.current);
      mapInstanceRef.current.setView([latitude, longitude], 10);
    }
  }, [latitude, longitude]);

  // Debounced search
  React.useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (searchQuery && searchQuery.length > 2) {
        searchLocation(searchQuery);
      }
    }, 500);

    return () => clearTimeout(timeoutId);
  }, [searchQuery]);

  return (
    <div className="relative w-full">
      {/* Search Box */}
      <div className="mb-3 relative">
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search for a location (e.g., New York, Paris, Tokyo)"
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none"
        />
        {isSearching && (
          <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-[#7CE495]"></div>
          </div>
        )}

        {/* Search Results Dropdown */}
        {searchResults.length > 0 && (
          <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-300 rounded-lg shadow-lg z-[2000] max-h-60 overflow-y-auto">
            {searchResults.map((result, index) => (
              <div
                key={index}
                onClick={() => handleSearchSelect(result)}
                className="px-4 py-2 hover:bg-gray-100 cursor-pointer border-b border-gray-100 last:border-b-0"
              >
                <div className="font-medium text-sm text-gray-900 truncate">
                  {result.display_name}
                </div>
                <div className="text-xs text-gray-500">
                  {result.type} • {result.lat}, {result.lon}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Map Container */}
      <div className="relative w-full h-64">
        <div ref={mapRef} className="w-full h-full rounded-lg overflow-hidden border border-gray-300"></div>
        <div className="absolute top-2 left-2 bg-white/90 px-2 py-1 rounded text-xs text-gray-600 z-[1000]">
          Click on the map or search above to set project location
        </div>
      </div>
    </div>
  );
};

const AddProjectForm = () => {
  const userData = useSelector((state) => state.user.userData);
  const [loading, setLoading] = useState(false);
  const [projectImage, setProjectImage] = useState(null);
  const [projectGallery, setProjectGallery] = useState([]);
  const [documents, setDocuments] = useState([]);

  const {
    register,
    handleSubmit,
    control,
    formState: { errors },
    reset,
    watch,
    setValue,
  } = useForm({
    resolver: zodResolver(projectSchema),
    defaultValues: {
      AvailableStock: 1,
      MinimumPurchaseAmount: 1,
      Latitude: null,
      Longitude: null,
      Vintages: [{ Year: new Date().getFullYear() }],
      SDGs: [],
      ProjectGallery: [],
      Documents: [],
    },
  });

  const { fields: vintageFields, append: appendVintage, remove: removeVintage } = useFieldArray({
    control,
    name: "Vintages"
  });

  const { fields: sdgFields, append: appendSDG, remove: removeSDG } = useFieldArray({
    control,
    name: "SDGs"
  });

  const country = watch("Country");

  // File upload handlers
  const handleProjectImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setProjectImage({
          file,
          preview: e.target.result,
          name: file.name
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleProjectGalleryChange = (e) => {
    const files = Array.from(e.target.files);
    const newImages = [];

    files.forEach((file) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        newImages.push({
          file,
          preview: e.target.result,
          name: file.name
        });
        if (newImages.length === files.length) {
          setProjectGallery([...projectGallery, ...newImages]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const handleDocumentsChange = (e) => {
    const files = Array.from(e.target.files);
    const newDocs = files.map(file => ({
      file,
      name: file.name,
      size: file.size,
      type: file.type
    }));
    setDocuments([...documents, ...newDocs]);
  };

  const removeProjectImage = () => {
    setProjectImage(null);
  };

  const removeGalleryImage = (index) => {
    setProjectGallery(projectGallery.filter((_, i) => i !== index));
  };

  const removeDocument = (index) => {
    setDocuments(documents.filter((_, i) => i !== index));
  };

  // Auto-set ISO code when country changes
  React.useEffect(() => {
    if (country) {
      const isoCode = countryISOMap[country] || "";
      setValue("CountryISOCode", isoCode);
    }
  }, [country, setValue]);

  // Pre-fill project owner data by fetching fresh user profile
  React.useEffect(() => {
    const fetchAndPreFillUserData = async () => {
      if (!userData?.token && !userData?.userObj) {
        console.log("No user token available for API call");
        return;
      }

      try {
        console.log("Fetching current user profile for pre-filling...");
        const response = await AdminGetCurrentUserProfile();
        console.log("AdminGetCurrentUserProfile response:", response);

        // Extract user data from API response
        if (response.data.success && response.data.user) {
          const user = response.data.user;
          console.log("📄 ADD PROJECT - User data from API:", user);

          // Map exactly as shown in your API response
          const ownerData = {
            firstName: user.firstName || "",        // "Thomas"
            lastName: user.lastName || "",          // "ashraf"
            Email: user.Email || "",              // "thomas.ashraf975+7878@gmail.com"
            PhoneNumber: user.PhoneNumber || "",   // "+201004160215"
            CompanyName: ""                       // Not in API, leave empty
          };

          console.log("✅ ADD PROJECT - Setting owner data:", ownerData);

          // Pre-fill form fields (only non-empty values)
          Object.keys(ownerData).forEach(key => {
            if (ownerData[key]) {
              setValue(`ProjectOwner.${key}`, ownerData[key]);
            }
          });

          console.log("✅ ADD PROJECT - Project owner data pre-filled!");
        } else {
          console.log("No user data found in API response");
        }
      } catch (error) {
        console.error("Error fetching user profile for pre-filling:", error);
        // Fallback to Redux userData if API fails
        if (userData) {
          const user = userData.user || userData;
          const fallbackData = {
            firstName: user.firstName || user.FirstName || "",
            lastName: user.lastName || user.LastName || "",
            Email: user.Email || "",
            PhoneNumber: user.PhoneNumber || ""
          };

          Object.keys(fallbackData).forEach(key => {
            if (fallbackData[key]) {
              setValue(`ProjectOwner.${key}`, fallbackData[key]);
            }
          });

          console.log("Used fallback pre-fill from Redux:", fallbackData);
        }
      }
    };

    fetchAndPreFillUserData();
  }, [userData, setValue]);

  const onSubmit = async (data) => {
    setLoading(true);

    // Validate required files
    if (!projectImage) {
      toast.error("Project image is required");
      setLoading(false);
      return;
    }

    if (projectGallery.length === 0) {
      toast.error("At least one gallery image is required");
      setLoading(false);
      return;
    }

    if (documents.length === 0) {
      toast.error("At least one document is required");
      setLoading(false);
      return;
    }

    try {
      const formData = new FormData();

      // Add all form fields with proper formatting
      Object.keys(data).forEach(key => {
        if (key === 'ProjectImage' || key === 'ProjectGallery' || key === 'Documents') {
          // Skip file fields as we'll add them from state
          return;
        } else if (key === 'Vintages') {
          // Format vintages as array of objects for API
          if (data[key] && data[key].length > 0) {
            formData.append(key, JSON.stringify(data[key]));
          }
        } else if (key === 'SDGs') {
          // Format SDGs as comma-separated numbers (extract number from "1. No poverty" format)
          if (data[key] && data[key].length > 0) {
            const sdgNumbers = data[key]
              .filter(sdg => sdg && typeof sdg === 'string' && sdg.trim() !== '')
              .map(sdg => sdg.split('.')[0]) // Extract number before the dot
              .join(',');
            if (sdgNumbers) {
              formData.append(key, sdgNumbers);
            } else {
              formData.append(key, ''); // Pass empty string if no valid SDGs
            }
          } else {
            formData.append(key, ''); // Pass empty string if no SDGs array
          }
        } else if (key === 'ProjectOwner') {
          // Format ProjectOwner as JSON string
          formData.append(key, JSON.stringify(data[key]));
        } else if (typeof data[key] === 'boolean') {
          // Convert booleans to strings
          formData.append(key, data[key].toString());
        } else if (data[key] !== undefined && data[key] !== null && data[key] !== '') {
          // Add other fields as strings
          formData.append(key, data[key].toString());
        }
      });

      // Add files from state
      if (projectImage) {
        formData.append('ProjectImage', projectImage.file);
      }

      if (projectGallery.length > 0) {
        projectGallery.forEach(image => {
          formData.append('ProjectGallery', image.file);
        });
      }

      if (documents.length > 0) {
        documents.forEach(doc => {
          formData.append('Documents', doc.file);
        });
      }

      // Debug: Log form data contents
      console.log('Submitting project with data:');
      for (let pair of formData.entries()) {
        console.log(pair[0], ':', pair[1]);
      }

      const response = await apiInstance.post("/AddProject", formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      if (response.status === 200 || response.status === 201) {
        toast.success("Project submitted successfully!", {
          position: "top-center",
        });
        // Reset form and clear file states
        reset();
        setProjectImage(null);
        setProjectGallery([]);
        setDocuments([]);
      } else {
        toast.error("Something went wrong. Please try again.", {
          position: "top-center",
        });
      }
    } catch (error) {
      console.error("Error submitting project:", error);
      console.error("Error response data:", error?.response?.data);
      console.error("Error response status:", error?.response?.status);
      console.error("Error response headers:", error?.response?.headers);

      let errorMsg = "Something went wrong. Please try again.";

      if (error?.response?.data?.error) {
        errorMsg = error.response.data.error;
      } else if (error?.response?.data?.message) {
        errorMsg = error.response.data.message;
      } else if (error?.response?.data) {
        // Try to extract any error message from the response data
        errorMsg = typeof error.response.data === 'string'
          ? error.response.data
          : JSON.stringify(error.response.data);
      } else if (error?.message) {
        errorMsg = error.message;
      }

      toast.error(errorMsg, { position: "top-center" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#f2f7f2] py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-[#2B5A3E] mb-2">Submit Your Project</h1>
            <p className="text-gray-600">Create a new carbon credit project submission</p>
          </div>

          <Toaster position="top-center" />
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">

            {/* 1 - Project Owner Information */}
            <div>
              <h2 className="text-lg font-semibold text-[#2B5A3E] mb-6 flex items-center">
                <span className="bg-[#7CE495] text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mx-2">
                  1
                </span>
                Project Owner Information
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                    First Name *
                  </label>
                  <input
                    {...register("ProjectOwner.firstName")}
                    type="text"
                    placeholder="First name"
                    autoComplete="given-name"
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all bg-gray-50"
                  />
                  <ErrorMessage message={errors.ProjectOwner?.firstName?.message} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                    Last Name *
                  </label>
                  <input
                    {...register("ProjectOwner.lastName")}
                    type="text"
                    placeholder="Last name"
                    autoComplete="family-name"
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all bg-gray-50"
                  />
                  <ErrorMessage message={errors.ProjectOwner?.lastName?.message} />
                </div>
              </div>

              <div className="mb-4">
                <div>
                  <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                    Company Name *
                  </label>
                  <input
                    {...register("ProjectOwner.CompanyName")}
                    type="text"
                    placeholder="Company name"
                    autoComplete="organization"
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all bg-gray-50"
                  />
                  <ErrorMessage message={errors.ProjectOwner?.CompanyName?.message} />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                <div>
                  <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                    Email *
                  </label>
                  <input
                    {...register("ProjectOwner.Email")}
                    type="email"
                    placeholder="Email address"
                    autoComplete="email"
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all bg-gray-50"
                  />
                  <ErrorMessage message={errors.ProjectOwner?.Email?.message} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                    Phone Number *
                  </label>
                  <input
                    {...register("ProjectOwner.PhoneNumber")}
                    type="tel"
                    placeholder="Phone number"
                    autoComplete="tel"
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all bg-gray-50"
                  />
                  <ErrorMessage message={errors.ProjectOwner?.PhoneNumber?.message} />
                </div>
              </div>
            </div>

            {/* 2 - Basic Project Information */}
            <div>
              <h2 className="text-lg font-semibold text-[#2B5A3E] mb-6 flex items-center">
                <span className="bg-[#7CE495] text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mx-2">
                  2
                </span>
                Basic Project Information
              </h2>

              {/* Project Name */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                  Project Name *
                </label>
                <input
                  {...register("ProjectName")}
                  type="text"
                  placeholder="Enter project name"
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all bg-gray-50"
                />
                <ErrorMessage message={errors.ProjectName?.message} />
              </div>

              {/* Description */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                  Description *
                </label>
                <textarea
                  {...register("Description")}
                  rows={4}
                  placeholder="Detailed description of the project"
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all bg-gray-50"
                />
                <ErrorMessage message={errors.Description?.message} />
              </div>

              {/* Project Kind & Country */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                <div>
                  <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                    Project Kind *
                  </label>
                  <Controller
                    name="ProjectKind"
                    control={control}
                    render={({ field }) => (
                      <div className="relative">
                        <select
                          {...field}
                          className="w-full px-10 py-3 bg-[#F2F7F2] border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all appearance-none font-medium text-[#2B5A3E]"
                        >
                          <option value="">Select Project Kind</option>
                          {projectKinds.map((kind) => (
                            <option key={kind.value} value={kind.value}>
                              {kind.label}
                            </option>
                          ))}
                        </select>
                        <ChevronDown className="absolute right-4 top-1/2 transform -translate-y-1/2 text-[#7CE495] pointer-events-none h-4 w-4" />
                      </div>
                    )}
                  />
                  <ErrorMessage message={errors.ProjectKind?.message} />
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                    Country *
                  </label>
                  <Controller
                    name="Country"
                    control={control}
                    render={({ field }) => (
                      <div className="relative">
                        <select
                          {...field}
                          className="w-full px-10 py-3 bg-[#F2F7F2] border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all appearance-none font-medium text-[#2B5A3E]"
                        >
                          <option value="">Select Country</option>
                          {Object.entries(countryGroups).map(([region, countries]) => (
                            <optgroup key={region} label={region}>
                              {countries.map((country) => (
                                <option key={country} value={country}>
                                  {country}
                                </option>
                              ))}
                            </optgroup>
                          ))}
                        </select>
                        <ChevronDown className="absolute right-4 top-1/2 transform -translate-y-1/2 text-[#7CE495] pointer-events-none h-4 w-4" />
                      </div>
                    )}
                  />
                  <ErrorMessage message={errors.Country?.message} />
                </div>
              </div>

              {/* Country ISO Code */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                  Country ISO Code
                </label>
                <input
                  {...register("CountryISOCode")}
                  type="text"
                  placeholder="Auto-filled based on country"
                  readOnly
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg bg-gray-100 text-gray-600 cursor-not-allowed"
                />
                <p className="text-xs text-gray-500 mt-1">Automatically filled when country is selected</p>
              </div>

              {/* Interactive Map with Coordinates */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                  Project Location *
                </label>
                <div className="bg-gray-100 border border-gray-200 rounded-lg p-4">
                  <InteractiveMap
                    latitude={watch("Latitude")}
                    longitude={watch("Longitude")}
                    onLocationSelect={(lat, lng) => {
                      setValue("Latitude", lat);
                      setValue("Longitude", lng);
                    }}
                  />
                </div>
                <p className="text-sm text-gray-600 mt-2 mb-4">
                  <strong>Required:</strong> Click on the map to set the project coordinates.
                </p>

                {/* Coordinates - Part of the map */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                      Latitude *
                    </label>
                    <input
                      {...register("Latitude", { valueAsNumber: true })}
                      type="number"
                      step="any"
                      placeholder="Click on map to set latitude"
                      readOnly
                      className="w-full px-4 py-3 border border-gray-200 rounded-lg bg-gray-100 text-gray-600 cursor-not-allowed"
                    />
                    <ErrorMessage message={errors.Latitude?.message} />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                      Longitude *
                    </label>
                    <input
                      {...register("Longitude", { valueAsNumber: true })}
                      type="number"
                      step="any"
                      placeholder="Click on map to set longitude"
                      readOnly
                      className="w-full px-4 py-3 border border-gray-200 rounded-lg bg-gray-100 text-gray-600 cursor-not-allowed"
                    />
                    <ErrorMessage message={errors.Longitude?.message} />
                  </div>
                </div>
              </div>
            </div>

            {/* 3 - Project Standards & Pricing */}
            <div>
              <h2 className="text-lg font-semibold text-[#2B5A3E] mb-6 flex items-center">
                <span className="bg-[#7CE495] text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mx-2">
                  3
                </span>
                Standards & Pricing
              </h2>

              {/* Vintages */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                  Vintages (Year)
                </label>
                {vintageFields.map((field, index) => (
                  <div key={field.id} className="flex gap-4 mb-3 items-end">
                    <div className="flex-1">
                      <input
                        {...register(`Vintages.${index}.Year`, { valueAsNumber: true })}
                        type="number"
                        placeholder="Year"
                        className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all bg-gray-50"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() => removeVintage(index)}
                      className="px-3 py-3 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                    >
                      <Minus className="h-4 w-4" />
                    </button>
                  </div>
                ))}
                <button
                  type="button"
                  onClick={() => appendVintage({ Year: new Date().getFullYear() })}
                  className="flex items-center text-[#7CE495] hover:text-[#6BD485] transition-colors"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add Vintage
                </button>
                <ErrorMessage message={errors.Vintages?.message} />
              </div>


              {/* Standard Type & Registry */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                <div>
                  <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                    Standard Type *
                  </label>
                  <Controller
                    name="StandardType"
                    control={control}
                    render={({ field }) => (
                      <div className="relative">
                        <select
                          {...field}
                          className="w-full px-10 py-3 bg-[#F2F7F2] border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all appearance-none font-medium text-[#2B5A3E]"
                        >
                          <option value="">Select Standard Type</option>
                          {standardTypes.map((standard) => (
                            <option key={standard.value} value={standard.value}>
                              {standard.label}
                            </option>
                          ))}
                        </select>
                        <ChevronDown className="absolute right-4 top-1/2 transform -translate-y-1/2 text-[#7CE495] pointer-events-none h-4 w-4" />
                      </div>
                    )}
                  />
                  <ErrorMessage message={errors.StandardType?.message} />
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                    Registry *
                  </label>
                  <Controller
                    name="Registry"
                    control={control}
                    render={({ field }) => (
                      <div className="relative">
                        <select
                          {...field}
                          className="w-full px-10 py-3 bg-[#F2F7F2] border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all appearance-none font-medium text-[#2B5A3E]"
                        >
                          <option value="">Select Registry</option>
                          {registries.map((registry) => (
                            <option key={registry.value} value={registry.value}>
                              {registry.label}
                            </option>
                          ))}
                        </select>
                        <ChevronDown className="absolute right-4 top-1/2 transform -translate-y-1/2 text-[#7CE495] pointer-events-none h-4 w-4" />
                      </div>
                    )}
                  />
                  <ErrorMessage message={errors.Registry?.message} />
                </div>
              </div>

              {/* Mechanism */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                  Mechanism *
                </label>
                <Controller
                  name="Mechanism"
                  control={control}
                  render={({ field }) => (
                    <div className="relative">
                      <select
                        {...field}
                        className="w-full px-10 py-3 bg-[#F2F7F2] border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all appearance-none font-medium text-[#2B5A3E]"
                      >
                        <option value="">Select Mechanism</option>
                        {mechanisms.map((mechanism) => (
                          <option key={mechanism.value} value={mechanism.value}>
                            {mechanism.label}
                          </option>
                        ))}
                      </select>
                      <ChevronDown className="absolute right-4 top-1/2 transform -translate-y-1/2 text-[#7CE495] pointer-events-none h-4 w-4" />
                    </div>
                  )}
                />
                <ErrorMessage message={errors.Mechanism?.message} />
              </div>
            </div>

            {/* 4 - Stock & Availability */}
            <div>
              <h2 className="text-lg font-semibold text-[#2B5A3E] mb-6 flex items-center">
                <span className="bg-[#7CE495] text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mx-2">
                  4
                </span>
                Stock & Availability
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                <div>
                  <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                    Available Stock *
                  </label>
                  <input
                    {...register("AvailableStock", { valueAsNumber: true })}
                    type="number"
                    placeholder="Available stock units"
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all bg-gray-50"
                  />
                  <ErrorMessage message={errors.AvailableStock?.message} />
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                    Minimum Purchase Amount *
                  </label>
                  <input
                    {...register("MinimumPurchaseAmount", { valueAsNumber: true })}
                    type="number"
                    placeholder="Minimum purchase amount"
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all bg-gray-50"
                  />
                  <ErrorMessage message={errors.MinimumPurchaseAmount?.message} />
                </div>
              </div>

            </div>


            {/* 5 - Additional Information */}
            <div>
              <h2 className="text-lg font-semibold text-[#2B5A3E] mb-6 flex items-center">
                <span className="bg-[#7CE495] text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mx-2">
                  5
                </span>
                Additional Information
              </h2>

              {/* Project Type */}
              <div className="mb-4">
                <div>
                  <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                    Project Type *
                  </label>
                  <Controller
                    name="ProjectType"
                    control={control}
                    render={({ field }) => (
                      <div className="relative">
                        <select
                          {...field}
                          className="w-full px-10 py-3 bg-[#F2F7F2] border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all appearance-none font-medium text-[#2B5A3E]"
                        >
                          <option value="">Select Project Type</option>
                          {projectTypes.map((type) => (
                            <option key={type.value} value={type.value}>
                              {type.label}
                            </option>
                          ))}
                        </select>
                        <ChevronDown className="absolute right-4 top-1/2 transform -translate-y-1/2 text-[#7CE495] pointer-events-none h-4 w-4" />
                      </div>
                    )}
                  />
                  <ErrorMessage message={errors.ProjectType?.message} />
                </div>
              </div>

              {/* SDGs */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                  Sustainable Development Goals (SDGs) *
                </label>
                {/* Show at least one SDG field even if array is empty */}
                {sdgFields.length === 0 ? (
                  <div className="flex gap-4 mb-3 items-end">
                    <div className="flex-1">
                      <div className="relative">
                        <select
                          onChange={(e) => {
                            if (e.target.value) {
                              appendSDG(e.target.value);
                            }
                          }}
                          className="w-full px-10 py-3 bg-[#F2F7F2] border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all appearance-none font-medium text-[#2B5A3E]"
                        >
                          <option value="">Select SDG</option>
                          {sdgOptions.map((sdg) => (
                            <option key={sdg.value} value={sdg.value}>
                              {sdg.label}
                            </option>
                          ))}
                        </select>
                        <ChevronDown className="absolute right-4 top-1/2 transform -translate-y-1/2 text-[#7CE495] pointer-events-none h-4 w-4" />
                      </div>
                    </div>
                    <div className="px-3 py-3 text-gray-400">
                      <Minus className="h-4 w-4" />
                    </div>
                  </div>
                ) : (
                  sdgFields.map((field, index) => {
                  const selectedSDGs = watch("SDGs") || [];
                  const availableSDGs = sdgOptions.filter(sdg =>
                    !selectedSDGs.includes(sdg.value) || selectedSDGs[index] === sdg.value
                  );

                  return (
                    <div key={field.id} className="flex gap-4 mb-3 items-end">
                      <div className="flex-1">
                        <Controller
                          name={`SDGs.${index}`}
                          control={control}
                          render={({ field }) => (
                            <div className="relative">
                              <select
                                {...field}
                                className="w-full px-10 py-3 bg-[#F2F7F2] border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all appearance-none font-medium text-[#2B5A3E]"
                              >
                                <option value="">Select SDG</option>
                                {availableSDGs.map((sdg) => (
                                  <option key={sdg.value} value={sdg.value}>
                                    {sdg.label}
                                  </option>
                                ))}
                              </select>
                              <ChevronDown className="absolute right-4 top-1/2 transform -translate-y-1/2 text-[#7CE495] pointer-events-none h-4 w-4" />
                            </div>
                          )}
                        />
                      </div>
                      <button
                        type="button"
                        onClick={() => removeSDG(index)}
                        className="px-3 py-3 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <Minus className="h-4 w-4" />
                      </button>
                    </div>
                  );
                  })
                )}
                <button
                  type="button"
                  onClick={() => appendSDG("")}
                  className="flex items-center text-[#7CE495] hover:text-[#6BD485] transition-colors"
                  disabled={sdgFields.length >= 17}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add SDG
                </button>
                {sdgFields.length >= 17 && (
                  <p className="text-sm text-gray-500 mt-2">All SDGs have been added</p>
                )}
              </div>

              {/* Project Impact */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                  Project Impact *
                </label>
                <Controller
                  name="ProjectImpact"
                  control={control}
                  render={({ field }) => (
                    <div className="relative">
                      <select
                        {...field}
                        className="w-full px-10 py-3 bg-[#F2F7F2] border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#7CE495] focus:border-transparent outline-none transition-all appearance-none font-medium text-[#2B5A3E]"
                      >
                        <option value="">Select Project Impact</option>
                        {projectImpacts.map((impact) => (
                          <option key={impact.value} value={impact.value}>
                            {impact.label}
                          </option>
                        ))}
                      </select>
                      <ChevronDown className="absolute right-4 top-1/2 transform -translate-y-1/2 text-[#7CE495] pointer-events-none h-4 w-4" />
                    </div>
                  )}
                />
                <ErrorMessage message={errors.ProjectImpact?.message} />
              </div>

              {/* File Uploads */}
              <div className="space-y-6">
                {/* Project Image */}
                <div>
                  <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                    Main Project Image *
                  </label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                    {projectImage ? (
                      <div className="relative">
                        <img
                          src={projectImage.preview}
                          alt="Project preview"
                          className="mx-auto h-48 w-auto rounded-lg shadow-md"
                        />
                        <div className="mt-2 text-sm text-gray-600">{projectImage.name}</div>
                        <button
                          type="button"
                          onClick={removeProjectImage}
                          className="mt-2 text-red-600 hover:text-red-800 text-sm underline"
                        >
                          Remove image
                        </button>
                      </div>
                    ) : (
                      <div>
                        <Upload className="mx-auto h-12 w-12 text-gray-400" />
                        <div className="mt-2">
                          <label className="cursor-pointer">
                            <span className="text-[#7CE495] font-medium hover:text-[#2B5A3E]">
                              Click to upload
                            </span>
                            <span className="text-gray-500"> or drag and drop</span>
                            <input
                              type="file"
                              accept="image/*"
                              onChange={handleProjectImageChange}
                              className="hidden"
                            />
                          </label>
                        </div>
                        <p className="text-xs text-gray-500 mt-1">PNG, JPG, GIF up to 10MB (Required)</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Project Gallery */}
                <div>
                  <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                    Project Gallery (Multiple Images) *
                  </label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6">
                    {projectGallery.length > 0 ? (
                      <div className="space-y-4">
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                          {projectGallery.map((image, index) => (
                            <div key={index} className="relative group">
                              <img
                                src={image.preview}
                                alt={`Gallery ${index + 1}`}
                                className="h-24 w-24 object-cover rounded-lg shadow-md"
                              />
                              <button
                                type="button"
                                onClick={() => removeGalleryImage(index)}
                                className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full h-6 w-6 flex items-center justify-center text-xs opacity-0 group-hover:opacity-100 transition-opacity"
                              >
                                ×
                              </button>
                              <div className="text-xs text-gray-600 mt-1 truncate">{image.name}</div>
                            </div>
                          ))}
                        </div>
                        <div className="text-center">
                          <label className="cursor-pointer text-[#7CE495] font-medium hover:text-[#2B5A3E]">
                            Add more images
                            <input
                              type="file"
                              accept="image/*"
                              multiple
                              onChange={handleProjectGalleryChange}
                              className="hidden"
                            />
                          </label>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center">
                        <Upload className="mx-auto h-12 w-12 text-gray-400" />
                        <div className="mt-2">
                          <label className="cursor-pointer">
                            <span className="text-[#7CE495] font-medium hover:text-[#2B5A3E]">
                              Click to upload images
                            </span>
                            <span className="text-gray-500"> or drag and drop</span>
                            <input
                              type="file"
                              accept="image/*"
                              multiple
                              onChange={handleProjectGalleryChange}
                              className="hidden"
                            />
                          </label>
                        </div>
                        <p className="text-xs text-gray-500 mt-1">Multiple PNG, JPG, GIF files (At least one required)</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Documents */}
                <div>
                  <label className="block text-sm font-medium text-[#2B5A3E] mb-2">
                    Project Documents (Multiple Files) *
                  </label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6">
                    {documents.length > 0 ? (
                      <div className="space-y-4">
                        <div className="space-y-2">
                          {documents.map((doc, index) => (
                            <div key={index} className="flex items-center justify-between bg-gray-50 p-3 rounded-lg">
                              <div className="flex items-center space-x-3">
                                <div className="h-8 w-8 bg-[#7CE495] rounded flex items-center justify-center">
                                  <span className="text-white text-xs font-bold">
                                    {doc.name.split('.').pop().toUpperCase()}
                                  </span>
                                </div>
                                <div>
                                  <div className="text-sm font-medium text-gray-900 truncate max-w-xs">
                                    {doc.name}
                                  </div>
                                  <div className="text-xs text-gray-500">
                                    {(doc.size / 1024 / 1024).toFixed(2)} MB
                                  </div>
                                </div>
                              </div>
                              <button
                                type="button"
                                onClick={() => removeDocument(index)}
                                className="text-red-600 hover:text-red-800 text-sm"
                              >
                                Remove
                              </button>
                            </div>
                          ))}
                        </div>
                        <div className="text-center">
                          <label className="cursor-pointer text-[#7CE495] font-medium hover:text-[#2B5A3E]">
                            Add more documents
                            <input
                              type="file"
                              multiple
                              onChange={handleDocumentsChange}
                              className="hidden"
                            />
                          </label>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center">
                        <Upload className="mx-auto h-12 w-12 text-gray-400" />
                        <div className="mt-2">
                          <label className="cursor-pointer">
                            <span className="text-[#7CE495] font-medium hover:text-[#2B5A3E]">
                              Click to upload documents
                            </span>
                            <span className="text-gray-500"> or drag and drop</span>
                            <input
                              type="file"
                              multiple
                              onChange={handleDocumentsChange}
                              className="hidden"
                            />
                          </label>
                        </div>
                        <p className="text-xs text-gray-500 mt-1">PDF, DOC, XLS, TXT files (At least one required)</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <div className="flex justify-center pt-4">
              <button
                type="submit"
                disabled={loading}
                className="w-full bg-[#7CE495] hover:bg-[#6BD485] text-white font-semibold py-4 px-6 rounded-2xl transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed text-lg shadow-lg flex items-center justify-center min-h-[56px]"
              >
                {loading ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                    Submitting Project...
                  </>
                ) : (
                  "Submit Project"
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AddProjectForm;