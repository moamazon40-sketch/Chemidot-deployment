"use client";

import { Provider } from "react-redux";
import store from "@/store/store";
import AuthProvider from "@/components/auth/AuthProvider";

export function ReduxProvider({ children }) {
  return (
    <Provider store={store}>
      <AuthProvider>{children}</AuthProvider>
    </Provider>
  );
}

export default ReduxProvider;
