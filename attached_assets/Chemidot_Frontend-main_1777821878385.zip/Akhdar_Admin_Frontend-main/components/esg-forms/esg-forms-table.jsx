"use client";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DataTable } from "@/components/ui/data-table";
import {
  ArrowUpDown,
  MoreHorizontal,
  Download,
  Loader2,
} from "lucide-react";
import { useState, useEffect, forwardRef, useImperativeHandle } from "react";
import { esgFormsService } from "@/services/api/esgFormsService";
import { toast } from "sonner";

const formatESGFormData = (apiForm) => {
  return {
    id: apiForm.id || "-",
    companyName: apiForm.CompanyName || "-",
    email: apiForm.Email || "-",
    phone: apiForm.Phone || "-",
    country: apiForm.Country || "-",
    companySize: apiForm.CompanySize || "-",
    emissionScopes: apiForm.EmissionScopes || "-",
    notes: apiForm.Notes || "-",
    policyAgreement: apiForm.PolicyAgreement ? "Yes" : "No",
    isTrackingCarbonEmissions: apiForm.IsTrackingCarbonEmissions ? "Yes" : "No",
    isReducingScope3Emissions: apiForm.IsReducingScope3Emissions ? "Yes" : "No",
    isInterestedInDecarbonization: apiForm.IsInterestedInDecarbonization ? "Yes" : "No",
    createdAt: apiForm.createdAt ? new Date(apiForm.createdAt).toLocaleDateString() : "-",
    original: apiForm,
  };
};

const createColumns = (handleFormExport) => [
  {
    accessorKey: "id",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Form ID
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => <div className="font-mono text-xs">{row.getValue("id")}</div>,
    enableHiding: true,
    meta: {
      displayName: "Form ID"
    }
  },
  {
    accessorKey: "companyName",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Company
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => {
      const form = row.original;
      return (
        <div className="max-w-[200px]">
          <div className="font-medium truncate">{form.companyName}</div>
          <div className="text-sm text-muted-foreground truncate">{form.email}</div>
        </div>
      );
    },
  },
  {
    accessorKey: "phone",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Phone
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => (
      <div className="max-w-[150px] truncate">{row.getValue("phone")}</div>
    ),
  },
  {
    accessorKey: "country",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Country
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => (
      <div className="max-w-[150px] truncate">{row.getValue("country")}</div>
    ),
  },
  {
    accessorKey: "companySize",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Company Size
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => (
      <Badge variant="outline">{row.getValue("companySize")}</Badge>
    ),
  },
  {
    accessorKey: "emissionScopes",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Emission Scopes
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => (
      <div className="max-w-[150px] truncate">{row.getValue("emissionScopes")}</div>
    ),
  },
  {
    accessorKey: "notes",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Notes
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => (
      <div className="max-w-[200px] truncate">{row.getValue("notes")}</div>
    ),
  },
  {
    accessorKey: "policyAgreement",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Policy Agreement
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => (
      <Badge variant={row.getValue("policyAgreement") === "Yes" ? "default" : "secondary"}>
        {row.getValue("policyAgreement")}
      </Badge>
    ),
  },
  {
    accessorKey: "isTrackingCarbonEmissions",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Tracking Carbon Emissions
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => (
      <Badge variant={row.getValue("isTrackingCarbonEmissions") === "Yes" ? "default" : "secondary"}>
        {row.getValue("isTrackingCarbonEmissions")}
      </Badge>
    ),
  },
  {
    accessorKey: "isReducingScope3Emissions",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Reducing Scope 3 Emissions
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => (
      <Badge variant={row.getValue("isReducingScope3Emissions") === "Yes" ? "default" : "secondary"}>
        {row.getValue("isReducingScope3Emissions")}
      </Badge>
    ),
  },
  {
    accessorKey: "isInterestedInDecarbonization",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Interested In Decarbonization
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => (
      <Badge variant={row.getValue("isInterestedInDecarbonization") === "Yes" ? "default" : "secondary"}>
        {row.getValue("isInterestedInDecarbonization")}
      </Badge>
    ),
  },
  {
    accessorKey: "createdAt",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Created
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => <div>{row.getValue("createdAt")}</div>,
  },
  {
    id: "actions",
    enableHiding: false,
    cell: ({ row }) => {
      const form = row.original;
      return (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="h-8 w-8 p-0">
              <span className="sr-only">Open menu</span>
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>Actions</DropdownMenuLabel>
            <DropdownMenuItem onClick={() => handleFormExport(form)}>
              <Download className="mr-2 h-4 w-4" />
              Download
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      );
    },
  },
];

export const ESGFormsTable = forwardRef(function ESGFormsTable(props, ref) {
  const [forms, setForms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [hasNextPage, setHasNextPage] = useState(false);
  const [totalCount, setTotalCount] = useState(0);
  const [currentFilters, setCurrentFilters] = useState(null);
  const [columnVisibility, setColumnVisibility] = useState({
    id: false, // Form ID disabled by default
  });
  const pageSize = 10;

  // Expose methods to parent component
  useImperativeHandle(ref, () => ({
    applyFilters: (filters) => {
      console.log("ESGFormsTable applyFilters called with:", filters);
      setCurrentFilters(filters);
      setCurrentPage(1);
      fetchForms(1, filters);
    }
  }));

  const handleFormExport = async (form) => {
    try {
      // Create filters to export only this specific form
      const formFilters = {
        email: form.email
      };

      // Create filename with company name and form ID
      const sanitizedCompany = (form.companyName || "Unknown").replace(/[^a-zA-Z0-9]/g, '_');
      const shortFormId = form.id.slice(0, 8);
      const customFilename = `${sanitizedCompany}_${shortFormId}`;

      await esgFormsService.exportESGForms({
        pageNumber: 1,
        pageSize: 1,
        filters: formFilters,
        customFilename: customFilename
      });

      toast.success('ESG form exported successfully!');
    } catch (error) {
      console.error('Export failed:', error);
      toast.error('Failed to export ESG form. Please try again.');
    }
  };

  const fetchForms = async (page, filters = null) => {
    try {
      setLoading(true);
      const response = await esgFormsService.getESGForms({
        pageNumber: page,
        pageSize: pageSize,
        filters: filters,
      });

      if (response.success) {
        const formattedForms = response.forms.map(formatESGFormData);
        setForms(formattedForms);
        setHasNextPage(response.hasNextPage);
        setTotalCount(response.totalCount);
        setCurrentPage(page);
        setError(null);
      } else {
        setError("Failed to fetch ESG forms");
      }
    } catch (err) {
      console.error("Error fetching ESG forms:", err);
      setError("Failed to load ESG forms");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchForms(1);
  }, []);

  const handleNextPage = () => {
    if (hasNextPage) {
      fetchForms(currentPage + 1, currentFilters);
    }
  };

  const handlePreviousPage = () => {
    if (currentPage > 1) {
      fetchForms(currentPage - 1, currentFilters);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-32">
        <Loader2 className="h-6 w-6 animate-spin" />
        <span className="ml-2">Loading ESG forms...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-32 text-red-500">
        <span>{error}</span>
        <Button
          variant="outline"
          className="ml-4"
          onClick={() => fetchForms(currentPage, currentFilters)}
        >
          Retry
        </Button>
      </div>
    );
  }

  const columns = createColumns(handleFormExport);

  return (
    <div className="space-y-4">
      <DataTable
        columns={columns}
        data={forms}
        hideDefaultPagination={true}
        columnVisibility={columnVisibility}
        onColumnVisibilityChange={setColumnVisibility}
      />

      <div className="flex items-center justify-between">
        <div className="text-sm text-muted-foreground">
          Showing {forms.length} of {totalCount} ESG forms (Page {currentPage})
        </div>
        <div className="flex space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handlePreviousPage}
            disabled={currentPage === 1}
          >
            Previous
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleNextPage}
            disabled={!hasNextPage}
          >
            Next
          </Button>
        </div>
      </div>
    </div>
  );
});