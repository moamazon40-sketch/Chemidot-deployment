"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Filter, X } from "lucide-react";
import { useState } from "react";

export function ESGFormsFilters({ onFiltersChange }) {
  const [filters, setFilters] = useState({
    userEmail: "",
    companyName: "",
  });
  const [hasChanges, setHasChanges] = useState(false);
  const [appliedFilters, setAppliedFilters] = useState({
    userEmail: "",
    companyName: "",
  });

  const handleFilterChange = (key, value) => {
    const newFilters = {
      ...filters,
      [key]: value,
    };
    setFilters(newFilters);

    // Check if filters have changed from applied filters
    const filtersChanged = JSON.stringify(newFilters) !== JSON.stringify(appliedFilters);
    setHasChanges(filtersChanged);

    onFiltersChange?.(newFilters);
  };

  const applyFilters = () => {
    console.log("Applying ESG forms filters:", filters);
    setAppliedFilters(filters);
    setHasChanges(false);
    onFiltersChange?.(filters, true);
  };

  const clearFilters = () => {
    const clearedFilters = {
      userEmail: "",
      companyName: "",
    };
    setFilters(clearedFilters);
    setAppliedFilters(clearedFilters);
    setHasChanges(false);
    onFiltersChange?.(clearedFilters, true);
  };

  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center gap-2 mb-4">
          <Filter className="h-4 w-4" />
          <span className="font-medium">ESG Forms Filters</span>
          <Button
            variant="ghost"
            size="sm"
            onClick={clearFilters}
            className="ml-auto"
          >
            <X className="h-4 w-4 mr-1" />
            Clear All
          </Button>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <div className="space-y-2">
            <Label htmlFor="userEmail">UserEmail</Label>
            <Input
              id="userEmail"
              placeholder="Filter by user email (partial, case-insensitive)"
              value={filters.userEmail}
              onChange={(e) => handleFilterChange("userEmail", e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="companyName">CompanyName</Label>
            <Input
              id="companyName"
              placeholder="Filter by company name"
              value={filters.companyName}
              onChange={(e) => handleFilterChange("companyName", e.target.value)}
            />
          </div>
        </div>

        <div className="mt-6 flex justify-end">
          <Button
            onClick={applyFilters}
            disabled={!hasChanges}
            className={hasChanges ? "bg-green-600 hover:bg-green-700" : ""}
          >
            Apply Filters
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}