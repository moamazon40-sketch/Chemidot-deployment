"use client";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Download, RefreshCw, CreditCard, Copy } from "lucide-react";
export function TransactionDetailModal({ transaction, open, onOpenChange }) {
  const mockPaymentResponse = {
    id: transaction.paymentProviderId,
    amount: Number.parseInt(transaction.total.replace(/[$,]|SAR/g, "").trim()) * 100,
    currency: transaction.currency.toLowerCase(),
    status: transaction.paymentStatus,
    payment_method: {
      type: "card",
      card: {
        brand: "visa",
        last4: "4242",
        exp_month: 12,
        exp_year: 2025,
      },
    },
    created: 1710518400,
    receipt_url: "https://pay.stripe.com/receipts/...",
  };
  const mockOrderPayload = {
    orderId: transaction.id,
    buyer: {
      email: transaction.buyer,
      name: "John Doe",
      company: "Example Corp",
    },
    items: [
      {
        projectId: "PRJ-001",
        projectName: transaction.project,
        quantity: Number.parseInt(transaction.quantity.split(" ")[0]),
        unitPrice: Number.parseFloat(transaction.unitPrice.replace(/\$|SAR/g, "").trim()),
        total: Number.parseFloat(transaction.total.replace(/[$,]|SAR/g, "").trim()),
      },
    ],
    payment: {
      method: transaction.paymentMethod,
      currency: transaction.currency,
      total: Number.parseFloat(transaction.total.replace(/[$,]|SAR/g, "").trim()),
    },
    metadata: {
      source: "marketplace",
      campaign: "carbon-offset-2024",
    },
  };
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            Transaction Details
            <Badge
              variant={
                transaction.paymentStatus === "completed"
                  ? "default"
                  : transaction.paymentStatus === "pending"
                  ? "secondary"
                  : "destructive"
              }
            >
              {transaction.paymentStatus}
            </Badge>
          </DialogTitle>
          <DialogDescription>
            Complete transaction information and payment gateway response
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Transaction Summary</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-4 md:grid-cols-2">
              <div>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">
                      Transaction ID:
                    </span>
                    <span className="font-mono">{transaction.id}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Buyer:</span>
                    <span>{transaction.buyer}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Project:</span>
                    <span>{transaction.project}</span>
                  </div>
                </div>
              </div>

              <div>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Quantity:</span>
                    <span className="font-mono">{transaction.quantity}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Unit Price:</span>
                    <span className="font-mono">{transaction.unitPrice}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Total:</span>
                    <span className="font-mono font-bold">
                      {transaction.total}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Created:</span>
                    <span>{transaction.createdAt}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Order Payload</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <pre className="text-xs bg-muted p-4 rounded-lg overflow-x-auto">
                {JSON.stringify(mockOrderPayload, null, 2)}
              </pre>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Payment Gateway Response</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <pre className="text-xs bg-muted p-4 rounded-lg overflow-x-auto">
                {JSON.stringify(mockPaymentResponse, null, 2)}
              </pre>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Actions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex gap-2 flex-wrap">
                <Button variant="outline">
                  <Download className="h-4 w-4 mr-2" />
                  Download Invoice PDF
                </Button>
                {transaction.paymentStatus === "completed" && (
                  <Button variant="outline">
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Process Refund
                  </Button>
                )}
                {transaction.orderStatus === "processing" && (
                  <Button variant="outline">
                    <CreditCard className="h-4 w-4 mr-2" />
                    Retire Credits Manually
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
}
