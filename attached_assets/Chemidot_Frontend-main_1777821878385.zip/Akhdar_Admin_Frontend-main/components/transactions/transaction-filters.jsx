"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { CalendarIcon, Filter, X } from "lucide-react";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { useState } from "react";

export function TransactionFilters({ onFiltersChange, isOwnerView = false }) {
  const [filters, setFilters] = useState({
    projectName: "",
    paymentStatus: "all",
    paymentMethod: "all",
    transactionID: "",
    moyasarPaymentID: "",
    buyerEmail: "",
    dateFrom: "",
    dateTo: "",
    carbonAmountMin: "",
    carbonAmountMax: "",
  });
  const [hasChanges, setHasChanges] = useState(false);
  const [appliedFilters, setAppliedFilters] = useState({
    projectName: "",
    paymentStatus: "all",
    paymentMethod: "all",
    transactionID: "",
    moyasarPaymentID: "",
    buyerEmail: "",
    dateFrom: "",
    dateTo: "",
    carbonAmountMin: "",
    carbonAmountMax: "",
  });

  const [dateFromOpen, setDateFromOpen] = useState(false);
  const [dateToOpen, setDateToOpen] = useState(false);

  const handleFilterChange = (key, value) => {
    const newFilters = {
      ...filters,
      [key]: value,
    };
    setFilters(newFilters);

    // Check if filters have changed from applied filters
    const filtersChanged = JSON.stringify(newFilters) !== JSON.stringify(appliedFilters);
    setHasChanges(filtersChanged);

    onFiltersChange?.(newFilters);
  };

  const handleDateChange = (key, date) => {
    const formattedDate = date ? format(date, "yyyy-MM-dd") : "";
    handleFilterChange(key, formattedDate);
  };

  const applyFilters = () => {
    console.log("Applying transaction filters:", filters);
    setAppliedFilters(filters);
    setHasChanges(false);
    onFiltersChange?.(filters, true);
  };

  const clearFilters = () => {
    const clearedFilters = {
      projectName: "",
      paymentStatus: "all",
      paymentMethod: "all",
      transactionID: "",
      moyasarPaymentID: "",
      buyerEmail: "",
      dateFrom: "",
      dateTo: "",
      carbonAmountMin: "",
      carbonAmountMax: "",
    };
    setFilters(clearedFilters);
    setAppliedFilters(clearedFilters);
    setHasChanges(false);
    onFiltersChange?.(clearedFilters, true);
  };
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center gap-2 mb-4">
          <Filter className="h-4 w-4" />
          <span className="font-medium">Transaction Filters</span>
          <Button
            variant="ghost"
            size="sm"
            onClick={clearFilters}
            className="ml-auto"
          >
            <X className="h-4 w-4 mr-1" />
            Clear All
          </Button>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <div className="space-y-2">
            <Label htmlFor="projectName">Project Name</Label>
            <Input
              id="projectName"
              placeholder="Enter project name"
              value={filters.projectName}
              onChange={(e) => handleFilterChange("projectName", e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="paymentStatus">Payment Status</Label>
            <Select
              value={filters.paymentStatus}
              onValueChange={(value) => handleFilterChange("paymentStatus", value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select payment status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All</SelectItem>
                <SelectItem value="paid">Paid</SelectItem>
                <SelectItem value="failed">Failed</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {!isOwnerView && (
            <div className="space-y-2">
              <Label htmlFor="paymentMethod">Payment Method</Label>
              <Select
                value={filters.paymentMethod}
                onValueChange={(value) => handleFilterChange("paymentMethod", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select payment method" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="creditcard">Credit Card</SelectItem>
                  <SelectItem value="stcpay">STC Pay</SelectItem>
                  <SelectItem value="applepay">Apple Pay</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="transactionID">Transaction ID</Label>
            <Input
              id="transactionID"
              placeholder="Enter transaction ID"
              value={filters.transactionID}
              onChange={(e) => handleFilterChange("transactionID", e.target.value)}
            />
          </div>

          {!isOwnerView && (
            <>
              <div className="space-y-2">
                <Label htmlFor="moyasarPaymentID">Moyasar Payment ID</Label>
                <Input
                  id="moyasarPaymentID"
                  placeholder="Enter Moyasar payment ID"
                  value={filters.moyasarPaymentID}
                  onChange={(e) => handleFilterChange("moyasarPaymentID", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="buyerEmail">Buyer Email</Label>
                <Input
                  id="buyerEmail"
                  placeholder="Enter buyer email"
                  value={filters.buyerEmail}
                  onChange={(e) => handleFilterChange("buyerEmail", e.target.value)}
                />
              </div>
            </>
          )}

          <div className="space-y-2">
            <Label>Date From</Label>
            <Popover open={dateFromOpen} onOpenChange={setDateFromOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !filters.dateFrom && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {filters.dateFrom ? (
                    format(new Date(filters.dateFrom), "PPP")
                  ) : (
                    <span>Pick a date</span>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={filters.dateFrom ? new Date(filters.dateFrom) : undefined}
                  onSelect={(date) => {
                    handleDateChange("dateFrom", date);
                    setDateFromOpen(false);
                  }}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>

          <div className="space-y-2">
            <Label>Date To</Label>
            <Popover open={dateToOpen} onOpenChange={setDateToOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !filters.dateTo && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {filters.dateTo ? (
                    format(new Date(filters.dateTo), "PPP")
                  ) : (
                    <span>Pick a date</span>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={filters.dateTo ? new Date(filters.dateTo) : undefined}
                  onSelect={(date) => {
                    handleDateChange("dateTo", date);
                    setDateToOpen(false);
                  }}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>

          <div className="space-y-2">
            <Label htmlFor="carbonAmountMin">Min Carbon Amount</Label>
            <Input
              id="carbonAmountMin"
              type="number"
              placeholder="Min amount"
              value={filters.carbonAmountMin}
              onChange={(e) => handleFilterChange("carbonAmountMin", e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="carbonAmountMax">Max Carbon Amount</Label>
            <Input
              id="carbonAmountMax"
              type="number"
              placeholder="Max amount"
              value={filters.carbonAmountMax}
              onChange={(e) => handleFilterChange("carbonAmountMax", e.target.value)}
            />
          </div>
        </div>

        <div className="mt-6 flex justify-end">
          <Button
            onClick={applyFilters}
            disabled={!hasChanges}
            className={hasChanges ? "bg-green-600 hover:bg-green-700" : ""}
          >
            Apply Filters
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
