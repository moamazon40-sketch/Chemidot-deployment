"use client";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DataTable } from "@/components/ui/data-table";
import {
  ArrowUpDown,
  MoreHorizontal,
  Download,
  Loader2,
} from "lucide-react";
import { TransactionDetailModal } from "./transaction-detail-modal";
import { useState, useEffect, forwardRef, useImperativeHandle } from "react";
import { transactionsService } from "@/services/api/transactionsService";
import { toast } from "sonner";
const formatTransactionData = (apiTransaction) => {
  const amount = apiTransaction.Amount || 0;
  const formattedAmount = (amount / 100).toFixed(2); // Convert from cents
  const carbonAmount = apiTransaction.CarbonAmount || 0;
  const unitPrice = carbonAmount > 0 ? (amount / 100 / carbonAmount).toFixed(2) : "0.00";

  return {
    id: apiTransaction.TransactionID || "N/A",
    buyer: apiTransaction.Email || "N/A",
    buyerName: `${apiTransaction.FirstName || ""} ${apiTransaction.LastName || ""}`.trim() || "N/A",
    project: apiTransaction.ProjectName || "N/A",
    projectID: apiTransaction.ProjectID || "N/A",
    quantity: `${carbonAmount} tCO₂e`,
    unitPrice: `${apiTransaction.Currency || "SAR"} ${unitPrice}`,
    total: `${apiTransaction.Currency || "SAR"} ${formattedAmount}`,
    paymentStatus: apiTransaction.Status || "unknown",
    paymentMethod: apiTransaction.PaymentMethod || "N/A",
    createdAt: apiTransaction.createdAt ? new Date(apiTransaction.createdAt).toLocaleDateString() : "N/A",
    moyasarPaymentID: apiTransaction.MoyasarPaymentID || "N/A",
    gateway: apiTransaction.Gateway || "N/A",
    vintage: apiTransaction.Vintage || "N/A",
    paymentType: apiTransaction.PaymentType || "N/A",
    original: apiTransaction,
  };
};
const createColumns = (handleTransactionExport, isOwnerView = false) => {
  const allColumns = [
  {
    accessorKey: "id",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Transaction ID
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => <div className="font-mono text-xs">{row.getValue("id")}</div>,
    enableHiding: true,
    meta: {
      displayName: "Transaction ID"
    }
  },
  {
    accessorKey: "buyer",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Buyer
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => {
      const transaction = row.original;
      return (
        <div className="max-w-[200px]">
          <div className="font-medium truncate">{transaction.buyerName}</div>
          <div className="text-sm text-muted-foreground truncate">{transaction.buyer}</div>
        </div>
      );
    },
  },
  {
    accessorKey: "project",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Project
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => (
      <div className="max-w-[150px] truncate">{row.getValue("project")}</div>
    ),
  },
  {
    accessorKey: "projectID",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Project ID
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => <div className="font-mono text-xs">{row.getValue("projectID")}</div>,
    enableHiding: true,
    meta: {
      displayName: "Project ID"
    }
  },
  {
    accessorKey: "quantity",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Quantity
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => (
      <div className="font-mono">{row.getValue("quantity")}</div>
    ),
  },
  {
    accessorKey: "unitPrice",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Unit Price
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => (
      <div className="font-mono">{row.getValue("unitPrice")}</div>
    ),
  },
  {
    accessorKey: "total",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Total
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => (
      <div className="font-mono font-medium">{row.getValue("total")}</div>
    ),
  },
  {
    accessorKey: "paymentStatus",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Payment
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => {
      const status = row.getValue("paymentStatus");
      return (
        <Badge
          variant={
            status === "paid"
              ? "default"
              : status === "pending"
              ? "secondary"
              : status === "failed"
              ? "destructive"
              : "outline"
          }
        >
          {status}
        </Badge>
      );
    },
  },
  {
    accessorKey: "paymentMethod",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Payment Method
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => {
      const method = row.getValue("paymentMethod");
      const methodLabels = {
        creditcard: "Credit Card",
        stcpay: "STC Pay",
        applepay: "Apple Pay",
      };
      return <div>{methodLabels[method] || method}</div>;
    },
  },
  {
    accessorKey: "moyasarPaymentID",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Moyasar ID
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => <div className="font-mono text-xs">{row.getValue("moyasarPaymentID")}</div>,
    enableHiding: true,
    meta: {
      displayName: "Moyasar Payment ID"
    }
  },
  {
    accessorKey: "createdAt",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Created
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => <div>{row.getValue("createdAt")}</div>,
  },
  {
    id: "actions",
    enableHiding: false,
    cell: ({ row }) => {
      const transaction = row.original;
      return (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="h-8 w-8 p-0">
              <span className="sr-only">Open menu</span>
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>Actions</DropdownMenuLabel>
            <DropdownMenuItem onClick={() => handleTransactionExport(transaction)}>
              <Download className="mr-2 h-4 w-4" />
              Download
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      );
    },
  },
];

  // Filter columns based on view type
  if (isOwnerView) {
    return allColumns.filter(column =>
      column.accessorKey !== 'buyer' &&
      column.accessorKey !== 'paymentMethod' &&
      column.accessorKey !== 'moyasarPaymentID'
    );
  }

  return allColumns;
};

export const TransactionsTable = forwardRef(function TransactionsTable({ appliedFilters, isOwnerView = false }, ref) {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [hasNextPage, setHasNextPage] = useState(false);
  const [totalCount, setTotalCount] = useState(0);
  const [currentFilters, setCurrentFilters] = useState(null);
  const [selectedTransaction, setSelectedTransaction] = useState(null);
  const [columnVisibility, setColumnVisibility] = useState({
    projectID: true, // Project ID enabled by default
    moyasarPaymentID: true, // Moyasar ID enabled by default
  });
  const pageSize = 10;

  // Expose methods to parent component
  useImperativeHandle(ref, () => ({
    applyFilters: (filters) => {
      console.log("TransactionsTable applyFilters called with:", filters);
      setCurrentFilters(filters);
      setCurrentPage(1);
      fetchTransactions(1, filters);
    }
  }));

  const handleTransactionExport = async (transaction) => {
    try {
      // Create filters to export only this specific transaction
      const transactionFilters = {
        transactionID: transaction.id
      };

      // Create filename with project name and transaction ID
      const sanitizedProjectName = transaction.project.replace(/[^a-zA-Z0-9]/g, '_');
      const shortTransactionId = transaction.id.slice(0, 8);
      const customFilename = `${sanitizedProjectName}_${shortTransactionId}`;

      await transactionsService.exportTransactions({
        pageNumber: 1,
        pageSize: 1,
        filters: transactionFilters,
        customFilename: customFilename
      });

      toast.success('Transaction exported successfully!');
    } catch (error) {
      console.error('Export failed:', error);
      toast.error('Failed to export transaction. Please try again.');
    }
  };

  const fetchTransactions = async (page, filters = null) => {
    try {
      setLoading(true);
      const response = await transactionsService.getTransactions({
        pageNumber: page,
        pageSize: pageSize,
        filters: filters,
      });

      if (response.success) {
        const formattedTransactions = response.transactions.map(formatTransactionData);
        setTransactions(formattedTransactions);
        setHasNextPage(response.hasNextPage);
        setTotalCount(response.totalCount);
        setCurrentPage(page);
        setError(null);
      } else {
        setError("Failed to fetch transactions");
      }
    } catch (err) {
      console.error("Error fetching transactions:", err);
      setError("Failed to load transactions");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTransactions(1);
  }, []);

  const handleNextPage = () => {
    if (hasNextPage) {
      fetchTransactions(currentPage + 1, currentFilters);
    }
  };

  const handlePreviousPage = () => {
    if (currentPage > 1) {
      fetchTransactions(currentPage - 1, currentFilters);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-32">
        <Loader2 className="h-6 w-6 animate-spin" />
        <span className="ml-2">Loading transactions...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-32 text-red-500">
        <span>{error}</span>
        <Button
          variant="outline"
          className="ml-4"
          onClick={() => fetchTransactions(currentPage, currentFilters)}
        >
          Retry
        </Button>
      </div>
    );
  }

  const columns = createColumns(handleTransactionExport, isOwnerView);

  return (
    <div className="space-y-4">
      <DataTable
        columns={columns}
        data={transactions}
        hideDefaultPagination={true}
        columnVisibility={columnVisibility}
        onColumnVisibilityChange={setColumnVisibility}
      />

      <div className="flex items-center justify-between">
        <div className="text-sm text-muted-foreground">
          Showing {transactions.length} of {totalCount} transactions (Page {currentPage})
        </div>
        <div className="flex space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handlePreviousPage}
            disabled={currentPage === 1}
          >
            Previous
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleNextPage}
            disabled={!hasNextPage}
          >
            Next
          </Button>
        </div>
      </div>

      {selectedTransaction && (
        <TransactionDetailModal
          transaction={selectedTransaction}
          open={!!selectedTransaction}
          onOpenChange={(open) => !open && setSelectedTransaction(null)}
        />
      )}
    </div>
  );
});
