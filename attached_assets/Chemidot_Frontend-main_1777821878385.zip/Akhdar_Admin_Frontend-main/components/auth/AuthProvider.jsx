"use client";

import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { getAuthData } from "@/utils/authStorage";
import { setUserData } from "@/store/userSlice";

export default function AuthProvider({ children }) {
  const dispatch = useDispatch();

  useEffect(() => {
    // Load auth data from localStorage on app startup
    const authData = getAuthData();
    if (authData) {
      dispatch(setUserData(authData));
    }
  }, [dispatch]);

  return <>{children}</>;
}