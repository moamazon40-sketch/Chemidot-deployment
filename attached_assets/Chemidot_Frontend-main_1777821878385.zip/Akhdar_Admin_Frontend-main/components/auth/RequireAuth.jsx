"use client";

import { useEffect, useState } from "react";
import { useRouter, usePathname } from "next/navigation";
import { useSelector } from "react-redux";
import { isAuthenticated } from "@/utils/authStorage";

export default function RequireAuth({ children }) {
  const [isLoading, setIsLoading] = useState(true);
  const router = useRouter();
  const pathname = usePathname();
  const userData = useSelector((state) => state.user.userData);

  useEffect(() => {
    const checkAuth = () => {
      console.log("RequireAuth: Checking authentication for path:", pathname);
      const authenticated = isAuthenticated();
      console.log("RequireAuth: Authenticated:", authenticated);
      console.log("RequireAuth: UserData:", userData);

      // If not authenticated, redirect to login
      if (!authenticated) {
        console.log("RequireAuth: Not authenticated, redirecting to login");
        router.replace("/");
        return;
      }

      // If authenticated but no userData in Redux yet, wait
      if (!userData?.UserType) {
        console.log("RequireAuth: No UserType in Redux, waiting...");
        return;
      }

      // Check UserType-based access
      const userType = userData.UserType;
      console.log("RequireAuth: UserType:", userType, "Current path:", pathname);

      // SuperAdmin and Admin can only access /admin/*
      if (userType === "SuperAdmin" || userType === "Admin") {
        if (!pathname.startsWith("/admin")) {
          console.log("RequireAuth: Admin user on non-admin route, redirecting to /admin/projects");
          router.replace("/admin/projects");
          return;
        }
      }

      // ProjectOwner can only access /owner/*
      if (userType === "ProjectOwner") {
        if (!pathname.startsWith("/owner")) {
          console.log("RequireAuth: ProjectOwner on non-owner route, redirecting to /owner/projects");
          router.replace("/owner/projects");
          return;
        }
      }

      // Unknown UserType
      if (userType !== "SuperAdmin" && userType !== "Admin" && userType !== "ProjectOwner") {
        console.log("RequireAuth: Unknown UserType:", userType, "redirecting to login");
        router.replace("/");
        return;
      }

      // If we get here, user has correct access
      console.log("RequireAuth: Access granted for", userType, "on", pathname);
      setIsLoading(false);
    };

    // Small delay to ensure Redux has loaded
    setTimeout(checkAuth, 100);
  }, [userData, pathname, router]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-sm text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}