"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useSelector } from "react-redux";
import { isAuthenticated } from "@/utils/authStorage";

export default function LoginPageProtection({ children }) {
  const [isChecking, setIsChecking] = useState(true);
  const router = useRouter();
  const userData = useSelector((state) => state.user.userData);

  useEffect(() => {
    const checkAuth = async () => {
      console.log("LoginPageProtection: Checking authentication...");
      const authenticated = isAuthenticated();
      console.log("LoginPageProtection: Authenticated:", authenticated);
      console.log("LoginPageProtection: UserData:", userData);

      if (authenticated && userData?.UserType) {
        const userType = userData.UserType;
        console.log("LoginPageProtection: User is authenticated with UserType:", userType);

        // Redirect authenticated users to their dashboard
        if (userType === "SuperAdmin" || userType === "Admin") {
          console.log("LoginPageProtection: Redirecting admin to /admin/projects");
          router.replace("/admin/projects");
          return;
        } else if (userType === "ProjectOwner") {
          console.log("LoginPageProtection: Redirecting owner to /owner/projects");
          router.replace("/owner/projects");
          return;
        }
      }

      // Not authenticated or no valid userData, allow login page to render
      console.log("LoginPageProtection: Allowing login page to render");
      setIsChecking(false);
    };

    // Small delay to ensure Redux has loaded
    setTimeout(checkAuth, 100);
  }, [userData, router]);

  // Show loading while checking
  if (isChecking) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return <>{children}</>;
}