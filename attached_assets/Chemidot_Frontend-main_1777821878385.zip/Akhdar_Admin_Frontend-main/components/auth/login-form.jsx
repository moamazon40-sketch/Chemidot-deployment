"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useDispatch } from "react-redux";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, AlertCircle } from "lucide-react";
import { setUserData } from "@/store/userSlice";
import { setAuthData } from "@/utils/authStorage";
import { AdminLogin } from "@/services/auth/authService";
import { ForgotPasswordForm } from "./forgot-password-form";

export function LoginForm({ userType = "auto" }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [rememberMe, setRememberMe] = useState(true);
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const router = useRouter();
  const dispatch = useDispatch();

  const handleBackToLogin = () => {
    setShowForgotPassword(false);
    setError("");
  };

  if (showForgotPassword) {
    return <ForgotPasswordForm onBackToLogin={handleBackToLogin} />;
  }

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");

    // Client-side validation
    const emailValue = email.trim();
    const passwordValue = password.trim();

    if (!emailValue) {
      setError("Please enter your email address.");
      setIsLoading(false);
      return;
    }

    if (!passwordValue) {
      setError("Please enter your password.");
      setIsLoading(false);
      return;
    }

    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(emailValue)) {
      setError("Please enter a valid email address.");
      setIsLoading(false);
      return;
    }

    try {
      const loginData = {
        email: emailValue,
        password: passwordValue,
      };

      console.log("Attempting login with:", { email: emailValue });

      // Call the AdminLogin API
      const response = await AdminLogin(loginData);

      console.log("Login successful, response:", response);

      if (response && response.data) {
        const responseData = response.data;
        console.log("Login API Response:", responseData);

        // Check if login was successful
        if (!responseData.success) {
          setError("Login failed. Please try again.");
          return;
        }

        // Extract user data from the correct response structure
        const user = responseData.user;
        const token = responseData.token;

        // Prepare user data based on actual API response structure
        const userData = {
          token: token,
          UserID: user.UserID,
          Email: user.Email,
          FirstName: user.FirstName || user.firstName, // Handle both capitalized and lowercase
          LastName: user.LastName || user.lastName,   // Handle both capitalized and lowercase
          firstName: user.firstName || user.FirstName, // Store both versions
          lastName: user.lastName || user.LastName,   // Store both versions
          PhoneNumber: user.PhoneNumber,
          UserType: user.UserType,
          createdAt: user.createdAt,
          updatedAt: user.updatedAt,
          IsUsingTemporaryPassword: user.IsUsingTemporaryPassword,
          session: responseData.session
        };

        console.log("Prepared user data:", userData);

        // Save to Redux store
        dispatch(setUserData({
          ...userData,
          RememberMe: rememberMe,
        }));

        // Save to localStorage or sessionStorage based on rememberMe preference
        setAuthData(userData, rememberMe);

        // Check if user is using temporary password
        if (user.IsUsingTemporaryPassword || responseData.session?.isUsingTemporaryPassword) {
          console.log("User is using temporary password, redirecting to change password page");
          // Store the current password temporarily for auto-fill
          sessionStorage.setItem("tempCurrentPassword", passwordValue);
          router.push("/change-password");
          return;
        }

        // Navigate based on UserType
        const userType = user.UserType;
        console.log("Login successful. UserType:", userType);

        if (userType === "SuperAdmin" || userType === "Admin") {
          console.log("Redirecting to admin dashboard");
          router.push("/admin/projects");
        } else if (userType === "ProjectOwner") {
          console.log("Redirecting to owner dashboard");
          router.push("/owner/projects");
        } else {
          console.log("Unknown UserType:", userType);
          setError("Invalid user type. Please contact administrator.");
        }
      } else {
        setError("Invalid response from server. Please try again.");
      }
    } catch (error) {
      console.error("Login error:", error);
      // The error message is already handled in the service and displayed via toast
      // We also set it here for the form display
      setError(error.message || "Login failed. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };
  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <div className="space-y-2">
        <Label htmlFor="email">Email</Label>
        <Input
          id="email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Enter your email"
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="password">Password</Label>
        <Input
          id="password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Enter your password"
          required
        />
      </div>

      <div className="flex items-center space-x-2">
        <input
          type="checkbox"
          id="rememberMe"
          checked={rememberMe}
          onChange={(e) => setRememberMe(e.target.checked)}
          className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
        />
        <Label htmlFor="rememberMe" className="text-sm cursor-pointer">
          Remember me for 30 days
        </Label>
      </div>

      {!rememberMe && (
        <p className="text-xs text-muted-foreground">
          You'll be automatically signed out when you close the browser
        </p>
      )}

      <Button type="submit" className="w-full" disabled={isLoading}>
        {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
        Sign In
      </Button>

      <div className="text-center">
        <Button
          variant="link"
          type="button"
          className="text-sm"
          onClick={() => setShowForgotPassword(true)}
          disabled={isLoading}
        >
          Forgot your password?
        </Button>
      </div>
    </form>
  );
}