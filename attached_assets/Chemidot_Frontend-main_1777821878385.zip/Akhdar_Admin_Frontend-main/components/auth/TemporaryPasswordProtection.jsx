"use client";

import { useEffect } from "react";
import { useRouter, usePathname } from "next/navigation";
import { useSelector } from "react-redux";
import { getAuthData } from "@/utils/authStorage";

const TemporaryPasswordProtection = ({ children }) => {
  const router = useRouter();
  const pathname = usePathname();
  const userData = useSelector((state) => state.user.userData);

  useEffect(() => {
    const checkTemporaryPassword = () => {
      // Skip check for change-password page and login page
      if (pathname === "/change-password" || pathname === "/") {
        return;
      }

      let currentUserData = userData;

      // If no userData in Redux, try to get from storage
      if (!currentUserData) {
        const storageData = getAuthData();
        if (storageData) {
          currentUserData = storageData;
        }
      }

      // If no authentication at all, let RequireAuth handle it
      if (!currentUserData || !currentUserData.token) {
        return;
      }

      // Check if user is using temporary password
      const isUsingTempPassword =
        currentUserData.IsUsingTemporaryPassword ||
        currentUserData.session?.isUsingTemporaryPassword;

      if (isUsingTempPassword) {
        console.log("User has temporary password, redirecting to change password page");
        router.replace("/change-password");
      }
    };

    checkTemporaryPassword();
  }, [userData, pathname, router]);

  return children;
};

export default TemporaryPasswordProtection;