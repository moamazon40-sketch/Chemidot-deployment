"use client";

import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Send } from "lucide-react";
import { toast } from "sonner";
import { adminService } from "@/services/api/adminService";

export function UserInviteModal({ open, onOpenChange }) {
  const [formData, setFormData] = useState({
    FirstName: "",
    LastName: "",
    Email: "",
    PhoneNumber: "",
  });
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState({});

  const handleInputChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    // Clear error for this field when user starts typing
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: "" }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    // First Name validation
    if (!formData.FirstName.trim()) {
      newErrors.FirstName = "First name is required";
    }

    // Last Name validation
    if (!formData.LastName.trim()) {
      newErrors.LastName = "Last name is required";
    }

    // Email validation
    if (!formData.Email.trim()) {
      newErrors.Email = "Email address is required";
    } else {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(formData.Email)) {
        newErrors.Email = "Please enter a valid email address";
      }
    }

    // Phone Number validation
    if (!formData.PhoneNumber.trim()) {
      newErrors.PhoneNumber = "Phone number is required";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) {
      toast.error("Please fill in all required fields correctly");
      return;
    }

    setIsLoading(true);

    try {
      const result = await adminService.createAdmin(formData);

      toast.success(result.message);
      onOpenChange(false);
      setFormData({
        FirstName: "",
        LastName: "",
        Email: "",
        PhoneNumber: "",
      });
      setErrors({});
    } catch (error) {
      console.error('Error creating admin:', error);

      if (error.response) {
        const errorMessage = error.response.data?.error || error.response.data?.message || `Server error (${error.response.status})`;
        toast.error(errorMessage);
      } else {
        toast.error(error.message || 'Failed to create admin user');
      }
    } finally {
      setIsLoading(false);
    }
  };
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Invite New Admin</DialogTitle>
          <DialogDescription>
            Create a new admin user for the carbon credit marketplace platform.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="firstName">First Name *</Label>
            <Input
              id="firstName"
              value={formData.FirstName}
              onChange={(e) => handleInputChange("FirstName", e.target.value)}
              placeholder="John"
              required
              className={errors.FirstName ? "border-red-500" : ""}
            />
            {errors.FirstName && (
              <p className="text-sm text-red-500">{errors.FirstName}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="lastName">Last Name *</Label>
            <Input
              id="lastName"
              value={formData.LastName}
              onChange={(e) => handleInputChange("LastName", e.target.value)}
              placeholder="Doe"
              required
              className={errors.LastName ? "border-red-500" : ""}
            />
            {errors.LastName && (
              <p className="text-sm text-red-500">{errors.LastName}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email Address *</Label>
            <Input
              id="email"
              type="email"
              value={formData.Email}
              onChange={(e) => handleInputChange("Email", e.target.value)}
              placeholder="user@example.com"
              required
              className={errors.Email ? "border-red-500" : ""}
            />
            {errors.Email && (
              <p className="text-sm text-red-500">{errors.Email}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="phoneNumber">Phone Number *</Label>
            <Input
              id="phoneNumber"
              type="tel"
              value={formData.PhoneNumber}
              onChange={(e) => handleInputChange("PhoneNumber", e.target.value)}
              placeholder="+1234567890"
              required
              className={errors.PhoneNumber ? "border-red-500" : ""}
            />
            {errors.PhoneNumber && (
              <p className="text-sm text-red-500">{errors.PhoneNumber}</p>
            )}
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={isLoading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isLoading || !formData.FirstName.trim() || !formData.LastName.trim() || !formData.Email.trim() || !formData.PhoneNumber.trim()}
            >
              <Send className="h-4 w-4 mr-2" />
              {isLoading ? "Creating..." : "Create Admin"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
