"use client";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { DataTable } from "@/components/ui/data-table";
import {
  ArrowUpDown,
  MoreHorizontal,
  Edit,
  Pause,
  Play,
  Trash2,
  Shield,
  Loader2,
} from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useState, useEffect, forwardRef, useImperativeHandle, useMemo } from "react";
import { useSelector } from "react-redux";
import { usersService } from "@/services/api/usersService";
import { toast } from "sonner";

const formatUserData = (apiUser) => {
  return {
    id: apiUser.UserID || apiUser.id || "N/A",
    name: `${apiUser.FirstName || apiUser.firstName || ""} ${apiUser.LastName || apiUser.lastName || ""}`.trim() || apiUser.Email || "Unknown",
    email: apiUser.Email || apiUser.email || "N/A",
    role: apiUser.UserType || apiUser.Role || "user",
    status: apiUser.Status || "-",
    lastLogin: apiUser.LastLoginDate ? new Date(apiUser.LastLoginDate).toLocaleDateString() : "-",
    createdAt: apiUser.createdAt ? new Date(apiUser.createdAt).toLocaleDateString() : "N/A",
    projectsCount: apiUser.ProjectCount || apiUser.ProjectsCount || apiUser.projectsCount || 0,
    original: apiUser,
  };
};
const createColumns = (openDeleteModal, openSuspendModal, handleSuspendUser, handleReactivateUser, showRoleColumn = true) => {
  const columns = [
    {
      accessorKey: "name",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          >
            Name
            <ArrowUpDown className="ml-2 h-4 w-4" />
          </Button>
        );
      },
      cell: ({ row }) => {
        const user = row.original;
        const initials = user.name
          .split(" ")
          .map((n) => n[0])
          .join("")
          .toUpperCase();
        return (
          <div className="flex items-center gap-3">
            <Avatar className="h-8 w-8">
              <AvatarFallback className="text-xs">{initials}</AvatarFallback>
            </Avatar>
            <div>
              <div className="font-medium">{user.name}</div>
              <div className="text-sm text-muted-foreground">{user.email}</div>
            </div>
          </div>
        );
      },
    }
  ];

  // Conditionally add role column only for SuperAdmin
  if (showRoleColumn) {
    columns.push({
      accessorKey: "role",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          >
            Role
            <ArrowUpDown className="ml-2 h-4 w-4" />
          </Button>
        );
      },
      cell: ({ row }) => {
        const role = row.getValue("role");
        const roleLabels = {
          SuperAdmin: "Super Admin",
          Admin: "Administrator",
          ProjectOwner: "Project Owner",
          admin: "Administrator",
          project_owner: "Project Owner",
          compliance_officer: "Compliance Officer",
          finance: "Finance",
        };
        return <Badge variant="outline">{roleLabels[role]}</Badge>;
      },
    });
  }

  columns.push({
    accessorKey: "status",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Status
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => {
      const status = row.getValue("status");
      if (status === "-" || !status) {
        return <div className="text-center">-</div>;
      }
      return (
        <Badge
  variant={
            status === "Active" || status === "active"
              ? "default"
              : status === "invited"
              ? "secondary"
              : status === "Suspended" || status === "suspended"
              ? "destructive"
              : "outline"
          }
        >
          {status}
        </Badge>
      );
    },
  },
  {
    accessorKey: "projectsCount",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Projects
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => {
      const count = row.getValue("projectsCount");
      return <div className="text-center">{count || 0}</div>;
    },
  },
  {
    accessorKey: "lastLogin",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Last Login
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => {
      const lastLogin = row.getValue("lastLogin");
      return <div className="text-sm">{lastLogin || "-"}</div>;
    },
  },
  {
    accessorKey: "createdAt",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Created
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => <div>{row.getValue("createdAt")}</div>,
  },
  {
    id: "actions",
    enableHiding: false,
    cell: ({ row }) => {
      const user = row.original;
      return (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="h-8 w-8 p-0">
              <span className="sr-only">Open menu</span>
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>

          <DropdownMenuContent align="end">
            <DropdownMenuLabel>Actions</DropdownMenuLabel>
            {(user.status === "Active" || user.status === "active") && (
              <DropdownMenuItem onClick={() => openSuspendModal(user)}>
                <Pause className="mr-2 h-4 w-4" />
                Suspend User
              </DropdownMenuItem>
            )}
            {(user.status === "Suspended" || user.status === "suspended") && (
              <DropdownMenuItem onClick={() => handleReactivateUser(user)}>
                <Play className="mr-2 h-4 w-4" />
                Reactivate User
              </DropdownMenuItem>
            )}
            <DropdownMenuSeparator />
            <DropdownMenuItem
              className="text-destructive"
              onClick={() => openDeleteModal(user)}
            >
              <Trash2 className="mr-2 h-4 w-4" />
              Delete User
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      );
    },
  });

  return columns;
};

export const columns = createColumns(() => {}, () => {}, () => {}, () => {}, true);
export const UsersTable = forwardRef(function UsersTable(props, ref) {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [hasNextPage, setHasNextPage] = useState(false);
  const [totalCount, setTotalCount] = useState(0);
  const [currentFilters, setCurrentFilters] = useState(null);
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [userToDelete, setUserToDelete] = useState(null);
  const [deleting, setDeleting] = useState(false);
  const [suspendModalOpen, setSuspendModalOpen] = useState(false);
  const [userToSuspend, setUserToSuspend] = useState(null);
  const [suspending, setSuspending] = useState(false);
  const [reactivating, setReactivating] = useState(false);
  const userData = useSelector((state) => state.user.userData);
  const pageSize = 10;

  // Only SuperAdmin can see role column
  const canSeeRoles = userData?.UserType === "SuperAdmin";

  // Define functions before using them in useMemo
  const openDeleteModal = (user) => {
    setUserToDelete(user);
    setDeleteModalOpen(true);
  };

  const openSuspendModal = (user) => {
    setUserToSuspend(user);
    setSuspendModalOpen(true);
  };

  const handleSuspendUser = async () => {
    if (!userToSuspend) return;

    try {
      setSuspending(true);
      await usersService.suspendUser(userToSuspend.id);
      toast.success(`User ${userToSuspend.name} suspended successfully`);

      // Refresh the users list
      fetchUsers(currentPage, currentFilters);

      // Close modal and reset state
      setSuspendModalOpen(false);
      setUserToSuspend(null);
    } catch (error) {
      console.error('Error suspending user:', error);
      toast.error('Failed to suspend user. Please try again.');
    } finally {
      setSuspending(false);
    }
  };

  const handleReactivateUser = async (user) => {
    try {
      setReactivating(true);
      await usersService.reactivateUser(user.id);
      toast.success(`User ${user.name} reactivated successfully`);

      // Refresh the users list
      fetchUsers(currentPage, currentFilters);
    } catch (error) {
      console.error('Error reactivating user:', error);
      toast.error('Failed to reactivate user. Please try again.');
    } finally {
      setReactivating(false);
    }
  };

  // Create columns with proper dependencies
  const dynamicColumns = useMemo(() =>
    createColumns(openDeleteModal, openSuspendModal, handleSuspendUser, handleReactivateUser, canSeeRoles),
    [canSeeRoles]
  );

  // Expose methods to parent component
  useImperativeHandle(ref, () => ({
    applyFilters: (filters) => {
      console.log("UsersTable applyFilters called with:", filters);
      setCurrentFilters(filters);
      setCurrentPage(1);
      fetchUsers(1, filters);
    }
  }));

  const fetchUsers = async (page, filters = null) => {
    try {
      setLoading(true);
      const response = await usersService.getUsers({
        pageNumber: page,
        pageSize: pageSize,
        filters: filters,
      });

      if (response.success) {
        const formattedUsers = response.users.map(formatUserData);
        setUsers(formattedUsers);
        setHasNextPage(response.hasNextPage);

        // Debug: Log the totalCount being set
        console.log('UsersTable: Setting totalCount to:', response.totalCount);
        console.log('UsersTable: Current users length:', formattedUsers.length);

        setTotalCount(response.totalCount);
        setCurrentPage(page);
        setError(null);
      } else {
        setError("Failed to fetch users");
      }
    } catch (err) {
      console.error("Error fetching users:", err);
      setError("Failed to load users");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers(1);
  }, []);

  const handleNextPage = () => {
    if (hasNextPage) {
      fetchUsers(currentPage + 1, currentFilters);
    }
  };

  const handlePreviousPage = () => {
    if (currentPage > 1) {
      fetchUsers(currentPage - 1, currentFilters);
    }
  };

  const handleDeleteUser = async () => {
    if (!userToDelete) return;

    try {
      setDeleting(true);
      await usersService.deleteUser(userToDelete.id);
      toast.success(`User ${userToDelete.name} deleted successfully`);

      // Refresh the users list
      fetchUsers(currentPage, currentFilters);

      // Close modal and reset state
      setDeleteModalOpen(false);
      setUserToDelete(null);
    } catch (error) {
      console.error('Error deleting user:', error);
      toast.error('Failed to delete user. Please try again.');
    } finally {
      setDeleting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-32">
        <Loader2 className="h-6 w-6 animate-spin" />
        <span className="ml-2">Loading users...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-32 text-red-500">
        <span>{error}</span>
        <Button
          variant="outline"
          className="ml-4"
          onClick={() => fetchUsers(currentPage, currentFilters)}
        >
          Retry
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <DataTable
        key={`table-${userData?.UserType}-${canSeeRoles}`}
        columns={dynamicColumns}
        data={users}
        hideDefaultPagination={true}
      />

      <div className="flex items-center justify-between">
        <div className="text-sm text-muted-foreground">
          Showing {users.length} of {totalCount} users (Page {currentPage})
          {/* Debug: Show pagination values */}
          <span className="hidden text-xs text-red-500 ml-2">
            Debug: users={users.length}, total={totalCount}, page={currentPage}
          </span>
        </div>
        <div className="flex space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handlePreviousPage}
            disabled={currentPage === 1}
          >
            Previous
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleNextPage}
            disabled={!hasNextPage}
          >
            Next
          </Button>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      <Dialog open={deleteModalOpen} onOpenChange={setDeleteModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete User</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete{" "}
              <span className="font-semibold">{userToDelete?.name}</span>?
              This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDeleteModalOpen(false)}
              disabled={deleting}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={handleDeleteUser}
              disabled={deleting}
            >
              {deleting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Deleting...
                </>
              ) : (
                "Delete User"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Suspend Confirmation Modal */}
      <Dialog open={suspendModalOpen} onOpenChange={setSuspendModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Suspend User</DialogTitle>
            <DialogDescription>
              Are you sure you want to suspend{" "}
              <span className="font-semibold">{userToSuspend?.name}</span>?
              The user will not be able to access their account until reactivated.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setSuspendModalOpen(false)}
              disabled={suspending}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={handleSuspendUser}
              disabled={suspending}
            >
              {suspending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Suspending...
                </>
              ) : (
                "Suspend User"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
});
