"use client";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DataTable } from "@/components/ui/data-table";
import {
  ArrowUpDown,
  MoreHorizontal,
  Download,
  Loader2,
} from "lucide-react";
import { useState, useEffect, forwardRef, useImperativeHandle } from "react";
import { contactUsService } from "@/services/api/contactUsService";
import { toast } from "sonner";

const formatContactUsData = (apiRequest) => {
  return {
    id: apiRequest.id || "-",
    name: `${apiRequest.FirstName || ""} ${apiRequest.LastName || ""}`.trim() || "-",
    email: apiRequest.Email || "-",
    company: apiRequest.Company || "-",
    interest: apiRequest.Interest || "-",
    region: apiRequest.Region || "-",
    notes: apiRequest.Notes || "-",
    createdAt: apiRequest.createdAt ? new Date(apiRequest.createdAt).toLocaleDateString() : "-",
    original: apiRequest,
  };
};

const createColumns = (handleRequestExport) => [
  {
    accessorKey: "id",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Request ID
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => <div className="font-mono text-xs">{row.getValue("id")}</div>,
    enableHiding: true,
    meta: {
      displayName: "Request ID"
    }
  },
  {
    accessorKey: "name",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Name
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => {
      const request = row.original;
      return (
        <div className="max-w-[200px]">
          <div className="font-medium">{request.name}</div>
          <div className="text-sm text-muted-foreground truncate">{request.email}</div>
        </div>
      );
    },
  },
  {
    accessorKey: "company",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Company
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => (
      <div className="max-w-[150px] truncate">{row.getValue("company")}</div>
    ),
  },
  {
    accessorKey: "interest",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Interest
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => (
      <div className="max-w-[200px] truncate">{row.getValue("interest")}</div>
    ),
  },
  {
    accessorKey: "region",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Region
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => (
      <div className="max-w-[150px] truncate">{row.getValue("region")}</div>
    ),
  },
  {
    accessorKey: "notes",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Notes
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => (
      <div className="max-w-[200px] truncate">{row.getValue("notes")}</div>
    ),
  },
  {
    accessorKey: "createdAt",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Created
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => <div>{row.getValue("createdAt")}</div>,
  },
  {
    id: "actions",
    enableHiding: false,
    cell: ({ row }) => {
      const request = row.original;
      return (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="h-8 w-8 p-0">
              <span className="sr-only">Open menu</span>
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>Actions</DropdownMenuLabel>
            <DropdownMenuItem onClick={() => handleRequestExport(request)}>
              <Download className="mr-2 h-4 w-4" />
              Download
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      );
    },
  },
];

export const ContactUsTable = forwardRef(function ContactUsTable(props, ref) {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [hasNextPage, setHasNextPage] = useState(false);
  const [totalCount, setTotalCount] = useState(0);
  const [currentFilters, setCurrentFilters] = useState(null);
  const [columnVisibility, setColumnVisibility] = useState({
    id: true, // Request ID enabled by default
  });
  const pageSize = 10;

  // Expose methods to parent component
  useImperativeHandle(ref, () => ({
    applyFilters: (filters) => {
      console.log("ContactUsTable applyFilters called with:", filters);
      setCurrentFilters(filters);
      setCurrentPage(1);
      fetchRequests(1, filters);
    }
  }));

  const handleRequestExport = async (request) => {
    try {
      // Create filters to export only this specific request
      const requestFilters = {
        email: request.email
      };

      // Create filename with company name and request ID
      const sanitizedCompany = (request.company || "Unknown").replace(/[^a-zA-Z0-9]/g, '_');
      const shortRequestId = request.id.slice(0, 8);
      const customFilename = `${sanitizedCompany}_${shortRequestId}`;

      await contactUsService.exportContactUsRequests({
        pageNumber: 1,
        pageSize: 1,
        filters: requestFilters,
        customFilename: customFilename
      });

      toast.success('Contact request exported successfully!');
    } catch (error) {
      console.error('Export failed:', error);
      toast.error('Failed to export contact request. Please try again.');
    }
  };

  const fetchRequests = async (page, filters = null) => {
    try {
      setLoading(true);
      const response = await contactUsService.getContactUsRequests({
        pageNumber: page,
        pageSize: pageSize,
        filters: filters,
      });

      if (response.success) {
        const formattedRequests = response.requests.map(formatContactUsData);
        setRequests(formattedRequests);
        setHasNextPage(response.hasNextPage);
        setTotalCount(response.totalCount);
        setCurrentPage(page);
        setError(null);
      } else {
        setError("Failed to fetch contact requests");
      }
    } catch (err) {
      console.error("Error fetching contact requests:", err);
      setError("Failed to load contact requests");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRequests(1);
  }, []);

  const handleNextPage = () => {
    if (hasNextPage) {
      fetchRequests(currentPage + 1, currentFilters);
    }
  };

  const handlePreviousPage = () => {
    if (currentPage > 1) {
      fetchRequests(currentPage - 1, currentFilters);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-32">
        <Loader2 className="h-6 w-6 animate-spin" />
        <span className="ml-2">Loading contact requests...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-32 text-red-500">
        <span>{error}</span>
        <Button
          variant="outline"
          className="ml-4"
          onClick={() => fetchRequests(currentPage, currentFilters)}
        >
          Retry
        </Button>
      </div>
    );
  }

  const columns = createColumns(handleRequestExport);

  return (
    <div className="space-y-4">
      <DataTable
        columns={columns}
        data={requests}
        hideDefaultPagination={true}
        columnVisibility={columnVisibility}
        onColumnVisibilityChange={setColumnVisibility}
      />

      <div className="flex items-center justify-between">
        <div className="text-sm text-muted-foreground">
          Showing {requests.length} of {totalCount} contact requests (Page {currentPage})
        </div>
        <div className="flex space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handlePreviousPage}
            disabled={currentPage === 1}
          >
            Previous
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleNextPage}
            disabled={!hasNextPage}
          >
            Next
          </Button>
        </div>
      </div>
    </div>
  );
});