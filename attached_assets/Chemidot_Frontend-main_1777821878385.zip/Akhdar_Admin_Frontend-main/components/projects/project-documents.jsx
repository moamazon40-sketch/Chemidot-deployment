"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Download,
  Eye,
  Upload,
  FileText,
  ImageIcon,
  Archive,
} from "lucide-react";
const documents = [
  {
    id: "1",
    name: "Project Design Document.pdf",
    type: "pdf",
    size: "2.4 MB",
    uploadedAt: "2024-01-15",
    status: "approved",
  },
  {
    id: "2",
    name: "Monitoring Report Q1 2024.pdf",
    type: "pdf",
    size: "1.8 MB",
    uploadedAt: "2024-02-01",
    status: "pending",
  },
  {
    id: "3",
    name: "Satellite Imagery.jpg",
    type: "image",
    size: "5.2 MB",
    uploadedAt: "2024-01-20",
    status: "approved",
  },
  {
    id: "4",
    name: "Shapefile_boundaries.zip",
    type: "archive",
    size: "892 KB",
    uploadedAt: "2024-01-18",
    status: "approved",
  },
];
export function ProjectDocuments({ projectId }) {
  const getFileIcon = (type) => {
    switch (type) {
      case "pdf":
        return <FileText className="h-4 w-4" />;
      case "image":
        return <ImageIcon className="h-4 w-4" />;
      case "archive":
        return <Archive className="h-4 w-4" />;
      default:
        return <FileText className="h-4 w-4" />;
    }
  };
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Project Documents</CardTitle>
          <Button>
            <Upload className="h-4 w-4 mr-2" />
            Upload Document
          </Button>
        </div>
      </CardHeader>

      <CardContent>
        <div className="space-y-4">
          {documents.map((doc) => (
            <div
              key={doc.id}
              className="flex items-center justify-between p-4 border rounded-lg"
            >
              <div className="flex items-center gap-3">
                {getFileIcon(doc.type)}
                <div>
                  <p className="font-medium">{doc.name}</p>
                  <p className="text-sm text-muted-foreground">
                    {doc.size} • Uploaded {doc.uploadedAt}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <Badge
                  variant={doc.status === "approved" ? "default" : "secondary"}
                >
                  {doc.status}
                </Badge>
                <Button variant="ghost" size="sm">
                  <Eye className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm">
                  <Download className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
