"use client";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Check, X, Loader2 } from "lucide-react";
import { useState } from "react";
import { projectsService } from "@/services/api/projectsService";
import { toast } from "sonner";
export function ApproveRejectActions({ project, onSuccess }) {
  const [approveOpen, setApproveOpen] = useState(false);
  const [rejectOpen, setRejectOpen] = useState(false);
  const [createOwnerAccount, setCreateOwnerAccount] = useState(true);
  const [sendAnnouncement, setSendAnnouncement] = useState(true);
  const [approveLoading, setApproveLoading] = useState(false);
  const [rejectLoading, setRejectLoading] = useState(false);
  const [vintagePricing, setVintagePricing] = useState({});
  const [defaultCarbonPrice, setDefaultCarbonPrice] = useState("");

  // Initialize vintage pricing when component loads or project changes
  const getProjectVintages = () => {
    if (project.original?.Vintages && project.original.Vintages.length > 0) {
      return project.original.Vintages.map(vintage => ({
        year: vintage.Year,
        currentPrice: vintage.CarbonPricePerTon || project.original.DefaultCarbonPricePerTon || 0
      })).sort((a, b) => b.year - a.year);
    }
    return [];
  };

  // Initialize pricing when approve dialog opens
  const handleApproveOpen = (open) => {
    setApproveOpen(open);
    if (open) {
      const vintages = getProjectVintages();
      const initialPricing = {};
      vintages.forEach(vintage => {
        initialPricing[vintage.year] = vintage.currentPrice.toString();
      });
      setVintagePricing(initialPricing);
      // Initialize default carbon price from project data
      setDefaultCarbonPrice((project.original?.DefaultCarbonPricePerTon || 0).toString());
    }
  };

  const updateVintagePrice = (year, price) => {
    setVintagePricing(prev => ({
      ...prev,
      [year]: price
    }));
  };

  const validatePricing = () => {
    const vintages = getProjectVintages();

    if (vintages.length > 0) {
      // If there are vintages, all must have valid pricing
      for (const vintage of vintages) {
        const price = parseFloat(vintagePricing[vintage.year] || "0");
        if (!price || price <= 0) {
          return { valid: false, message: `Price for vintage ${vintage.year} is required and must be greater than 0` };
        }
      }
    } else {
      // If no vintages, default carbon price is required
      const price = parseFloat(defaultCarbonPrice || "0");
      if (!price || price <= 0) {
        return { valid: false, message: "Default Carbon Price Per Ton is required and must be greater than 0" };
      }
    }

    return { valid: true };
  };

  const handleApprove = async () => {
    const validation = validatePricing();
    if (!validation.valid) {
      toast.error(validation.message);
      return;
    }

    setApproveLoading(true);
    try {
      const vintages = getProjectVintages();
      let pricingData = {};

      if (vintages.length > 0) {
        // Send vintage-specific pricing
        pricingData.vintages = vintages.map(vintage => ({
          year: parseInt(vintage.year),
          price: parseFloat(vintagePricing[vintage.year] || "0")
        }));
      } else {
        // Send default pricing
        pricingData.defaultPrice = parseFloat(defaultCarbonPrice || "0");
      }

      console.log('Approval pricing data:', pricingData);

      const result = await projectsService.approveProject(project.id, pricingData);
      if (result.success) {
        toast.success(result.message || "Project approved successfully");
        setApproveOpen(false);
        if (onSuccess) onSuccess();
      } else {
        toast.error(result.message || "Failed to approve project");
      }
    } catch (error) {
      console.error("Error approving project:", error);
      toast.error("Failed to approve project. Please try again.");
    } finally {
      setApproveLoading(false);
    }
  };

  const handleReject = async () => {
    setRejectLoading(true);
    try {
      const result = await projectsService.rejectProject(project.id);
      if (result.success) {
        toast.success(result.message || "Project rejected successfully");
        setRejectOpen(false);
        if (onSuccess) onSuccess();
      } else {
        toast.error(result.message || "Failed to reject project");
      }
    } catch (error) {
      console.error("Error rejecting project:", error);
      toast.error("Failed to reject project. Please try again.");
    } finally {
      setRejectLoading(false);
    }
  };
  return (
    <div className="flex gap-2">
      <Dialog open={approveOpen} onOpenChange={handleApproveOpen}>
        <DialogTrigger asChild>
          <Button>
            <Check className="h-4 w-4 mr-2" />
            Approve
          </Button>
        </DialogTrigger>

        <DialogContent className="sm:max-w-[600px] max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Approve Project</DialogTitle>
            <DialogDescription>
              Review and set pricing before approving "{project.name}".
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6 py-4">
            <div className="grid gap-2">
              <Label>Project Details</Label>
              <div className="text-sm space-y-1 bg-gray-50 p-3 rounded-lg">
                <div><strong>Total Credits:</strong> {project.available}</div>
                <div><strong>Owner Email:</strong> {project.ownerEmail}</div>
                <div><strong>Standard:</strong> {project.standard}</div>
                <div><strong>Country:</strong> {project.country}</div>
              </div>
            </div>

            <div className="space-y-4">
              <Label className="text-base font-semibold">Vintage Pricing (Required)</Label>
              <div className="space-y-3">
                {getProjectVintages().map((vintage) => (
                  <div key={vintage.year} className="flex items-center justify-between p-3 border rounded-lg bg-white">
                    <div className="flex items-center space-x-3">
                      <div className="font-medium">Vintage {vintage.year}</div>
                      <div className="text-sm text-gray-500">
                        Current: {vintage.currentPrice.toFixed(2)} SAR
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Label htmlFor={`price-${vintage.year}`} className="text-sm">
                        Price per tCO₂e:
                      </Label>
                      <Input
                        id={`price-${vintage.year}`}
                        type="number"
                        step="0.01"
                        min="0.01"
                        value={vintagePricing[vintage.year] || ""}
                        onChange={(e) => updateVintagePrice(vintage.year, e.target.value)}
                        placeholder="0.00"
                        className="w-24 text-right"
                        required
                      />
                      <span className="text-sm text-gray-500">SAR</span>
                    </div>
                  </div>
                ))}
              </div>
              {getProjectVintages().length === 0 && (
                <div className="space-y-3">
                  <div className="text-sm text-gray-500 italic p-3 border rounded-lg bg-gray-50">
                    No vintages for this project. Please set the default carbon price per ton.
                  </div>
                  <div className="flex items-center justify-between p-3 border rounded-lg bg-white">
                    <div className="flex items-center space-x-3">
                      <div className="font-medium">Default Carbon Price Per Ton</div>
                      <div className="text-sm text-gray-500">
                        Current: {(project.original?.DefaultCarbonPricePerTon || 0).toFixed(2)} SAR
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Label htmlFor="default-price" className="text-sm">
                        Price per tCO₂e:
                      </Label>
                      <Input
                        id="default-price"
                        type="number"
                        step="0.01"
                        min="0.01"
                        value={defaultCarbonPrice}
                        onChange={(e) => setDefaultCarbonPrice(e.target.value)}
                        placeholder="0.00"
                        className="w-24 text-right"
                        required
                      />
                      <span className="text-sm text-gray-500">SAR</span>
                    </div>
                  </div>
                </div>
              )}
            </div>

          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setApproveOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleApprove} disabled={approveLoading}>
              {approveLoading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Approving...
                </>
              ) : (
                "Confirm Approval"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={rejectOpen} onOpenChange={setRejectOpen}>
        <DialogTrigger asChild>
          <Button variant="destructive">
            <X className="h-4 w-4 mr-2" />
            Reject
          </Button>
        </DialogTrigger>

        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Reject Project</DialogTitle>
            <DialogDescription>
              Are you sure you want to reject "{project.name}"? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>

          <DialogFooter>
            <Button variant="outline" onClick={() => setRejectOpen(false)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={handleReject}
              disabled={rejectLoading}
            >
              {rejectLoading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Rejecting...
                </>
              ) : (
                "Confirm Rejection"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
