"use client";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DataTable } from "@/components/ui/data-table";
import {
  ArrowUpDown,
  MoreHorizontal,
  Eye,
  Edit,
  Check,
  X,
  Pause,
  Download,
  Loader2,
  Play,
  Trash2,
  FileText,
} from "lucide-react";
import Link from "next/link";
import { useState, useEffect, forwardRef, useImperativeHandle } from "react";
import { useRouter } from "next/navigation";
import { projectsService } from "@/services/api/projectsService";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
const formatProjectData = (apiProject) => {
  const getStatusFromProject = (project) => {
    if (project.Status === "Rejected" || project.ProjectStatus === "rejected") return "rejected";
    if (project.Status === "Active" && project.IsActive) return "active";
    if (project.Status === "Suspended" && !project.IsActive) return "suspended";
    if (project.ProjectStatus === "active" && project.IsActive) return "active";
    return "pending";
  };

  const getVintageDisplay = (project) => {
    if (project.Vintages && project.Vintages.length > 0) {
      try {
        const years = project.Vintages.map(vintage => {
          // Handle both object and primitive cases
          if (typeof vintage === 'object' && vintage !== null) {
            return parseInt(vintage.Year, 10);
          } else if (typeof vintage === 'number' || typeof vintage === 'string') {
            return parseInt(vintage, 10);
          }
          return null;
        })
        .filter(year => year !== null && !isNaN(year))
        .sort((a, b) => b - a);

        return years;
      } catch (error) {
        console.error("Error processing vintages:", error, project.Vintages);
        return [];
      }
    }
    return [];
  };

  const getPrice = (project) => {
    if (project.DefaultCarbonPricePerTon && project.DefaultCarbonPricePerTon > 0) {
      return `${project.DefaultCarbonPricePerTon.toFixed(2)} SAR`;
    }
    if (project.Vintages && project.Vintages.length > 0) {
      const firstVintage = project.Vintages[0];
      if (firstVintage.CarbonPricePerTon && firstVintage.CarbonPricePerTon > 0) {
        return `${firstVintage.CarbonPricePerTon.toFixed(2)} SAR`;
      }
    }
    return "-";
  };

  return {
    id: apiProject.id || "N/A",
    name: apiProject.ProjectName || "Unnamed Project",
    owner: apiProject.ProjectOwner
      ? `${apiProject.ProjectOwner.firstName || ""} ${
          apiProject.ProjectOwner.lastName || ""
        }`.trim() ||
        apiProject.ProjectOwner.Email ||
        "Unknown"
      : "Unknown",
    ownerEmail: apiProject.ProjectOwner?.Email || "N/A",
    standard: apiProject.StandardType || "N/A",
    country: apiProject.Country || "N/A",
    vintages: getVintageDisplay(apiProject),
    available: apiProject.AvailableStock
      ? `${apiProject.AvailableStock.toLocaleString()} tCO₂e`
      : "0 tCO₂e",
    price: getPrice(apiProject),
    status: getStatusFromProject(apiProject),
    submittedAt: apiProject.CreatedAt
      ? new Date(apiProject.CreatedAt).toLocaleDateString()
      : "N/A",
    original: apiProject,
  };
};
export const ProjectsTable = forwardRef(function ProjectsTable({ appliedFilters, isOwnerView = false }, ref) {
  const router = useRouter();
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [hasNextPage, setHasNextPage] = useState(false);
  const [totalCount, setTotalCount] = useState(0);
  const [actionLoading, setActionLoading] = useState({});
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [projectToDelete, setProjectToDelete] = useState(null);
  const [rejectDialogOpen, setRejectDialogOpen] = useState(false);
  const [projectToReject, setProjectToReject] = useState(null);
  const [approveDialogOpen, setApproveDialogOpen] = useState(false);
  const [projectToApprove, setProjectToApprove] = useState(null);
  const [vintagePricing, setVintagePricing] = useState({});
  const [defaultCarbonPrice, setDefaultCarbonPrice] = useState("");
  const [columnVisibility, setColumnVisibility] = useState({
    id: false, // Project ID disabled by default
  });
  const [currentFilters, setCurrentFilters] = useState(null);
  const [documentsDialogOpen, setDocumentsDialogOpen] = useState(false);
  const [currentProjectDocuments, setCurrentProjectDocuments] = useState([]);
  const [documentsLoading, setDocumentsLoading] = useState(false);
  const pageSize = 10;

  // Expose methods to parent component
  useImperativeHandle(ref, () => ({
    applyFilters: (filters) => {
      console.log("ProjectsTable applyFilters called with:", filters);
      setCurrentFilters(filters);
      setCurrentPage(1);
      fetchProjects(1, filters);
    }
  }));

  const fetchProjects = async (page, filters = null) => {
    try {
      setLoading(true);
      const response = await projectsService.getProjects({
        pageNumber: page,
        pageSize: pageSize,
        filters: filters,
      });

      if (response.success) {
        const formattedProjects = response.projects.map(formatProjectData);
        setProjects(formattedProjects);
        setHasNextPage(response.hasNextPage);
        setTotalCount(response.totalCount);
        setCurrentPage(page);
        setError(null);
      } else {
        setError("Failed to fetch projects");
      }
    } catch (err) {
      console.error("Error fetching projects:", err);
      setError("Failed to load projects");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProjects(1);
  }, []);

  const handleNextPage = () => {
    if (hasNextPage) {
      fetchProjects(currentPage + 1, currentFilters);
    }
  };

  const handlePreviousPage = () => {
    if (currentPage > 1) {
      fetchProjects(currentPage - 1, currentFilters);
    }
  };

  const handleAction = async (action, projectId) => {
    setActionLoading((prev) => ({ ...prev, [projectId]: true }));

    try {
      let result;
      switch (action) {
        case "approve":
          // Handle approve separately with detailed dialog
          return;
        case "reject":
          // Handle reject separately with confirmation dialog
          return;
        case "suspend":
          result = await projectsService.suspendProject(projectId);
          break;
        case "reactivate":
          result = await projectsService.reactivateProject(projectId);
          break;
        case "delete":
          // Handle delete separately with confirmation dialog
          return;
        default:
          throw new Error("Unknown action");
      }

      if (result.success) {
        // Refresh current page to show updated data
        await fetchProjects(currentPage, currentFilters);
        toast.success(result.message);
      } else {
        toast.error(result.message || "Unknown error");
      }
    } catch (error) {
      console.error(`Error performing ${action}:`, error);
      toast.error(`Failed to ${action} project. Please try again.`);
    } finally {
      setActionLoading((prev) => ({ ...prev, [projectId]: false }));
    }
  };

  const handleRejectProject = async () => {
    if (!projectToReject) return;

    setActionLoading((prev) => ({ ...prev, [projectToReject.id]: true }));

    try {
      const result = await projectsService.rejectProject(projectToReject.id);

      if (result.success) {
        await fetchProjects(currentPage, currentFilters);
        toast.success(result.message || "Project rejected successfully");
      } else {
        toast.error(result.message || "Failed to reject project");
      }
    } catch (error) {
      console.error("Error rejecting project:", error);
      toast.error("Failed to reject project. Please try again.");
    } finally {
      setActionLoading((prev) => ({ ...prev, [projectToReject.id]: false }));
      setRejectDialogOpen(false);
      setProjectToReject(null);
    }
  };

  // Approval handling functions
  const getProjectVintages = (project) => {
    if (project?.Vintages && project.Vintages.length > 0) {
      return project.Vintages.map(vintage => ({
        year: vintage.Year,
        currentPrice: vintage.CarbonPricePerTon || project.DefaultCarbonPricePerTon || 0
      })).sort((a, b) => b.year - a.year);
    }
    return [];
  };

  const handleApproveDialogOpen = (open, project = null) => {
    setApproveDialogOpen(open);
    if (open && project) {
      setProjectToApprove(project);
      const vintages = getProjectVintages(project);
      const initialPricing = {};
      vintages.forEach(vintage => {
        initialPricing[vintage.year] = vintage.currentPrice.toString();
      });
      setVintagePricing(initialPricing);
      // Initialize default carbon price from project data
      setDefaultCarbonPrice((project.DefaultCarbonPricePerTon || 0).toString());
    } else {
      setProjectToApprove(null);
      setVintagePricing({});
      setDefaultCarbonPrice("");
    }
  };

  const updateVintagePrice = (year, price) => {
    setVintagePricing(prev => ({
      ...prev,
      [year]: price
    }));
  };

  const validatePricing = () => {
    if (!projectToApprove) return { valid: false, message: "No project selected" };

    const vintages = getProjectVintages(projectToApprove);

    if (vintages.length > 0) {
      // If there are vintages, all must have valid pricing
      for (const vintage of vintages) {
        const price = parseFloat(vintagePricing[vintage.year] || "0");
        if (!price || price <= 0) {
          return { valid: false, message: `Price for vintage ${vintage.year} is required and must be greater than 0` };
        }
      }
    } else {
      // If no vintages, default carbon price is required
      const price = parseFloat(defaultCarbonPrice || "0");
      if (!price || price <= 0) {
        return { valid: false, message: "Default Carbon Price Per Ton is required and must be greater than 0" };
      }
    }

    return { valid: true };
  };

  const handleApproveProject = async () => {
    if (!projectToApprove) return;

    const validation = validatePricing();
    if (!validation.valid) {
      toast.error(validation.message);
      return;
    }

    setActionLoading((prev) => ({ ...prev, [projectToApprove.id]: true }));

    try {
      const vintages = getProjectVintages(projectToApprove);
      let pricingData = {};

      if (vintages.length > 0) {
        // Send vintage-specific pricing
        pricingData.vintages = vintages.map(vintage => ({
          year: parseInt(vintage.year),
          price: parseFloat(vintagePricing[vintage.year] || "0")
        }));
      } else {
        // Send default pricing
        pricingData.defaultPrice = parseFloat(defaultCarbonPrice || "0");
      }

      console.log('Projects table approval pricing data:', pricingData);

      const result = await projectsService.approveProject(projectToApprove.id, pricingData);

      if (result.success) {
        await fetchProjects(currentPage, currentFilters);
        toast.success(result.message || "Project approved successfully");
      } else {
        toast.error(result.message || "Failed to approve project");
      }
    } catch (error) {
      console.error("Error approving project:", error);
      toast.error("Failed to approve project. Please try again.");
    } finally {
      setActionLoading((prev) => ({ ...prev, [projectToApprove.id]: false }));
      setApproveDialogOpen(false);
      setProjectToApprove(null);
      setVintagePricing({});
      setDefaultCarbonPrice("");
    }
  };

  const downloadProjectCSV = (project) => {
    const csvData = [
      ["Field", "Value"],
      ["Project ID", project.id],
      ["Name", project.name],
      ["Owner", project.owner],
      ["Standard", project.standard],
      ["Country", project.country],
      ["Vintage", project.vintage],
      ["Available Stock", project.available],
      ["Price", project.price],
      ["Status", project.status],
      ["Created Date", project.submittedAt],
    ];

    const csvContent = csvData
      .map((row) => row.map((cell) => `"${cell}"`).join(","))
      .join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute(
      "download",
      `${project.name.replace(/[^a-z0-9]/gi, '_')}_${new Date().toISOString().split("T")[0]}.csv`
    );
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    toast.success(`${project.name} data exported successfully`);
  };

  const handleDeleteProject = async () => {
    if (!projectToDelete) return;

    setActionLoading((prev) => ({ ...prev, [projectToDelete.id]: true }));

    try {
      const result = await projectsService.deleteProject(projectToDelete.id);

      if (result.success) {
        await fetchProjects(currentPage, currentFilters);
        toast.success(result.message || "Project deleted successfully");
      } else {
        toast.error(result.message || "Failed to delete project");
      }
    } catch (error) {
      console.error("Error deleting project:", error);
      toast.error("Failed to delete project. Please try again.");
    } finally {
      setActionLoading((prev) => ({ ...prev, [projectToDelete.id]: false }));
      setDeleteDialogOpen(false);
      setProjectToDelete(null);
    }
  };

  const fetchProjectDocuments = async (projectId) => {
    setDocumentsLoading(true);
    try {
      const response = await projectsService.getProjectById(projectId);
      if (response.data?.success && response.data?.data?.Documents) {
        setCurrentProjectDocuments(response.data.data.Documents);
        setDocumentsDialogOpen(true);
      } else {
        toast.error("No documents found for this project");
        setCurrentProjectDocuments([]);
      }
    } catch (error) {
      console.error("Error fetching project documents:", error);
      toast.error("Failed to fetch project documents");
    } finally {
      setDocumentsLoading(false);
    }
  };

  const downloadDocument = (documentUrl, fileName) => {
    window.open(documentUrl, '_blank');
    toast.success(`${fileName} download started`);
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getFileIcon = (mimeType) => {
    if (mimeType?.includes('pdf')) return '📄';
    if (mimeType?.includes('image')) return '🖼️';
    if (mimeType?.includes('text') || mimeType?.includes('csv')) return '📊';
    if (mimeType?.includes('word')) return '📝';
    if (mimeType?.includes('excel') || mimeType?.includes('spreadsheet')) return '📈';
    return '📄';
  };

  const allColumns = [
    {
      accessorKey: "id",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          >
            Project ID
            <ArrowUpDown className="ml-2 h-4 w-4" />
          </Button>
        );
      },
      cell: ({ row }) => (
        <div className="font-mono text-xs">
          {row.getValue("id")?.slice(0, 8)}...
        </div>
      ),
      enableHiding: true,
    },
    {
      accessorKey: "name",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          >
            Name
            <ArrowUpDown className="ml-2 h-4 w-4" />
          </Button>
        );
      },
      cell: ({ row }) => (
        <a
          href={`https://akhdar-sa.com/dashboard/project/${row.original.id}`}
          target="_blank"
          rel="noopener noreferrer"
          className="font-medium text-blue-600 hover:text-blue-800 hover:underline cursor-pointer"
        >
          {row.getValue("name")}
        </a>
      ),
    },
    {
      accessorKey: "owner",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          >
            Owner
            <ArrowUpDown className="ml-2 h-4 w-4" />
          </Button>
        );
      },
      cell: ({ row }) => <div>{row.getValue("owner")}</div>,
    },
    {
      accessorKey: "ownerEmail",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          >
            Owner Email
            <ArrowUpDown className="ml-2 h-4 w-4" />
          </Button>
        );
      },
      cell: ({ row }) => <div className="font-mono text-sm">{row.getValue("ownerEmail")}</div>,
    },
    {
      accessorKey: "standard",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          >
            Standard
            <ArrowUpDown className="ml-2 h-4 w-4" />
          </Button>
        );
      },
      cell: ({ row }) => (
        <Badge variant="outline">{row.getValue("standard")}</Badge>
      ),
    },
    {
      accessorKey: "country",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          >
            Country
            <ArrowUpDown className="ml-2 h-4 w-4" />
          </Button>
        );
      },
      cell: ({ row }) => <div>{row.getValue("country")}</div>,
    },
    {
      accessorKey: "vintages",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          >
            Vintage
            <ArrowUpDown className="ml-2 h-4 w-4" />
          </Button>
        );
      },
      cell: ({ row }) => {
        const vintages = row.getValue("vintages");
        if (!vintages || vintages.length === 0) {
          return <div className="text-gray-500">N/A</div>;
        }

        if (vintages.length === 1) {
          return (
            <Badge variant="outline" className="text-xs">
              {vintages[0]}
            </Badge>
          );
        }

        if (vintages.length <= 3) {
          return (
            <div className="space-y-1">
              {vintages.map((year, index) => (
                <Badge key={index} variant="outline" className="text-xs mr-1">
                  {year}
                </Badge>
              ))}
            </div>
          );
        }

        // For more than 3 vintages, show latest + count with tooltip
        return (
          <div className="space-y-1" title={`All vintages: ${vintages.filter(v => v !== null && v !== undefined).join(', ')}`}>
            <Badge variant="outline" className="text-xs">
              {vintages[0]}
            </Badge>
            <div className="text-xs text-gray-500 cursor-help">
              +{vintages.length - 1} more
            </div>
          </div>
        );
      },
    },
    {
      accessorKey: "available",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          >
            Available
            <ArrowUpDown className="ml-2 h-4 w-4" />
          </Button>
        );
      },
      cell: ({ row }) => (
        <div className="font-mono">{row.getValue("available")}</div>
      ),
    },
    {
      accessorKey: "price",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          >
            Price
            <ArrowUpDown className="ml-2 h-4 w-4" />
          </Button>
        );
      },
      cell: ({ row }) => (
        <div className="font-mono">{row.getValue("price")}</div>
      ),
    },
    {
      accessorKey: "status",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          >
            Status
            <ArrowUpDown className="ml-2 h-4 w-4" />
          </Button>
        );
      },
      cell: ({ row }) => {
        const status = row.getValue("status");
        return (
          <Badge
            variant={
              status === "active"
                ? "default"
                : status === "pending"
                ? "secondary"
                : status === "suspended"
                ? "destructive"
                : status === "rejected"
                ? "destructive"
                : "outline"
            }
          >
            {status}
          </Badge>
        );
      },
    },
    {
      accessorKey: "submittedAt",
      header: ({ column }) => {
        return (
          <Button
            variant="ghost"
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          >
            Submitted
            <ArrowUpDown className="ml-2 h-4 w-4" />
          </Button>
        );
      },
      cell: ({ row }) => <div>{row.getValue("submittedAt")}</div>,
    },
    {
      id: "actions",
      enableHiding: false,
      cell: ({ row }) => {
        const project = row.original;
        return (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                className="h-8 w-8 p-0"
                onClick={() => console.log("Dropdown opened for project:", project.original)}
              >
                <span className="sr-only">Open menu</span>
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Actions</DropdownMenuLabel>

              <DropdownMenuItem
                onClick={() => {
                  console.log("View Details clicked for project:", project.original.id);
                  console.log("Full project object:", project.original);
                  const baseUrl = isOwnerView ? '/owner/projects' : '/admin/projects';
                  router.push(`${baseUrl}?id=${project.original.id}`);
                }}
              >
                <Eye className="mr-2 h-4 w-4" />
                View Details
              </DropdownMenuItem>

              {!isOwnerView && project.status !== "pending" && (
                <DropdownMenuItem
                  onClick={() => {
                    console.log("Edit Project clicked for project:", project.original.id);
                    router.push(`/admin/projects?id=${project.original.id}&mode=edit`);
                  }}
                >
                  <Edit className="mr-2 h-4 w-4" />
                  Edit Project
                </DropdownMenuItem>
              )}

              {!isOwnerView && (
                <>
                  <DropdownMenuSeparator />

                  {project.status === "pending" && (
                    <>
                      <DropdownMenuItem
                        onSelect={(e) => {
                          e.preventDefault();
                          handleApproveDialogOpen(true, project.original);
                        }}
                        disabled={actionLoading[project.original.id]}
                      >
                        <Check className="mr-2 h-4 w-4" />
                        {actionLoading[project.original.id]
                          ? "Approving..."
                          : "Approve"}
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onSelect={(e) => {
                          e.preventDefault();
                          setProjectToReject(project.original);
                          setRejectDialogOpen(true);
                        }}
                        disabled={actionLoading[project.original.id]}
                      >
                        <X className="mr-2 h-4 w-4" />
                        {actionLoading[project.original.id]
                          ? "Rejecting..."
                          : "Reject"}
                      </DropdownMenuItem>
                    </>
                  )}

                  {project.status === "active" && (
                    <DropdownMenuItem
                      onClick={() => handleAction("suspend", project.original.id)}
                      disabled={actionLoading[project.original.id]}
                    >
                      <Pause className="mr-2 h-4 w-4" />
                      {actionLoading[project.original.id]
                        ? "Suspending..."
                        : "Suspend"}
                    </DropdownMenuItem>
                  )}

                  {project.status === "suspended" && (
                    <DropdownMenuItem
                      onClick={() =>
                        handleAction("reactivate", project.original.id)
                      }
                      disabled={actionLoading[project.original.id]}
                    >
                      <Play className="mr-2 h-4 w-4" />
                      {actionLoading[project.original.id]
                        ? "Reactivating..."
                        : "Reactivate"}
                </DropdownMenuItem>
                  )}
                </>
              )}

              <DropdownMenuSeparator />

              <DropdownMenuItem
                onClick={() => fetchProjectDocuments(project.original.id)}
                disabled={documentsLoading}
              >
                <FileText className="mr-2 h-4 w-4" />
                {documentsLoading ? "Loading..." : "View Documents"}
              </DropdownMenuItem>

              <DropdownMenuItem onClick={() => downloadProjectCSV(project)}>
                <Download className="mr-2 h-4 w-4" />
                Download CSV
              </DropdownMenuItem>

              {!isOwnerView && (
                <DropdownMenuItem
                  onSelect={(e) => {
                    e.preventDefault();
                    setProjectToDelete(project.original);
                    setDeleteDialogOpen(true);
                  }}
                  className="text-red-600 focus:text-red-600"
                >
                  <Trash2 className="mr-2 h-4 w-4" />
                  Delete Project
                </DropdownMenuItem>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        );
      },
    },
  ];

  // Filter columns based on view type
  const columns = isOwnerView
    ? allColumns.filter(column =>
        column.accessorKey !== 'owner' &&
        column.accessorKey !== 'ownerEmail'
      )
    : allColumns;

  if (loading) {
    return (
      <div className="flex items-center justify-center h-32">
        <Loader2 className="h-6 w-6 animate-spin" />
        <span className="ml-2">Loading projects...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-32 text-green-500">
        <span>{error}</span>
        <Button
          variant="outline"
          className="ml-4"
          onClick={() => fetchProjects(currentPage, currentFilters)}
        >
          Retry
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <DataTable
        columns={columns}
        data={projects}
        searchKey="name"
        searchPlaceholder="Search projects..."
        hideDefaultPagination={true}
        columnVisibility={columnVisibility}
        onColumnVisibilityChange={setColumnVisibility}
      />

      <div className="flex items-center justify-between">
        <div className="text-sm text-muted-foreground">
          Showing {projects.length} of {totalCount} projects (Page {currentPage})
        </div>
        <div className="flex space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handlePreviousPage}
            disabled={currentPage === 1}
          >
            Previous
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleNextPage}
            disabled={!hasNextPage}
          >
            Next
          </Button>
        </div>
      </div>

      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Project</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete "
              {projectToDelete?.ProjectName || "this project"}"? This action
              cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDeleteDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button
              onClick={handleDeleteProject}
              disabled={actionLoading[projectToDelete?.id]}
              className="bg-red-600 hover:bg-green-700 text-white"
            >
              {actionLoading[projectToDelete?.id] ? "Deleting..." : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={rejectDialogOpen} onOpenChange={setRejectDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reject Project</DialogTitle>
            <DialogDescription>
              Are you sure you want to reject "
              {projectToReject?.ProjectName || "this project"}"? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setRejectDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={handleRejectProject}
              disabled={actionLoading[projectToReject?.id]}
            >
              {actionLoading[projectToReject?.id] ? "Rejecting..." : "Confirm Rejection"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={approveDialogOpen} onOpenChange={(open) => handleApproveDialogOpen(open)}>
        <DialogContent className="sm:max-w-[600px] max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Approve Project</DialogTitle>
            <DialogDescription>
              Review and set pricing for all vintages before approving "{projectToApprove?.ProjectName || "this project"}".
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6 py-4">
            {projectToApprove && (
              <>
                <div className="grid gap-2">
                  <Label>Project Details</Label>
                  <div className="text-sm space-y-1 bg-gray-50 p-3 rounded-lg">
                    <div><strong>Name:</strong> {projectToApprove.ProjectName}</div>
                    <div><strong>Total Credits:</strong> {projectToApprove.AvailableStock?.toLocaleString() || 0} tCO₂e</div>
                    <div><strong>Owner Email:</strong> {projectToApprove.ProjectOwner?.Email || "N/A"}</div>
                    <div><strong>Standard:</strong> {projectToApprove.StandardType || "N/A"}</div>
                    <div><strong>Country:</strong> {projectToApprove.Country || "N/A"}</div>
                  </div>
                </div>

                <div className="space-y-4">
                  <Label className="text-base font-semibold">Vintage Pricing (Required)</Label>
                  <div className="space-y-3">
                    {getProjectVintages(projectToApprove).map((vintage) => (
                      <div key={vintage.year} className="flex items-center justify-between p-3 border rounded-lg bg-white">
                        <div className="flex items-center space-x-3">
                          <div className="font-medium">Vintage {vintage.year}</div>
                          <div className="text-sm text-gray-500">
                            Current: ${vintage.currentPrice.toFixed(2)} SAR
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Label htmlFor={`table-price-${vintage.year}`} className="text-sm">
                            Price per tCO₂e:
                          </Label>
                          <Input
                            id={`table-price-${vintage.year}`}
                            type="number"
                            step="0.01"
                            min="0.01"
                            value={vintagePricing[vintage.year] || ""}
                            onChange={(e) => updateVintagePrice(vintage.year, e.target.value)}
                            placeholder="0.00"
                            className="w-24 text-right"
                            required
                          />
                          <span className="text-sm text-gray-500">SAR</span>
                        </div>
                      </div>
                    ))}
                  </div>
                  {getProjectVintages(projectToApprove).length === 0 && (
                    <div className="space-y-3">
                      <div className="text-sm text-gray-500 italic p-3 border rounded-lg bg-gray-50">
                        No vintages for this project. Please set the default carbon price per ton.
                      </div>
                      <div className="flex items-center justify-between p-3 border rounded-lg bg-white">
                        <div className="flex items-center space-x-3">
                          <div className="font-medium">Default Carbon Price Per Ton</div>
                          <div className="text-sm text-gray-500">
                            Current: {(projectToApprove?.DefaultCarbonPricePerTon || 0).toFixed(2)} SAR
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Label htmlFor="table-default-price" className="text-sm">
                            Price per tCO₂e:
                          </Label>
                          <Input
                            id="table-default-price"
                            type="number"
                            step="0.01"
                            min="0.01"
                            value={defaultCarbonPrice}
                            onChange={(e) => setDefaultCarbonPrice(e.target.value)}
                            placeholder="0.00"
                            className="w-24 text-right"
                            required
                          />
                          <span className="text-sm text-gray-500">SAR</span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => handleApproveDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleApproveProject} disabled={actionLoading[projectToApprove?.id]}>
              {actionLoading[projectToApprove?.id] ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Approving...
                </>
              ) : (
                "Confirm Approval"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Documents Dialog */}
      <Dialog open={documentsDialogOpen} onOpenChange={setDocumentsDialogOpen}>
        <DialogContent className="sm:max-w-[700px] max-h-[80vh] overflow-hidden">
          <DialogHeader>
            <DialogTitle>Project Documents</DialogTitle>
            <DialogDescription>
              View and download project documents
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 overflow-y-auto max-h-[60vh] py-4">
            {documentsLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin mr-2" />
                <span>Loading documents...</span>
              </div>
            ) : currentProjectDocuments.length > 0 ? (
              <div className="grid gap-4">
                {currentProjectDocuments.map((doc, index) => (
                  <div key={index} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 flex-1 min-w-0">
                        <div className="text-2xl flex-shrink-0">
                          {getFileIcon(doc.mimeType)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium text-gray-900 truncate">
                            {doc.originalName || doc.fileName || 'Unnamed Document'}
                          </h4>
                          <div className="flex items-center space-x-4 text-sm text-gray-500 mt-1">
                            <span>Size: {formatFileSize(doc.size || 0)}</span>
                            {doc.mimeType && (
                              <span>Type: {doc.mimeType.split('/')[1]?.toUpperCase() || 'Unknown'}</span>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="flex-shrink-0 ml-4">
                        <Button
                          onClick={() => downloadDocument(doc.url, doc.originalName || doc.fileName)}
                          size="sm"
                          variant="outline"
                          className="flex items-center space-x-2"
                        >
                          <Download className="h-4 w-4" />
                          <span>Download</span>
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                <FileText className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                <p>No documents found for this project</p>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setDocumentsDialogOpen(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

    </div>
  );
});
