import React from 'react';
import { Badge } from "@/components/ui/badge";

const ProjectUnSdgs = ({ projectData }) => {
  if (!projectData) return null;

  const sdgs = (() => {
    const sdgData = projectData.sdgs || projectData.SDGs;
    if (!sdgData) return [];
    if (Array.isArray(sdgData)) {
      return sdgData.filter(sdg => sdg && (typeof sdg === 'object' || (typeof sdg === 'string' && sdg.trim() !== '')));
    }
    if (typeof sdgData === 'string' && sdgData.trim() !== '') {
      // If it's a comma-separated string of numbers, convert to SDG objects
      return sdgData.split(',')
        .map(num => num.trim())
        .filter(num => num !== '')
        .map(num => ({
          number: parseInt(num),
          name: `SDG ${num}`
        }));
    }
    return [];
  })();

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold mb-4">UN Sustainable Development Goals</h3>

        {sdgs.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {sdgs.map((sdg, index) => (
              <div key={index} className="p-4 border rounded-lg text-center hover:shadow-md transition-shadow">
                {sdg.image && (
                  <div className="mb-3">
                    <img
                      src={sdg.image}
                      alt={sdg.name || `SDG ${sdg.number}`}
                      className="w-16 h-16 mx-auto object-cover rounded"
                    />
                  </div>
                )}
                <div className="font-medium text-sm mb-2">
                  {sdg.name || `SDG ${sdg.number}`}
                </div>
                {sdg.description && (
                  <div className="text-xs text-gray-600 leading-relaxed">
                    {sdg.description}
                  </div>
                )}
                {sdg.number && (
                  <Badge variant="outline" className="mt-2 text-xs">
                    Goal {sdg.number}
                  </Badge>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <div className="text-gray-500 text-sm">
              No SDGs chosen for this project.
            </div>
          </div>
        )}
      </div>

      {(projectData.SustainabilityImpact || projectData.EnvironmentalImpact) && (
        <div className="mt-8">
          <h4 className="font-medium mb-3">Sustainability Impact</h4>
          <p className="text-gray-700 text-sm leading-relaxed">
            {projectData.SustainabilityImpact || projectData.EnvironmentalImpact}
          </p>
        </div>
      )}
    </div>
  );
};

export default ProjectUnSdgs;