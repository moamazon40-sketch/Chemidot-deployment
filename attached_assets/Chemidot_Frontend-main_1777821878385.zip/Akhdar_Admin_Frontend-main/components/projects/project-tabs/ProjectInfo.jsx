import React from "react";
import { Badge } from "@/components/ui/badge";

const ProjectInfo = ({ projectData }) => {
  if (!projectData) return null;

  const getVintageInfo = () => {
    if (projectData.Vintages && projectData.Vintages.length > 0) {
      return projectData.Vintages;
    }
    return [];
  };

  const vintages = getVintageInfo();

  // Debug logging to see actual data
  console.log("🔍 ProjectInfo Debug:");
  console.log("📦 Raw projectData:", projectData);
  console.log("📅 Extracted vintages array:", vintages);
  console.log("💰 Individual vintage data:",
    vintages.map(v => ({
      year: v.Year,
      price: v.CarbonPricePerTon,
      rawVintage: v
    }))
  );
  console.log("🏷️ Project DefaultCarbonPricePerTon:", projectData.DefaultCarbonPricePerTon);
  console.log("🏷️ Project price field:", projectData.price);

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold mb-4 text-red-600">🔥 PROJECT INFORMATION (UPDATED)</h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <label className="font-medium text-sm text-gray-600">
                Project ID
              </label>
              <p className="text-gray-900 text-sm mt-1 font-mono">
                {projectData.id || projectData.ProjectID || "N/A"}
              </p>
            </div>

            <div>
              <label className="font-medium text-sm text-gray-600">
                Project Owner
              </label>
              <p className="text-gray-900 text-sm mt-1">
                {projectData.owner || "Unknown"}
              </p>
            </div>

            <div>
              <label className="font-medium text-sm text-gray-600">
                Country
              </label>
              <p className="text-gray-900 text-sm mt-1">
                {projectData.country || projectData.Country || "N/A"}
              </p>
            </div>

            <div>
              <label className="font-medium text-sm text-gray-600">
                Standard Type
              </label>
              <p className="text-gray-900 text-sm mt-1">
                <Badge variant="outline">
                  {projectData.standard || projectData.StandardType || "N/A"}
                </Badge>
              </p>
            </div>

            <div>
              <label className="font-medium text-sm text-gray-600">
                Project Type
              </label>
              <p className="text-gray-900 text-sm mt-1">
                {projectData.projectType ||
                  projectData.ProjectType ||
                  projectData.ProjectKind ||
                  "N/A"}
              </p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="font-medium text-sm text-gray-600">
                Available Stock
              </label>
              <p className="text-gray-900 text-sm mt-1 font-semibold">
                {projectData.AvailableStock ? `${projectData.AvailableStock.toLocaleString()} tCO₂e` : (projectData.available || "0 tCO₂e")}
              </p>
            </div>

            {vintages.length === 0 && (
              <div>
                <label className="font-medium text-sm text-gray-600">
                  Price per tCO₂e
                </label>
                <p className="text-gray-900 text-sm mt-1 font-semibold">
                  {projectData.DefaultCarbonPricePerTon && projectData.DefaultCarbonPricePerTon > 0
                    ? `${projectData.DefaultCarbonPricePerTon.toFixed(2)} SAR`
                    : (projectData.price || "-")}
                </p>
              </div>
            )}

            <div>
              <label className="font-medium text-sm text-gray-600">
                Minimum Purchase
              </label>
              <p className="text-gray-900 text-sm mt-1">
                {projectData.minimumPurchase ||
                  projectData.MinimumPurchase ||
                  1}{" "}
                tCO₂e
              </p>
            </div>

            <div>
              <label className="font-medium text-sm text-gray-600">
                Project Status
              </label>
              <p className="text-gray-900 text-sm mt-1">
                <Badge
                  variant={
                    projectData.status === "active"
                      ? "default"
                      : projectData.status === "pending"
                      ? "secondary"
                      : "destructive"
                  }
                >
                  {projectData.status || "Unknown"}
                </Badge>
              </p>
            </div>

            <div>
              <label className="font-medium text-sm text-gray-600">
                Created Date
              </label>
              <p className="text-gray-900 text-sm mt-1">
                {projectData.submittedAt || "N/A"}
              </p>
            </div>
          </div>
        </div>
      </div>

      {vintages.length > 0 && (
        <div>
          <h4 className="font-medium mb-3">Vintage Information</h4>
          <div className="space-y-3">
            {vintages.map((vintage, index) => (
              <div key={index} className="p-4 border rounded-lg">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="font-medium text-xs text-gray-600">
                      Year
                    </label>
                    <p className="text-gray-900 text-sm">
                      {vintage.Year || "N/A"}
                    </p>
                  </div>
                  <div>
                    <label className="font-medium text-xs text-gray-600">
                      Price
                    </label>
                    <p className="text-gray-900 text-sm font-semibold">
                      {vintage.CarbonPricePerTon && vintage.CarbonPricePerTon > 0 ? `${vintage.CarbonPricePerTon.toFixed(2)} SAR` : "-"}
                    </p>
                  </div>
                  <div>
                    <label className="font-medium text-xs text-gray-600">
                      Status
                    </label>
                    <p className="text-gray-900 text-sm">
                      Available
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ProjectInfo;
