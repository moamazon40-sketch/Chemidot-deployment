import React from 'react';
import { Badge } from "@/components/ui/badge";
import { Award, Calendar, FileText, ExternalLink } from 'lucide-react';

const ProjectCertification = ({ projectData }) => {
  if (!projectData) return null;

  const certifications = projectData.certifications || projectData.Certifications || [];
  const hasStandardCertification = projectData.standard || projectData.StandardType;

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold mb-4">Certifications & Standards</h3>

        {/* Primary Standard */}
        {hasStandardCertification && (
          <div className="mb-6">
            <h4 className="font-medium mb-3 flex items-center gap-2">
              <Award className="h-4 w-4" />
              Primary Certification Standard
            </h4>
            <div className="p-4 border rounded-lg bg-green-50 border-green-200">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium text-green-900">
                    {projectData.standard || projectData.StandardType}
                  </div>
                  <div className="text-sm text-green-700 mt-1">
                    Primary certification standard for this carbon offset project
                  </div>
                </div>
                <Badge variant="default" className="bg-green-600">
                  Verified
                </Badge>
              </div>
            </div>
          </div>
        )}

        {/* Additional Certifications */}
        {certifications.length > 0 ? (
          <div>
            <h4 className="font-medium mb-3 flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Additional Certifications
            </h4>
            <div className="space-y-3">
              {certifications.map((cert, index) => (
                <div key={index} className="p-4 border rounded-lg hover:shadow-sm transition-shadow">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="font-medium text-gray-900">
                        {cert.name || cert.type || cert.Name || cert.Type || `Certification ${index + 1}`}
                      </div>
                      {cert.issuer && (
                        <div className="text-sm text-gray-600 mt-1">
                          <span className="font-medium">Issued by:</span> {cert.issuer}
                        </div>
                      )}
                      {cert.description && (
                        <div className="text-sm text-gray-600 mt-1">
                          {cert.description}
                        </div>
                      )}
                      <div className="flex items-center gap-4 mt-2 text-xs text-gray-500">
                        {cert.issuedDate && (
                          <span className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            Issued: {new Date(cert.issuedDate).toLocaleDateString()}
                          </span>
                        )}
                        {cert.validUntil && (
                          <span className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            Valid until: {new Date(cert.validUntil).toLocaleDateString()}
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="ml-4 flex flex-col gap-2">
                      <Badge
                        variant={cert.status === "valid" || cert.status === "active" ? "default" : "secondary"}
                      >
                        {cert.status || "Valid"}
                      </Badge>
                      {cert.certificateUrl && (
                        <a
                          href={cert.certificateUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-xs text-blue-600 hover:text-blue-800 flex items-center gap-1"
                        >
                          <ExternalLink className="h-3 w-3" />
                          View Certificate
                        </a>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div>
            <h4 className="font-medium mb-3 flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Additional Certifications
            </h4>
            <div className="text-center py-8 border-2 border-dashed border-gray-300 rounded-lg">
              <div className="text-gray-500 text-sm mb-2">
                No additional certifications available.
              </div>
              <p className="text-xs text-gray-400">
                Additional certifications may be added by the project owner.
              </p>
            </div>
          </div>
        )}

        {/* Compliance Information */}
        {(projectData.ComplianceInfo || projectData.RegistryInfo) && (
          <div className="mt-6">
            <h4 className="font-medium mb-3">Compliance & Registry Information</h4>
            <div className="p-4 border rounded-lg bg-blue-50 border-blue-200">
              <div className="text-sm text-blue-900">
                {projectData.ComplianceInfo || projectData.RegistryInfo}
              </div>
            </div>
          </div>
        )}

        {/* Verification History */}
        {projectData.VerificationHistory && projectData.VerificationHistory.length > 0 && (
          <div className="mt-6">
            <h4 className="font-medium mb-3">Verification History</h4>
            <div className="space-y-2">
              {projectData.VerificationHistory.map((verification, index) => (
                <div key={index} className="p-3 border rounded-lg text-sm">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">{verification.verifier}</span>
                    <span className="text-gray-500">{new Date(verification.date).toLocaleDateString()}</span>
                  </div>
                  {verification.status && (
                    <div className="mt-1">
                      <Badge variant="outline" className="text-xs">
                        {verification.status}
                      </Badge>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProjectCertification;