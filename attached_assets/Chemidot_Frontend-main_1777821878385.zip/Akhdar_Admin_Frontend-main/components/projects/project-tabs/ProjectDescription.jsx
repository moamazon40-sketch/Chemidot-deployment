import React from 'react';
import { Badge } from "@/components/ui/badge";

const ProjectDescription = ({ projectData }) => {
  if (!projectData) return null;

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold mb-4">Project Description</h3>
        <p className="text-gray-700 leading-relaxed text-sm">
          {projectData.description || projectData.ProjectDescription || projectData.Description || "No description available"}
        </p>
      </div>

      {projectData.projectType && (
        <div>
          <h4 className="font-medium mb-3">Project Type</h4>
          <Badge variant="outline" className="text-sm">
            {projectData.projectType || projectData.ProjectType || projectData.ProjectKind}
          </Badge>
        </div>
      )}

      {(projectData.ProjectLocation || projectData.Location) && (
        <div>
          <h4 className="font-medium mb-3">Location</h4>
          <p className="text-gray-700 text-sm">
            {projectData.ProjectLocation || projectData.Location}
          </p>
        </div>
      )}

      {(projectData.ProjectSize || projectData.Size) && (
        <div>
          <h4 className="font-medium mb-3">Project Size</h4>
          <p className="text-gray-700 text-sm">
            {projectData.ProjectSize || projectData.Size}
          </p>
        </div>
      )}

      {(projectData.Methodology || projectData.methodology) && (
        <div>
          <h4 className="font-medium mb-3">Methodology</h4>
          <p className="text-gray-700 text-sm">
            {projectData.Methodology || projectData.methodology}
          </p>
        </div>
      )}
    </div>
  );
};

export default ProjectDescription;