import React, { useState } from 'react';
import { X } from 'lucide-react';
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

const ProjectGallery = ({ projectData }) => {
  const [selectedImage, setSelectedImage] = useState(null);
  const [isImageModalOpen, setIsImageModalOpen] = useState(false);

  if (!projectData) return null;

  const images = [];

  // Add main project image
  if (projectData.projectImageURL || projectData.ProjectImageURL) {
    images.push({
      url: projectData.projectImageURL || projectData.ProjectImageURL,
      title: "Project Main Image",
      description: "Primary project image"
    });
  }

  // Add additional project images
  if (projectData.images && projectData.images.length > 0) {
    projectData.images.forEach((image, index) => {
      images.push({
        url: image.url || image,
        title: image.title || `Project Image ${index + 1}`,
        description: image.description || `Additional project image ${index + 1}`
      });
    });
  }

  // Add project images from ProjectImages array
  if (projectData.ProjectImages && projectData.ProjectImages.length > 0) {
    projectData.ProjectImages.forEach((image, index) => {
      images.push({
        url: image.ImageURL || image.url || image,
        title: image.Title || image.title || `Project Image ${index + 1}`,
        description: image.Description || image.description || `Project gallery image ${index + 1}`
      });
    });
  }

  const handleImageClick = (image) => {
    setSelectedImage(image);
    setIsImageModalOpen(true);
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold mb-4">Project Gallery</h3>

        {images.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {images.map((image, index) => (
              <div
                key={index}
                className="border rounded-lg overflow-hidden cursor-pointer hover:shadow-lg transition-shadow group"
                onClick={() => handleImageClick(image)}
              >
                <div className="relative">
                  <img
                    src={image.url}
                    alt={image.title}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                    onError={(e) => {
                      e.target.src = '/api/placeholder/400/200';
                      e.target.alt = 'Image not available';
                    }}
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-all duration-300"></div>
                </div>
                {(image.title !== "Project Main Image" || image.description !== "Primary project image") && (
                  <div className="p-3">
                    <h4 className="font-medium text-sm text-gray-900 truncate">
                      {image.title}
                    </h4>
                    {image.description && (
                      <p className="text-xs text-gray-600 mt-1 line-clamp-2">
                        {image.description}
                      </p>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12 border-2 border-dashed border-gray-300 rounded-lg">
            <div className="text-gray-500 text-sm mb-2">
              No images available for this project.
            </div>
            <p className="text-xs text-gray-400">
              Project images may be added by the project owner.
            </p>
          </div>
        )}
      </div>

      {/* Image Modal */}
      <Dialog open={isImageModalOpen} onOpenChange={setIsImageModalOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <div className="flex items-center justify-between">
              <DialogTitle>{selectedImage?.title}</DialogTitle>
              <Button variant="ghost" size="sm" onClick={() => setIsImageModalOpen(false)}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          </DialogHeader>
          {selectedImage && (
            <div className="space-y-4">
              <img
                src={selectedImage.url}
                alt={selectedImage.title}
                className="w-full max-h-[70vh] object-contain rounded-lg"
              />
              {selectedImage.description && (
                <p className="text-gray-700 text-sm">{selectedImage.description}</p>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ProjectGallery;