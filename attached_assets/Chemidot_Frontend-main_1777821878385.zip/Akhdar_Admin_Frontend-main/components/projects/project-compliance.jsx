"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Shield, AlertTriangle, CheckCircle } from "lucide-react";
const complianceNotes = [
  {
    id: "1",
    type: "review",
    title: "Initial Compliance Review",
    note: "Project meets all VCS requirements. Documentation is complete and accurate.",
    author: "Sarah Johnson",
    date: "2024-01-16",
    status: "completed",
  },
  {
    id: "2",
    type: "flag",
    title: "Missing Monitoring Report",
    note: "Q4 2023 monitoring report is missing. Required for final approval.",
    author: "Mike Chen",
    date: "2024-02-01",
    status: "pending",
  },
  {
    id: "3",
    type: "verification",
    title: "Third-party Verification",
    note: "Verification by TÜV SÜD completed successfully. All criteria met.",
    author: "System",
    date: "2024-02-05",
    status: "completed",
  },
];
export function ProjectCompliance({ projectId }) {
  const getStatusIcon = (status) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case "pending":
        return <AlertTriangle className="h-4 w-4 text-yellow-600" />;
      default:
        return <Shield className="h-4 w-4 text-muted-foreground" />;
    }
  };
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Compliance Notes
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Add Compliance Note</label>
              <Textarea placeholder="Enter compliance notes, observations, or requirements..." />
              <Button>Add Note</Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Compliance History</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {complianceNotes.map((note) => (
              <div key={note.id} className="p-4 border rounded-lg">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2">
                    {getStatusIcon(note.status)}
                    <span className="font-medium">{note.title}</span>
                    <Badge
                      variant={
                        note.status === "completed" ? "default" : "secondary"
                      }
                    >
                      {note.status}
                    </Badge>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {note.date}
                  </div>
                </div>
                <p className="text-sm mb-2">{note.note}</p>
                <div className="text-xs text-muted-foreground">
                  By {note.author}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
