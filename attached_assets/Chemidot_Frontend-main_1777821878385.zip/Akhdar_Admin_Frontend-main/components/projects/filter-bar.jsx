"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Filter, X } from "lucide-react";
import { useState } from "react";
export function FilterBar({ onFiltersChange, isOwnerView = false }) {
  const [filters, setFilters] = useState({
    projectName: "",
    projectOwnerEmail: "",
    country: "all",
    vintageYear: "",
  });
  const [hasChanges, setHasChanges] = useState(false);
  const [appliedFilters, setAppliedFilters] = useState({
    projectName: "",
    projectOwnerEmail: "",
    country: "all",
    vintageYear: "",
  });
  const handleFilterChange = (key, value) => {
    const newFilters = {
      ...filters,
      [key]: value,
    };
    setFilters(newFilters);

    // Check if filters have changed from applied filters
    const filtersChanged =
      JSON.stringify(newFilters) !== JSON.stringify(appliedFilters);
    setHasChanges(filtersChanged);

    onFiltersChange?.(newFilters);
  };

  const applyFilters = () => {
    console.log("Applying filters:", filters);
    setAppliedFilters(filters);
    setHasChanges(false);
    onFiltersChange?.(filters, true);
  };
  const clearFilters = () => {
    const clearedFilters = {
      projectName: "",
      projectOwnerEmail: "",
      country: "all",
      vintageYear: "",
    };
    setFilters(clearedFilters);
    setAppliedFilters(clearedFilters);
    setHasChanges(false);
    onFiltersChange?.(clearedFilters, true);
  };
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center gap-2 mb-4">
          <Filter className="h-4 w-4" />
          <span className="font-medium">Filters</span>
          <Button
            variant="ghost"
            size="sm"
            onClick={clearFilters}
            className="ml-auto"
          >
            <X className="h-4 w-4 mr-1" />
            Clear All
          </Button>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <div className="space-y-2">
            <Label htmlFor="projectName">Project Name</Label>
            <Input
              id="projectName"
              placeholder="Enter project name"
              value={filters.projectName}
              onChange={(e) =>
                handleFilterChange("projectName", e.target.value)
              }
            />
            <p className="text-sm text-muted-foreground">
              Filter by project name (partial, case-insensitive)
            </p>
          </div>

          {!isOwnerView && (
            <div className="space-y-2">
              <Label htmlFor="projectOwnerEmail">Project Owner Email</Label>
              <Input
                id="projectOwnerEmail"
                placeholder="Enter project owner email"
                value={filters.projectOwnerEmail}
                onChange={(e) =>
                  handleFilterChange("projectOwnerEmail", e.target.value)
                }
              />
              <p className="text-sm text-muted-foreground">
                Filter by project owner email (partial, case-insensitive)
              </p>
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="country">Country</Label>
            <Select
              value={filters.country}
              onValueChange={(value) => handleFilterChange("country", value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select country" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All countries</SelectItem>
                <SelectItem value="afghanistan">Afghanistan</SelectItem>
                <SelectItem value="albania">Albania</SelectItem>
                <SelectItem value="algeria">Algeria</SelectItem>
                <SelectItem value="argentina">Argentina</SelectItem>
                <SelectItem value="australia">Australia</SelectItem>
                <SelectItem value="austria">Austria</SelectItem>
                <SelectItem value="bangladesh">Bangladesh</SelectItem>
                <SelectItem value="belgium">Belgium</SelectItem>
                <SelectItem value="brazil">Brazil</SelectItem>
                <SelectItem value="canada">Canada</SelectItem>
                <SelectItem value="chile">Chile</SelectItem>
                <SelectItem value="china">China</SelectItem>
                <SelectItem value="colombia">Colombia</SelectItem>
                <SelectItem value="costa-rica">Costa Rica</SelectItem>
                <SelectItem value="denmark">Denmark</SelectItem>
                <SelectItem value="egypt">Egypt</SelectItem>
                <SelectItem value="finland">Finland</SelectItem>
                <SelectItem value="france">France</SelectItem>
                <SelectItem value="germany">Germany</SelectItem>
                <SelectItem value="ghana">Ghana</SelectItem>
                <SelectItem value="greece">Greece</SelectItem>
                <SelectItem value="india">India</SelectItem>
                <SelectItem value="indonesia">Indonesia</SelectItem>
                <SelectItem value="iran">Iran</SelectItem>
                <SelectItem value="iraq">Iraq</SelectItem>
                <SelectItem value="ireland">Ireland</SelectItem>
                <SelectItem value="israel">Israel</SelectItem>
                <SelectItem value="italy">Italy</SelectItem>
                <SelectItem value="japan">Japan</SelectItem>
                <SelectItem value="jordan">Jordan</SelectItem>
                <SelectItem value="kenya">Kenya</SelectItem>
                <SelectItem value="malaysia">Malaysia</SelectItem>
                <SelectItem value="mexico">Mexico</SelectItem>
                <SelectItem value="morocco">Morocco</SelectItem>
                <SelectItem value="netherlands">Netherlands</SelectItem>
                <SelectItem value="nigeria">Nigeria</SelectItem>
                <SelectItem value="norway">Norway</SelectItem>
                <SelectItem value="pakistan">Pakistan</SelectItem>
                <SelectItem value="peru">Peru</SelectItem>
                <SelectItem value="philippines">Philippines</SelectItem>
                <SelectItem value="poland">Poland</SelectItem>
                <SelectItem value="portugal">Portugal</SelectItem>
                <SelectItem value="russia">Russia</SelectItem>
                <SelectItem value="ksa">KSA</SelectItem>
                <SelectItem value="singapore">Singapore</SelectItem>
                <SelectItem value="south-africa">South Africa</SelectItem>
                <SelectItem value="south-korea">South Korea</SelectItem>
                <SelectItem value="spain">Spain</SelectItem>
                <SelectItem value="sweden">Sweden</SelectItem>
                <SelectItem value="switzerland">Switzerland</SelectItem>
                <SelectItem value="thailand">Thailand</SelectItem>
                <SelectItem value="turkey">Turkey</SelectItem>
                <SelectItem value="ukraine">Ukraine</SelectItem>
                <SelectItem value="united-kingdom">United Kingdom</SelectItem>
                <SelectItem value="usa">USA</SelectItem>
                <SelectItem value="venezuela">Venezuela</SelectItem>
                <SelectItem value="vietnam">Vietnam</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-sm text-muted-foreground">
              Filter by country (partial, case-insensitive)
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="vintageYear">Vintage Year</Label>
            <Input
              id="vintageYear"
              type="number"
              placeholder="Enter vintage year"
              value={filters.vintageYear}
              onChange={(e) =>
                handleFilterChange("vintageYear", e.target.value)
              }
            />
            <p className="text-sm text-muted-foreground">
              Filter projects that have any vintage with this year
            </p>
          </div>
        </div>

        <div className="mt-6 flex justify-end">
          <Button
            onClick={applyFilters}
            disabled={!hasChanges}
            className={hasChanges ? "bg-green-600 hover:bg-green-700" : ""}
          >
            Apply Filters
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
