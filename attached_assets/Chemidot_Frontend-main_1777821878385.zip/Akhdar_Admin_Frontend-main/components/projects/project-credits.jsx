"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Coins, Split, Merge } from "lucide-react";
const creditLots = [
  {
    id: "LOT-001",
    issued: "1,000 tCO₂e",
    available: "650 tCO₂e",
    reserved: "200 tCO₂e",
    retired: "150 tCO₂e",
    price: "50.00 SAR",
    vintage: "2023",
    status: "active",
  },
  {
    id: "LOT-002",
    issued: "800 tCO₂e",
    available: "500 tCO₂e",
    reserved: "100 tCO₂e",
    retired: "200 tCO₂e",
    price: "50.00 SAR",
    vintage: "2023",
    status: "active",
  },
  {
    id: "LOT-003",
    issued: "650 tCO₂e",
    available: "650 tCO₂e",
    reserved: "0 tCO₂e",
    retired: "0 tCO₂e",
    price: "50.00 SAR",
    vintage: "2024",
    status: "pending",
  },
];
export function ProjectCredits({ projectId }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Coins className="h-5 w-5" />
          Credit Lots & Ledger
        </CardTitle>
      </CardHeader>

      <CardContent>
        <div className="space-y-4">
          {creditLots.map((lot) => (
            <div key={lot.id} className="p-4 border rounded-lg">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="font-mono font-medium">{lot.id}</span>
                  <Badge
                    variant={lot.status === "active" ? "default" : "secondary"}
                  >
                    {lot.status}
                  </Badge>
                  <Badge variant="outline">Vintage {lot.vintage}</Badge>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    <Split className="h-4 w-4 mr-1" />
                    Split
                  </Button>
                  <Button variant="outline" size="sm">
                    <Merge className="h-4 w-4 mr-1" />
                    Merge
                  </Button>
                </div>
              </div>

              <div className="grid gap-2 md:grid-cols-4">
                <div className="text-center p-2 bg-muted rounded">
                  <div className="font-medium">{lot.issued}</div>
                  <div className="text-xs text-muted-foreground">Issued</div>
                </div>
                <div className="text-center p-2 bg-green-50 rounded">
                  <div className="font-medium text-green-700">
                    {lot.available}
                  </div>
                  <div className="text-xs text-muted-foreground">Available</div>
                </div>
                <div className="text-center p-2 bg-yellow-50 rounded">
                  <div className="font-medium text-yellow-700">
                    {lot.reserved}
                  </div>
                  <div className="text-xs text-muted-foreground">Reserved</div>
                </div>
                <div className="text-center p-2 bg-blue-50 rounded">
                  <div className="font-medium text-blue-700">{lot.retired}</div>
                  <div className="text-xs text-muted-foreground">Retired</div>
                </div>
              </div>

              <div className="mt-2 text-right">
                <span className="font-mono font-medium">
                  {lot.price} per tCO₂e
                </span>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
