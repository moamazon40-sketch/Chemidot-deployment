"use client";

import React, { useState, useEffect, useMemo } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MapPin, Calendar, Globe, Award, ArrowLeft, Loader2 } from "lucide-react";
import Link from "next/link";
import { ApproveRejectActions } from "./approve-reject-actions";
import { apiInstance } from "@/services/api/apiInstance";
import { CARBON_OFFSET_URLS } from "@/services/api/apiConfig";
import { toast } from "sonner";
const ProjectTabs = ({ activeTab, setActiveTab }) => {
  const tabs = [
    { key: "description", label: "Description" },
    { key: "unSdgs", label: "UN SDGs" },
    { key: "projectInfo", label: "Project Info" },
    { key: "gallery", label: "Gallery" },
    { key: "certification", label: "Certification" },
  ];

  return (
    <div className="flex border-b border-gray-200 mb-6 overflow-x-auto gap-2 scrollbar-hide">
      {tabs.map((tab) => (
        <button
          key={tab.key}
          onClick={() => setActiveTab(tab.key)}
          className={`px-2 py-3 text-sm border-b-2 transition-colors whitespace-nowrap ${
            activeTab === tab.key
              ? "text-teal-600 border-teal-600 font-bold"
              : "text-gray-500 border-transparent hover:text-gray-700"
          }`}
        >
          {tab.label}
        </button>
      ))}
    </div>
  );
};

export function ProjectDetail({ projectId, isOwnerView = false }) {
  const [projectData, setProjectData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState("description");

  const fetchProjectDetails = async () => {
    try {
      setLoading(true);
      setError(null);

      const response = await apiInstance.get(
        `${CARBON_OFFSET_URLS.GET_PROJECT_BY_ID}?ProjectID=${projectId}`
      );

      if (response.data) {
        setProjectData(response.data.data || response.data);
      } else {
        throw new Error("No project data received");
      }
    } catch (error) {
      console.error("Error fetching project details:", error);
      setError(error.message || "Failed to load project details");
      toast.error("Failed to load project details");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (projectId) {
      fetchProjectDetails();
    }
  }, [projectId]);

  const formatProjectData = useMemo(() => {
    if (!projectData) return null;

    const getStatusFromProject = (project) => {
      if (project.Status === "Rejected" || project.ProjectStatus === "rejected") return "rejected";
      if (project.Status === "Active" && project.IsActive) return "active";
      if (project.Status === "Suspended" && !project.IsActive) return "suspended";
      if (project.ProjectStatus === "active" && project.IsActive) return "active";
      return "pending";
    };

    const getVintages = (project) => {
      if (project.Vintages && project.Vintages.length > 0) {
        return project.Vintages
          .filter(vintage => vintage.Year && !isNaN(vintage.Year))
          .sort((a, b) => b.Year - a.Year);
      }
      return [];
    };

    const getPrice = (project) => {
      // If there are vintages, use vintage pricing
      if (project.Vintages && project.Vintages.length > 0) {
        const firstVintage = project.Vintages[0];
        if (firstVintage.CarbonPricePerTon && firstVintage.CarbonPricePerTon > 0) {
          return `${firstVintage.CarbonPricePerTon.toFixed(2)} SAR`;
        }
      }

      // If no vintages, show DefaultCarbonPricePerTon if available
      if (project.DefaultCarbonPricePerTon && project.DefaultCarbonPricePerTon > 0) {
        return `${project.DefaultCarbonPricePerTon.toFixed(2)} SAR`;
      }

      // No vintages and no default price - return "-"
      return "-";
    };

    return {
      id: projectData.id || "N/A",
      name: projectData.ProjectName || "Unnamed Project",
      owner: projectData.ProjectOwner
        ? `${projectData.ProjectOwner.firstName || ""} ${
            projectData.ProjectOwner.lastName || ""
          }`.trim() ||
          projectData.ProjectOwner.Email ||
          "Unknown"
        : "Unknown",
      standard: projectData.StandardType || "N/A",
      country: projectData.Country || "N/A",
      vintages: getVintages(projectData),
      vintage: getVintages(projectData).length > 0 ? getVintages(projectData)[0].Year.toString() : "N/A",
      available: projectData.AvailableStock
        ? `${projectData.AvailableStock.toLocaleString()} tCO₂e`
        : "0 tCO₂e",
      price: getPrice(projectData),
      status: getStatusFromProject(projectData),
      submittedAt: projectData.CreatedAt
        ? new Date(projectData.CreatedAt).toLocaleDateString()
        : "N/A",
      description: projectData.ProjectDescription || projectData.Description || "No description available",
      projectType: projectData.ProjectType || projectData.ProjectKind || "N/A",
      minimumPurchase: projectData.MinimumPurchase || 1,
      sdgs: (() => {
        const sdgData = projectData.SDGs;
        if (!sdgData) return [];
        if (Array.isArray(sdgData)) {
          return sdgData.filter(sdg => sdg && (typeof sdg === 'object' || (typeof sdg === 'string' && sdg.trim() !== '')));
        }
        if (typeof sdgData === 'string' && sdgData.trim() !== '') {
          // If it's a comma-separated string of numbers, convert to SDG objects
          return sdgData.split(',')
            .map(num => num.trim())
            .filter(num => num !== '')
            .map(num => ({
              number: parseInt(num),
              name: `SDG ${num}`
            }));
        }
        return [];
      })(),
      certifications: projectData.Certifications || [],
      images: projectData.ProjectImages || [],
      projectGallery: projectData.ProjectGallery || [],
      projectImageURL: projectData.ProjectImageURL,
      original: projectData,
    };
  }, [projectData]);

  const renderTabContent = () => {
    if (!formatProjectData) return null;

    switch (activeTab) {
      case "description":
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Project Description</h3>

            {/* Project Image */}
            {formatProjectData.projectImageURL && (
              <div className="mb-6">
                <img
                  src={formatProjectData.projectImageURL}
                  alt={formatProjectData.name}
                  className="w-full h-screen object-cover rounded-lg border"
                />
              </div>
            )}

            <p className="text-gray-700 leading-relaxed">
              {formatProjectData.description}
            </p>
            {formatProjectData.projectType && (
              <div>
                <h4 className="font-medium mb-2">Project Type</h4>
                <Badge variant="outline">{formatProjectData.projectType}</Badge>
              </div>
            )}
          </div>
        );

      case "unSdgs":
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">UN Sustainable Development Goals</h3>
            {formatProjectData.sdgs.length > 0 ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {formatProjectData.sdgs.map((sdg, index) => {
                  const sdgNumber = sdg.number || (sdg.name && sdg.name.match(/\d+/)?.[0]) || index + 1;
                  const sdgImageUrl = `https://sdgs.un.org/sites/default/files/goals/E_SDG_Icons-${String(sdgNumber).padStart(2, '0')}.jpg`;

                  return (
                    <div key={index} className="p-3 border rounded-lg text-center hover:shadow-md transition-shadow">
                      <div className="mb-3">
                        <img
                          src={sdgImageUrl}
                          alt={`SDG ${sdgNumber} - ${sdg.name || 'UN Sustainable Development Goal'}`}
                          className="w-full h-24 object-contain rounded"
                          onError={(e) => {
                            // Fallback to alternative URL format if primary fails
                            e.target.src = `https://sustainabledevelopment.un.org/content/images/E-WEB-Goal-${String(sdgNumber).padStart(2, '0')}.png`;
                          }}
                        />
                      </div>
                      <div className="font-medium text-sm">{sdg.name || `SDG ${sdgNumber}`}</div>
                      {sdg.description && (
                        <div className="text-xs text-gray-600 mt-1">{sdg.description}</div>
                      )}
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-gray-500">No SDGs chosen for this project.</p>
            )}
          </div>
        );

      case "projectInfo":
        return (
          <div className="space-y-6">
            <h3 className="text-lg font-semibold">Project Information</h3>

            {/* Project Location */}
            <div className="bg-white border rounded-lg p-4">
              <h4 className="font-semibold mb-3">Project Location</h4>
              <div className="rounded-lg overflow-hidden">
                {formatProjectData.original?.Latitude && formatProjectData.original?.Longitude ? (
                  <iframe
                    src={`https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d15000!2d${formatProjectData.original.Longitude}!3d${formatProjectData.original.Latitude}!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2s!4v1234567890123`}
                    width="100%"
                    height="300"
                    style={{ border: 0 }}
                    allowFullScreen=""
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                    title={`Map of ${formatProjectData.name}`}
                  ></iframe>
                ) : (
                  <div className="bg-gray-100 rounded-lg p-4 min-h-[300px] flex items-center justify-center">
                    <div className="text-center text-gray-500">
                      <MapPin className="h-8 w-8 mx-auto mb-2" />
                      <p>Map view for {formatProjectData.country}</p>
                      <p className="text-sm mt-1">Coordinates not available</p>
                      <button
                        className="text-blue-500 hover:underline mt-2"
                        onClick={() => window.open(`https://www.google.com/maps/search/${encodeURIComponent(formatProjectData.country)}`, '_blank')}
                      >
                        View larger map
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Basic and Technical Details */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Basic Details */}
              <div className="bg-white border rounded-lg p-4">
                <h4 className="font-semibold mb-3">Basic Details</h4>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Project Name:</span>
                    <span className="font-medium">{formatProjectData.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Category:</span>
                    <span className="font-medium">{formatProjectData.projectType}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Project Kind:</span>
                    <span className="font-medium">{formatProjectData.original?.ProjectKind || 'Carbon Removal'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Location:</span>
                    <span className="font-medium">{formatProjectData.country}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Status:</span>
                    <span className="font-medium capitalize">{formatProjectData.status}</span>
                  </div>
                </div>
              </div>

              {/* Technical Details */}
              <div className="bg-white border rounded-lg p-4">
                <h4 className="font-semibold mb-3">Technical Details</h4>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Standard:</span>
                    <span className="font-medium">{formatProjectData.standard}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Registry:</span>
                    <span className="font-medium">{formatProjectData.original?.Registry || 'CDM Registry'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Mechanism:</span>
                    <span className="font-medium">{formatProjectData.original?.Mechanism || 'Avoidance'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Available Stock:</span>
                    <span className="font-medium">{formatProjectData.available}</span>
                  </div>
                  {formatProjectData.vintages.length > 0 ? (
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-gray-600">Vintages:</span>
                      </div>
                      <div className="ml-4">
                        <div className="space-y-1">
                          {formatProjectData.vintages.map((vintage, index) => (
                            <div key={index} className="flex justify-between">
                              <span className="text-gray-500">{vintage.Year}:</span>
                              <span className="font-medium">
                                {vintage.CarbonPricePerTon && vintage.CarbonPricePerTon > 0
                                  ? `${vintage.CarbonPricePerTon.toFixed(2)} SAR`
                                  : "Pending pricing"}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="flex justify-between">
                      <span className="text-gray-600">Price per tCO₂e:</span>
                      <span className="font-medium">{formatProjectData.price}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Description */}
            <div className="bg-white border rounded-lg p-4">
              <h4 className="font-semibold mb-3">Description</h4>
              <p className="text-gray-700 leading-relaxed">
                {formatProjectData.description}
              </p>
            </div>
          </div>
        );

      case "gallery":
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Project Gallery</h3>
            {formatProjectData.projectImageURL || formatProjectData.projectGallery.length > 0 || formatProjectData.images.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {formatProjectData.projectImageURL && (
                  <div className="border rounded-lg overflow-hidden">
                    <img
                      src={formatProjectData.projectImageURL}
                      alt="Project main image"
                      className="w-full h-48 object-cover"
                    />
                    <div className="p-2 bg-gray-50">
                      <p className="text-xs text-gray-600">Main Project Image</p>
                    </div>
                  </div>
                )}
                {formatProjectData.projectGallery.map((image, index) => (
                  <div key={index} className="border rounded-lg overflow-hidden">
                    <img
                      src={image.url}
                      alt={image.originalName || `Gallery image ${index + 1}`}
                      className="w-full h-48 object-cover"
                    />
                    <div className="p-2 bg-gray-50">
                      <p className="text-xs text-gray-600 truncate" title={image.originalName}>
                        {image.originalName || `Gallery image ${index + 1}`}
                      </p>
                      <p className="text-xs text-gray-500">
                        {image.mimeType} • {(image.size / 1024).toFixed(1)} KB
                      </p>
                    </div>
                  </div>
                ))}
                {formatProjectData.images.map((image, index) => (
                  <div key={`legacy-${index}`} className="border rounded-lg overflow-hidden">
                    <img
                      src={image.url || image}
                      alt={`Project image ${index + 1}`}
                      className="w-full h-48 object-cover"
                    />
                    <div className="p-2 bg-gray-50">
                      <p className="text-xs text-gray-600">Legacy Image {index + 1}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500">No images available for this project.</p>
            )}
          </div>
        );

      case "certification":
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Certifications</h3>
            {formatProjectData.certifications.length > 0 ? (
              <div className="space-y-3">
                {formatProjectData.certifications.map((cert, index) => (
                  <div key={index} className="p-4 border rounded-lg">
                    <div className="font-medium">{cert.name || cert.type}</div>
                    {cert.issuer && (
                      <div className="text-sm text-gray-600">Issued by: {cert.issuer}</div>
                    )}
                    {cert.validUntil && (
                      <div className="text-sm text-gray-600">
                        Valid until: {new Date(cert.validUntil).toLocaleDateString()}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-4 border rounded-lg">
                <div className="font-medium">{formatProjectData.standard}</div>
                <div className="text-sm text-gray-600">Primary certification standard</div>
              </div>
            )}
          </div>
        );

      default:
        return null;
    }
  };

  if (!projectId) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <h3 className="text-xl font-semibold text-gray-900 mb-2">
            No Project ID
          </h3>
          <p className="text-gray-600 mb-4">
            No project ID provided in the URL.
          </p>
          <Button asChild>
            <Link href={isOwnerView ? "/owner/projects" : "/admin/projects"}>Back to Projects</Link>
          </Button>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin" />
        <span className="ml-2">Loading project details...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <h3 className="text-xl font-semibold text-gray-900 mb-2">
            Error Loading Project
          </h3>
          <p className="text-gray-600 mb-4">{error}</p>
          <div className="space-x-2">
            <Button onClick={fetchProjectDetails}>Retry</Button>
            <Button variant="outline" asChild>
              <Link href={isOwnerView ? "/owner/projects" : "/admin/projects"}>Back to Projects</Link>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  if (!formatProjectData) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <h3 className="text-xl font-semibold text-gray-900 mb-2">
            No Project Data
          </h3>
          <p className="text-gray-600 mb-4">Project details are not available.</p>
          <Button asChild>
            <Link href={isOwnerView ? "/owner/projects" : "/admin/projects"}>Back to Projects</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" asChild>
          <Link href="/admin/projects">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Projects
          </Link>
        </Button>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
            <div className="space-y-2 flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <CardTitle className="text-2xl">{formatProjectData.name}</CardTitle>
                <Badge
                  variant={
                    formatProjectData.status === "active"
                      ? "default"
                      : formatProjectData.status === "pending"
                      ? "secondary"
                      : "destructive"
                  }
                >
                  {formatProjectData.status}
                </Badge>
              </div>
              <CardDescription>
                <div className="flex items-center gap-4 text-sm flex-wrap">
                  <span className="flex items-center gap-1">
                    <Globe className="h-4 w-4" />
                    {formatProjectData.owner}
                  </span>
                  <span className="flex items-center gap-1">
                    <MapPin className="h-4 w-4" />
                    {formatProjectData.country}
                  </span>
                  <span className="flex items-center gap-1">
                    <Award className="h-4 w-4" />
                    {formatProjectData.standard}
                  </span>
                  {formatProjectData.vintages.length > 0 ? (
                    <span className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      {formatProjectData.vintages.length > 1
                        ? `Vintages ${formatProjectData.vintages.map(v => v.Year).join(', ')}`
                        : `Vintage ${formatProjectData.vintage}`}
                    </span>
                  ) : formatProjectData.price !== '-' ? (
                    <span className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      Default Price: {formatProjectData.price}
                    </span>
                  ) : null}
                </div>
              </CardDescription>
            </div>

            {!isOwnerView && formatProjectData.status === "pending" && (
              <div className="flex-shrink-0">
                <ApproveRejectActions
                  project={formatProjectData}
                  onSuccess={fetchProjectDetails}
                />
              </div>
            )}
          </div>
        </CardHeader>

        <CardContent>
          <div className={`grid gap-4 ${formatProjectData.price !== '-' ? 'md:grid-cols-3' : 'md:grid-cols-2'}`}>
            <div className="text-center p-4 border rounded-lg">
              <div className="text-2xl font-bold text-primary">
                {formatProjectData.available}
              </div>
              <div className="text-sm text-muted-foreground">Available</div>
            </div>
            {formatProjectData.price !== '-' && (
              <div className="text-center p-4 border rounded-lg">
                <div className="text-2xl font-bold">{formatProjectData.price}</div>
                <div className="text-sm text-muted-foreground">
                  Price per tCO₂e
                </div>
              </div>
            )}
            <div className="text-center p-4 border rounded-lg">
              <div className="text-2xl font-bold text-orange-600">
                {formatProjectData.minimumPurchase} tCO₂e
              </div>
              <div className="text-sm text-muted-foreground">
                Minimum Purchase
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-4">
        <ProjectTabs activeTab={activeTab} setActiveTab={setActiveTab} />
        <div className="min-h-[300px]">
          {renderTabContent()}
        </div>
      </div>
    </div>
  );
}
