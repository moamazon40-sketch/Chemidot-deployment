"use client";

import React, { useState, useEffect, useMemo } from "react";
import { useParams } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { projectsService } from "@/services/api/projectsService";
import ProjectTabs from "./ProjectTabsSimple";

// Tab components
import ProjectDescription from "./project-tabs/ProjectDescription";
import ProjectUnSdgs from "./project-tabs/ProjectUnSdgs";
import ProjectInfo from "./project-tabs/ProjectInfo";
import ProjectGallery from "./project-tabs/ProjectGallery";
import ProjectCertification from "./project-tabs/ProjectCertification";

const ProjectDetailsPage = () => {
  const params = useParams();

  // Follow the EXACT same state structure as DashboardProject
  const lang = "en"; // Default to English since we don't have i18n setup
  const isArabic = lang === "ar";
  const direction = isArabic ? "rtl" : "ltr";

  const [activeTab, setActiveTab] = useState("Description");
  const [projectData, setProjectData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Fetch project data - same pattern as DashboardProject
  useEffect(() => {
    const fetchProjectData = async () => {
      if (!params.id) return;

      try {
        setLoading(true);
        setError(null);
        const response = await projectsService.getProjectById(params.id);
        const rawProjectData = response?.data?.data || response?.data;
        setProjectData(rawProjectData);
      } catch (err) {
        console.error("Error fetching project:", err);
        setError(err.message || "Failed to load project details");
      } finally {
        setLoading(false);
      }
    };

    fetchProjectData();
  }, [params.id]);

  // Create the same outlet context pattern
  const outletContext = { projectData };

  const renderTabContent = () => {
    if (!projectData) return null;

    switch (activeTab) {
      case "Description":
        return <ProjectDescription projectData={projectData} />;
      case "UN SDGs":
        return <ProjectUnSdgs projectData={projectData} />;
      case "Project Info":
        return <ProjectInfo projectData={projectData} />;
      case "Gallery":
        return <ProjectGallery projectData={projectData} />;
      case "Certification":
        return <ProjectCertification projectData={projectData} />;
      default:
        return null;
    }
  };

  // EXACT same error handling as DashboardProject
  if (!params.id) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <h3 className="text-xl font-semibold text-gray-900 mb-2">
            No Project ID
          </h3>
          <p className="text-gray-600 mb-4">
            No project ID provided in the URL.
          </p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <h3 className="text-xl font-semibold text-gray-900 mb-2">
            Error Loading Project
          </h3>
          <p className="text-gray-600 mb-4">
            {error.message || "Failed to load project details."}
          </p>
        </div>
      </div>
    );
  }

  if (!projectData) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  // EXACT same return structure as DashboardProject
  return (
    <>
      <div className="min-h-full bg-bg">
        {/* Main Content - EXACT same structure */}
        <div
          className="relative -mt-20 sm:-mt-32 md:-mt-40 z-20 py-4 text-xs"
          dir={direction}
        >
          <div className="px-5 xs:px-10 sm:px-7 md:px-6 lg:px-8 xl:px-14 lg:mx-8 xl:mx-16 2xl:mx-24">
            <div className="relative bg-bg pt-4 pb-20 rounded-xl sm:rounded-4xl md:rounded-[50px] lg:rounded-[80px]">
              {/* Arabic Layout */}
              {isArabic ? (
                <div
                  className={`relative flex flex-col lg:flex-row gap-2 lg:gap-4 lg:flex-row-reverse`}
                >
                  {/* Content - Full width (no purchase card) */}
                  <div className="lg:w-[100%] py-4 px-2 sm:px-4 lg:px-0 lg:pr-15">
                    <ProjectTabs
                      activeTab={activeTab}
                      setActiveTab={setActiveTab}
                    />
                    <div className="text-right">
                      {renderTabContent()}
                    </div>
                  </div>
                </div>
              ) : (
                /* English Layout - EXACT same structure */
                <div
                  className={`relative grid grid-cols-1 lg:grid-cols-10 gap-2 lg:gap-4`}
                >
                  {/* Content - Full 10 columns (no purchase card) */}
                  <div className="lg:col-span-10 lg:order-1 lg:pl-15 py-4">
                    <ProjectTabs
                      activeTab={activeTab}
                      setActiveTab={setActiveTab}
                    />
                    <div className="text-left">
                      {renderTabContent()}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* ProjectOwnersCard - same as original */}
        {/* Note: Commenting out since we don't have this component */}
        {/* <ProjectOwnersCard /> */}
      </div>
    </>
  );
};

export default ProjectDetailsPage;