"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, User, Edit, Eye, Check, X } from "lucide-react";
const auditEntries = [
  {
    id: "1",
    action: "Project Submitted",
    user: "EcoGuard Brazil",
    timestamp: "2024-01-15 10:30:00",
    details: "Initial project submission with all required documents",
    type: "create",
  },
  {
    id: "2",
    action: "Document Uploaded",
    user: "EcoGuard Brazil",
    timestamp: "2024-01-18 14:22:00",
    details: "Added shapefile boundaries (Shapefile_boundaries.zip)",
    type: "update",
  },
  {
    id: "3",
    action: "Compliance Review Started",
    user: "Sarah Johnson",
    timestamp: "2024-01-20 09:15:00",
    details: "Assigned to compliance officer for initial review",
    type: "review",
  },
  {
    id: "4",
    action: "Price Updated",
    user: "Mike Chen",
    timestamp: "2024-01-22 16:45:00",
    details: "Price changed from 48.00 SAR to 50.00 SAR per tCO₂e",
    type: "update",
    changes: {
      field: "price",
      before: "48.00 SAR",
      after: "50.00 SAR",
    },
  },
  {
    id: "5",
    action: "Compliance Note Added",
    user: "Sarah Johnson",
    timestamp: "2024-02-01 11:30:00",
    details: "Added note about missing Q4 2023 monitoring report",
    type: "review",
  },
  {
    id: "6",
    action: "Document Uploaded",
    user: "EcoGuard Brazil",
    timestamp: "2024-02-05 08:20:00",
    details: "Added monitoring report (Monitoring Report Q1 2024.pdf)",
    type: "update",
  },
];
export function ProjectAuditLog({ projectId }) {
  const getActionIcon = (type) => {
    switch (type) {
      case "create":
        return <Check className="h-4 w-4 text-green-600" />;
      case "update":
        return <Edit className="h-4 w-4 text-blue-600" />;
      case "review":
        return <Eye className="h-4 w-4 text-orange-600" />;
      case "reject":
        return <X className="h-4 w-4 text-red-600" />;
      default:
        return <Clock className="h-4 w-4 text-muted-foreground" />;
    }
  };
  const getActionBadge = (type) => {
    switch (type) {
      case "create":
        return <Badge variant="default">Created</Badge>;
      case "update":
        return <Badge variant="secondary">Updated</Badge>;
      case "review":
        return <Badge variant="outline">Review</Badge>;
      case "reject":
        return <Badge variant="destructive">Rejected</Badge>;
      default:
        return <Badge variant="outline">Action</Badge>;
    }
  };
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Clock className="h-5 w-5" />
          Audit Trail
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {auditEntries.map((entry, index) => (
            <div key={entry.id} className="flex gap-4">
              <div className="flex flex-col items-center">
                <div className="flex items-center justify-center w-8 h-8 rounded-full border bg-background">
                  {getActionIcon(entry.type)}
                </div>
                {index < auditEntries.length - 1 && (
                  <div className="w-px h-8 bg-border mt-2" />
                )}
              </div>

              <div className="flex-1 pb-4">
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-medium">{entry.action}</span>
                  {getActionBadge(entry.type)}
                </div>
                <p className="text-sm text-muted-foreground mb-2">
                  {entry.details}
                </p>
                {entry.changes && (
                  <div className="text-xs bg-muted p-2 rounded">
                    <span className="font-medium">{entry.changes.field}:</span>{" "}
                    <span className="line-through text-red-600">
                      {entry.changes.before}
                    </span>{" "}
                    →{" "}
                    <span className="text-green-600">
                      {entry.changes.after}
                    </span>
                  </div>
                )}
                <div className="flex items-center gap-2 text-xs text-muted-foreground mt-2">
                  <User className="h-3 w-3" />
                  <span>{entry.user}</span>
                  <span>•</span>
                  <span>{entry.timestamp}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
