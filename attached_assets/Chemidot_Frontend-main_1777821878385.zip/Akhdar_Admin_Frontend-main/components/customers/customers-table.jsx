"use client";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { DataTable } from "@/components/ui/data-table";
import { TablePagination } from "@/components/ui/table-pagination";
import {
  ArrowUpDown,
  MoreHorizontal,
  Download,
  Loader2,
  Building,
  Calculator,
  Leaf,
  FolderOpen,
  Eye,
} from "lucide-react";
import { forwardRef, useImperativeHandle, useState, useEffect } from "react";
import { customersService } from "@/services/api/customersService";
import { toast } from "sonner";

const formatCustomerData = (apiCustomer) => {
  // Safely extract arrays with fallback to empty arrays
  const calculations = Array.isArray(apiCustomer.Calculations) ? apiCustomer.Calculations : [];
  const offsets = Array.isArray(apiCustomer.CarbonOffsets) ? apiCustomer.CarbonOffsets : [];
  const projects = Array.isArray(apiCustomer.RecentProjects) ? apiCustomer.RecentProjects : [];

  return {
    id: apiCustomer.UserID,
    name: `${apiCustomer.FirstName || ""} ${apiCustomer.LastName || ""}`.trim() || "Unknown",
    email: apiCustomer.Email || "-",
    phone: apiCustomer.PhoneNumber || "-",
    userType: apiCustomer.UserType || "-",
    companyName: apiCustomer.CompanyName || null,
    companyId: apiCustomer.CompanyID || null,
    totalCalculations: calculations.length,
    totalOffsets: offsets.length,
    totalProjects: projects.length,
    totalEmissions: calculations.reduce((sum, calc) => sum + (parseFloat(calc.TotalEmissions) || 0), 0),
    totalSpent: offsets.reduce((sum, offset) => sum + (parseFloat(offset.PaymentAmountInSAR) || 0), 0),
    createdAt: apiCustomer.createdAt ? new Date(apiCustomer.createdAt).toLocaleDateString() : "-",
    updatedAt: apiCustomer.updatedAt ? new Date(apiCustomer.updatedAt).toLocaleDateString() :
               apiCustomer.createdAt ? new Date(apiCustomer.createdAt).toLocaleDateString() : "-",
    calculations: calculations,
    offsets: offsets,
    projects: projects,
    original: apiCustomer,
  };
};

const CustomersTable = forwardRef(({ appliedFilters }, ref) => {
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [hasNextPage, setHasNextPage] = useState(false);
  const [totalCount, setTotalCount] = useState(0);
  const pageSize = 10;

  const fetchCustomers = async (page = 1, filters = null) => {
    try {
      setLoading(true);
      setError(null);

      const response = await customersService.getCustomers({
        pageNumber: page,
        pageSize: pageSize,
        filters: filters,
      });

      if (response.success) {
        const formattedCustomers = response.customers.map(formatCustomerData);
        setCustomers(formattedCustomers);
        setHasNextPage(response.hasNextPage);
        setTotalCount(response.totalCount);
        setCurrentPage(page);
        setError(null);
      } else {
        setError("Failed to fetch customers");
      }
    } catch (err) {
      console.error("Error fetching customers:", err);
      setError("Failed to load customers");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCustomers(1, appliedFilters);
  }, [appliedFilters]);

  useImperativeHandle(ref, () => ({
    applyFilters: (filters) => {
      console.log("CustomersTable: Applying filters", filters);
      fetchCustomers(1, filters);
    },
  }));

  const handleNextPage = () => {
    if (hasNextPage) {
      fetchCustomers(currentPage + 1, appliedFilters);
    }
  };

  const handlePreviousPage = () => {
    if (currentPage > 1) {
      fetchCustomers(currentPage - 1, appliedFilters);
    }
  };

  const downloadCustomerCSV = (customer) => {
    // Create CSV data for individual customer
    const csvData = [
      ["Field", "Value"],
      ["Customer ID", customer.id],
      ["Name", customer.name],
      ["Email", customer.email],
      ["Phone", customer.phone],
      ["User Type", customer.userType],
      ["Company Name", customer.companyName || "-"],
      ["Total Calculations", customer.totalCalculations],
      ["Total Offsets", customer.totalOffsets],
      ["Total Projects", customer.totalProjects],
      ["Total Emissions", customer.totalEmissions.toFixed(2)],
      ["Total Spent", `${customer.totalSpent.toLocaleString()} SAR`],
      ["Registered", customer.createdAt],
      ["Last Updated", customer.updatedAt],
    ];

    const csvContent = csvData.map(row =>
      row.map(cell => `"${cell}"`).join(",")
    ).join("\\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `customer_${customer.id}_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    toast.success(`Customer data for ${customer.name} exported successfully`);
  };

  const CalculationsModal = ({ customer }) => (
    <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2">
          <Calculator className="h-5 w-5" />
          {customer.name} - Carbon Calculations ({customer.totalCalculations})
        </DialogTitle>
      </DialogHeader>
      <div className="space-y-4">
        {customer.calculations.length === 0 ? (
          <p className="text-center text-muted-foreground py-8">No calculations found</p>
        ) : (
          customer.calculations.map((calc, index) => (
            <div key={index} className="border rounded-lg p-4 space-y-2">
              <div className="flex justify-between items-start">
                <h3 className="font-semibold">Calculation #{index + 1}</h3>
                <Badge variant="outline">{calc.TotalEmissions?.toFixed(2) || 0} tCO2e</Badge>
              </div>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="font-medium">Power:</span> {calc.power || "0"} kWh
                </div>
                <div>
                  <span className="font-medium">Gas:</span> {calc.gas ? parseFloat(calc.gas).toFixed(2) : "0"} units
                </div>
                <div>
                  <span className="font-medium">Vehicles:</span> {calc.vehicles || "0"}
                </div>
                <div>
                  <span className="font-medium">Flights:</span> {calc.flights || "0"} km
                </div>
                <div>
                  <span className="font-medium">Waste:</span> {calc.waste || "0"} kg
                </div>
                <div>
                  <span className="font-medium">Date:</span> {calc.createdAt ? new Date(calc.createdAt).toLocaleDateString() : "-"}
                </div>
              </div>
              {calc.Description && (
                <div className="text-sm">
                  <span className="font-medium">Description:</span> {calc.Description}
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </DialogContent>
  );

  const OffsetsModal = ({ customer }) => (
    <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2">
          <Leaf className="h-5 w-5" />
          {customer.name} - Carbon Offsets ({customer.totalOffsets})
        </DialogTitle>
      </DialogHeader>
      <div className="space-y-4">
        {customer.offsets.length === 0 ? (
          <p className="text-center text-muted-foreground py-8">No offsets found</p>
        ) : (
          customer.offsets.map((offset, index) => (
            <div key={index} className="border rounded-lg p-4 space-y-2">
              <div className="flex justify-between items-start">
                <h3 className="font-semibold">Offset #{index + 1}</h3>
                <Badge variant="default">{offset.PaymentAmountInSAR?.toLocaleString() || 0} SAR</Badge>
              </div>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="font-medium">Project:</span> {offset.ProjectName || "-"}
                </div>
                <div>
                  <span className="font-medium">Date:</span> {offset.CreatedAt ? new Date(offset.CreatedAt).toLocaleDateString() : "-"}
                </div>
                <div>
                  <span className="font-medium">Carbon Amount:</span> {offset.CarbonAmount || "0"} tCO2e
                </div>
                <div>
                  <span className="font-medium">Payment Status:</span> {offset.PaymentStatus || "-"}
                </div>
                <div>
                  <span className="font-medium">Project Type:</span> {offset.ProjectType || "-"}
                </div>
                <div>
                  <span className="font-medium">Country:</span> {offset.Country || "-"}
                </div>
                <div>
                  <span className="font-medium">Project Kind:</span> {offset.ProjectKind || "-"}
                </div>
                <div>
                  <span className="font-medium">Partners:</span> {offset.Partners || "-"}
                </div>
              </div>
              {offset.ProjectImpact && (
                <div className="text-sm">
                  <span className="font-medium">Project Impact:</span> {offset.ProjectImpact}
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </DialogContent>
  );

  const ProjectsModal = ({ customer }) => (
    <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2">
          <FolderOpen className="h-5 w-5" />
          {customer.name} - Recent Projects ({customer.totalProjects})
        </DialogTitle>
      </DialogHeader>
      <div className="space-y-4">
        {customer.projects.length === 0 ? (
          <p className="text-center text-muted-foreground py-8">No projects found</p>
        ) : (
          customer.projects.map((project, index) => (
            <div key={index} className="border rounded-lg p-4 space-y-2">
              <div className="flex justify-between items-start">
                <h3 className="font-semibold">{project.Projectname || `Project #${index + 1}`}</h3>
                <Badge variant="outline">{project.Registry || "-"}</Badge>
              </div>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="font-medium">Type:</span> {project.ProjectType || "-"}
                </div>
                <div>
                  <span className="font-medium">Country:</span> {project.Country || "-"}
                </div>
                <div>
                  <span className="font-medium">Coordinates:</span> {project.Latitude && project.Longitude ? `${project.Latitude}, ${project.Longitude}` : "-"}
                </div>
                <div>
                  <span className="font-medium">SDGs:</span> {project.SDGs && project.SDGs.length > 0 ? project.SDGs.join(", ") : "-"}
                </div>
              </div>
              {project.Description && (
                <div className="text-sm">
                  <span className="font-medium">Description:</span> {project.Description}
                </div>
              )}
              {project.ProjectImageURL && (
                <div className="mt-2">
                  <img
                    src={project.ProjectImageURL}
                    alt={project.Projectname || "Project"}
                    className="w-full h-32 object-cover rounded-md"
                  />
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </DialogContent>
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin" />
        <span className="ml-2">Loading customers...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <h3 className="text-xl font-semibold text-gray-900 mb-2">
            Error Loading Customers
          </h3>
          <p className="text-gray-600 mb-4">{error}</p>
          <Button onClick={() => fetchCustomers(currentPage, appliedFilters)}>
            Retry
          </Button>
        </div>
      </div>
    );
  }

  const columns = [
    {
      accessorKey: "name",
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          className="h-auto p-0"
        >
          Customer Name
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      ),
      cell: ({ row }) => (
        <div className="flex items-center space-x-2">
          <div className="flex flex-col">
            <span className="font-medium">{row.getValue("name")}</span>
            <span className="text-sm text-muted-foreground">{row.original.userType}</span>
          </div>
        </div>
      ),
    },
    {
      accessorKey: "email",
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          className="h-auto p-0"
        >
          Email
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      ),
      cell: ({ row }) => (
        <div className="flex flex-col">
          <span className="font-mono text-sm">{row.getValue("email")}</span>
          {row.original.companyName && (
            <div className="flex items-center mt-1">
              <Building className="mr-1 h-3 w-3 text-muted-foreground" />
              <span className="text-xs text-muted-foreground">{row.original.companyName}</span>
            </div>
          )}
        </div>
      ),
    },
    {
      accessorKey: "phone",
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          className="h-auto p-0"
        >
          Phone
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      ),
      cell: ({ row }) => (
        <span className="font-mono text-sm">{row.getValue("phone")}</span>
      ),
    },
    {
      accessorKey: "totalCalculations",
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          className="h-auto p-0"
        >
          Calculations
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      ),
      cell: ({ row }) => {
        const customer = row.original;
        return (
          <div className="text-center">
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="ghost" className="p-1 h-auto flex items-center gap-1 hover:bg-muted/50 rounded-md">
                  <Badge variant="outline" className="font-mono">
                    {row.getValue("totalCalculations")}
                  </Badge>
                  <Eye className="h-3 w-3 text-muted-foreground opacity-60 hover:opacity-100 transition-opacity" />
                </Button>
              </DialogTrigger>
              <CalculationsModal customer={customer} />
            </Dialog>
          </div>
        );
      },
    },
    {
      accessorKey: "totalOffsets",
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          className="h-auto p-0"
        >
          Offsets
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      ),
      cell: ({ row }) => {
        const customer = row.original;
        return (
          <div className="text-center">
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="ghost" className="p-1 h-auto flex items-center gap-1 hover:bg-muted/50 rounded-md">
                  <Badge
                    variant={row.getValue("totalOffsets") > 0 ? "default" : "secondary"}
                    className="font-mono"
                  >
                    {row.getValue("totalOffsets")}
                  </Badge>
                  <Eye className="h-3 w-3 text-muted-foreground opacity-60 hover:opacity-100 transition-opacity" />
                </Button>
              </DialogTrigger>
              <OffsetsModal customer={customer} />
            </Dialog>
          </div>
        );
      },
    },
    {
      accessorKey: "totalProjects",
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          className="h-auto p-0"
        >
          Projects
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      ),
      cell: ({ row }) => {
        const customer = row.original;
        return (
          <div className="text-center">
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="ghost" className="p-1 h-auto flex items-center gap-1 hover:bg-muted/50 rounded-md">
                  <Badge variant="outline" className="font-mono">
                    {row.getValue("totalProjects")}
                  </Badge>
                  <Eye className="h-3 w-3 text-muted-foreground opacity-60 hover:opacity-100 transition-opacity" />
                </Button>
              </DialogTrigger>
              <ProjectsModal customer={customer} />
            </Dialog>
          </div>
        );
      },
    },
    {
      accessorKey: "totalSpent",
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          className="h-auto p-0"
        >
          Total Spent
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      ),
      cell: ({ row }) => {
        const amount = row.getValue("totalSpent");
        return (
          <div className="font-mono text-sm">
            {amount > 0 ? `${amount.toLocaleString()} SAR` : "-"}
          </div>
        );
      },
    },
    {
      accessorKey: "createdAt",
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          className="h-auto p-0"
        >
          Registered
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      ),
      cell: ({ row }) => <div className="text-sm">{row.getValue("createdAt")}</div>,
    },
    {
      id: "actions",
      enableHiding: false,
      cell: ({ row }) => {
        const customer = row.original;
        return (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-8 w-8 p-0">
                <span className="sr-only">Open menu</span>
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => downloadCustomerCSV(customer)}>
                <Download className="mr-2 h-4 w-4" />
                Download CSV
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        );
      },
    },
  ];

  return (
    <div className="space-y-4">
      <DataTable
        columns={columns}
        data={customers}
        hideDefaultPagination={true}
      />

      <TablePagination
        currentItems={customers.length}
        totalCount={totalCount}
        currentPage={currentPage}
        itemName="customers"
        onPreviousPage={handlePreviousPage}
        onNextPage={handleNextPage}
        canPreviousPage={currentPage > 1}
        canNextPage={hasNextPage}
      />
    </div>
  );
});

CustomersTable.displayName = "CustomersTable";

export { CustomersTable };