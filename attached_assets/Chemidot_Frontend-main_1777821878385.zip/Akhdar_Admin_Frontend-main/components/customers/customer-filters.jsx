"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Filter, X } from "lucide-react";

export function CustomerFilters({ onFiltersChange }) {
  const [filters, setFilters] = useState({
    userEmail: ""
  });
  const [hasChanges, setHasChanges] = useState(false);
  const [appliedFilters, setAppliedFilters] = useState({
    userEmail: ""
  });

  const handleFilterChange = (key, value) => {
    const newFilters = {
      ...filters,
      [key]: value,
    };
    setFilters(newFilters);

    // Check if filters have changed from applied filters
    const filtersChanged = JSON.stringify(newFilters) !== JSON.stringify(appliedFilters);
    setHasChanges(filtersChanged);

    onFiltersChange?.(newFilters);
  };

  const applyFilters = () => {
    console.log("Applying customer filters:", filters);
    setAppliedFilters(filters);
    setHasChanges(false);
    onFiltersChange?.(filters, true);
  };

  const clearFilters = () => {
    const clearedFilters = {
      userEmail: ""
    };
    setFilters(clearedFilters);
    setAppliedFilters(clearedFilters);
    setHasChanges(false);
    onFiltersChange?.(clearedFilters, true);
  };

  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center gap-2 mb-4">
          <Filter className="h-4 w-4" />
          <span className="font-medium">Customer Filters</span>
          <Button
            variant="ghost"
            size="sm"
            onClick={clearFilters}
            className="ml-auto"
          >
            <X className="h-4 w-4 mr-1" />
            Clear All
          </Button>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <div className="space-y-2">
            <Label htmlFor="userEmail">Customer Email</Label>
            <Input
              id="userEmail"
              placeholder="Enter customer email"
              value={filters.userEmail}
              onChange={(e) => handleFilterChange("userEmail", e.target.value)}
            />
          </div>
        </div>

        {hasChanges && (
          <div className="flex justify-end mt-4">
            <Button onClick={applyFilters} size="sm">
              Apply Filters
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}