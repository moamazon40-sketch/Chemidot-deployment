"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, TrendingUp, Loader2 } from "lucide-react";
import { useTotalUsersCount } from "@/hooks/use-total-users-count";

export function UsersStatsCard() {
  const {
    totalUsersCount,
    totalAdmins,
    totalProjectOwners,
    loading,
    error,
    refetch
  } = useTotalUsersCount();

  if (loading) {
    return (
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Total Users</CardTitle>
          <Users className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-2">
            <Loader2 className="h-4 w-4 animate-spin" />
            <div className="text-2xl font-bold">Loading...</div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Total Users</CardTitle>
          <Users className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-red-500">Error</div>
          <p className="text-xs text-red-500 mt-1">{error}</p>
          <button
            onClick={refetch}
            className="text-xs text-blue-500 hover:underline mt-2"
          >
            Retry
          </button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">Total Users</CardTitle>
        <Users className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{totalUsersCount.toLocaleString()}</div>
        <div className="flex items-center space-x-2 text-xs text-muted-foreground mt-1">
          <span>{totalAdmins} Admins</span>
          <span>•</span>
          <span>{totalProjectOwners} Owners</span>
        </div>
      </CardContent>
    </Card>
  );
}