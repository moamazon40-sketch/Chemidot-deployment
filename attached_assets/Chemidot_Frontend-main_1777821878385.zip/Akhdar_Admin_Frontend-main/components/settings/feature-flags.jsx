"use client";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";

export function FeatureFlags() {
  const [features, setFeatures] = useState({
    bulkOperations: true,
    advancedFiltering: true,
    realTimeNotifications: false,
    apiAccess: true,
    mobileApp: false,
    blockchainIntegration: false,
    aiRecommendations: false,
    multiCurrency: true,
  });
  const toggleFeature = (feature) => {
    setFeatures((prev) => ({
      ...prev,
      [feature]: !prev[feature],
    }));
  };
  const featureList = [
    {
      key: "bulkOperations",
      name: "Bulk Operations",
      description: "Enable bulk actions for projects and transactions",
      category: "Operations",
    },
    {
      key: "advancedFiltering",
      name: "Advanced Filtering",
      description: "Enhanced filtering and search capabilities",
      category: "UI/UX",
    },
    {
      key: "realTimeNotifications",
      name: "Real-time Notifications",
      description: "Live updates and push notifications",
      category: "Notifications",
      beta: true,
    },
    {
      key: "apiAccess",
      name: "API Access",
      description: "RESTful API for third-party integrations",
      category: "Integration",
    },
    {
      key: "mobileApp",
      name: "Mobile Application",
      description: "Native mobile app for iOS and Android",
      category: "Platform",
      beta: true,
    },
    {
      key: "blockchainIntegration",
      name: "Blockchain Integration",
      description: "Blockchain-based credit verification",
      category: "Technology",
      experimental: true,
    },
    {
      key: "aiRecommendations",
      name: "AI Recommendations",
      description: "Machine learning-powered project recommendations",
      category: "AI/ML",
      experimental: true,
    },
    {
      key: "multiCurrency",
      name: "Multi-Currency Support",
      description: "Support for multiple currencies and exchange rates",
      category: "Finance",
    },
  ];
  const categories = Array.from(new Set(featureList.map((f) => f.category)));
  return (
    <div className="space-y-6">
      {categories.map((category) => (
        <Card key={category}>
          <CardHeader>
            <CardTitle>{category} Features</CardTitle>
            <CardDescription>
              Configure {category.toLowerCase()} related features and
              capabilities
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {featureList
                .filter((feature) => feature.category === category)
                .map((feature) => (
                  <div
                    key={feature.key}
                    className="flex items-center justify-between p-4 border rounded-lg"
                  >
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-medium">{feature.name}</h4>
                        {feature.beta && (
                          <Badge variant="secondary">Beta</Badge>
                        )}
                        {feature.experimental && (
                          <Badge variant="outline">Experimental</Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {feature.description}
                      </p>
                    </div>
                    <Switch
                      checked={features[feature.key]}
                      onCheckedChange={() => toggleFeature(feature.key)}
                    />
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
