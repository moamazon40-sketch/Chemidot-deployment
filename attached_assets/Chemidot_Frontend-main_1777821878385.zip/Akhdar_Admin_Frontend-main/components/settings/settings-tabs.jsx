"use client";

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CompanySettings } from "./company-settings";
import { IntegrationSettings } from "./integration-settings";
import { SecuritySettings } from "./security-settings";
import { EmailSettings } from "./email-settings";
import { FeatureFlags } from "./feature-flags";
export function SettingsTabs() {
  return (
    <Tabs defaultValue="company" className="space-y-6">
      <TabsList className="grid w-full grid-cols-5">
        <TabsTrigger value="company">Company</TabsTrigger>
        <TabsTrigger value="integrations">Integrations</TabsTrigger>
        <TabsTrigger value="security">Security</TabsTrigger>
        <TabsTrigger value="email">Email</TabsTrigger>
        <TabsTrigger value="features">Features</TabsTrigger>
      </TabsList>

      <TabsContent value="company">
        <CompanySettings />
      </TabsContent>

      <TabsContent value="integrations">
        <IntegrationSettings />
      </TabsContent>

      <TabsContent value="security">
        <SecuritySettings />
      </TabsContent>

      <TabsContent value="email">
        <EmailSettings />
      </TabsContent>

      <TabsContent value="features">
        <FeatureFlags />
      </TabsContent>
    </Tabs>
  );
}
