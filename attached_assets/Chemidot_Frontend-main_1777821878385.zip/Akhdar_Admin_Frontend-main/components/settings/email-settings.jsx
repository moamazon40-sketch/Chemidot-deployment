"use client";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Edit, Send } from "lucide-react";
const emailTemplates = [
  {
    id: "project_approved_admin",
    name: "Project Approved (Admin)",
    description: "Sent to admins when a project is approved",
    status: "active",
    lastModified: "2024-03-10",
  },
  {
    id: "project_published",
    name: "Project Published (Owner)",
    description: "Sent to project owners when their project goes live",
    status: "active",
    lastModified: "2024-03-08",
  },
  {
    id: "project_rejected",
    name: "Project Rejected",
    description: "Sent when a project is rejected with feedback",
    status: "active",
    lastModified: "2024-03-05",
  },
  {
    id: "user_invite",
    name: "User Invitation",
    description: "Invitation email for new users",
    status: "active",
    lastModified: "2024-03-01",
  },
  {
    id: "transaction_complete",
    name: "Transaction Complete",
    description: "Confirmation email for completed purchases",
    status: "active",
    lastModified: "2024-02-28",
  },
];
export function EmailSettings() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Email Templates</CardTitle>
          <CardDescription>
            Manage automated email templates and notifications
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {emailTemplates.map((template) => (
              <div
                key={template.id}
                className="flex items-center justify-between p-4 border rounded-lg"
              >
                <div>
                  <h4 className="font-medium">{template.name}</h4>
                  <p className="text-sm text-muted-foreground">
                    {template.description}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Last modified: {template.lastModified}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="default">{template.status}</Badge>
                  <Button variant="outline" size="sm">
                    <Edit className="h-4 w-4 mr-2" />
                    Edit
                  </Button>
                  <Button variant="outline" size="sm">
                    <Send className="h-4 w-4 mr-2" />
                    Test
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Webhook Configuration</CardTitle>
          <CardDescription>
            Configure webhooks for external integrations
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="p-4 border rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-medium">Project Status Updates</h4>
                <Badge variant="default">Active</Badge>
              </div>
              <p className="text-sm text-muted-foreground mb-2">
                https://api.example.com/webhooks/project-status
              </p>
              <p className="text-xs text-muted-foreground">
                Triggers: project.approved, project.rejected, project.suspended
              </p>
            </div>
            <div className="p-4 border rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-medium">Transaction Events</h4>
                <Badge variant="secondary">Inactive</Badge>
              </div>
              <p className="text-sm text-muted-foreground mb-2">
                https://api.example.com/webhooks/transactions
              </p>
              <p className="text-xs text-muted-foreground">
                Triggers: transaction.completed, transaction.failed,
                transaction.refunded
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
