"use client";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Save, RefreshCw, Loader2 } from "lucide-react";
import { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { updateUserData } from "@/store/userSlice";
import { AdminGetCurrentUserProfile } from "@/services/auth/authService";

const API_BASE_URL = "https://ha858aeok8.execute-api.eu-north-1.amazonaws.com/DEV";

export function AdminProfileSettings() {
  const userData = useSelector((state) => state.user.userData);
  const dispatch = useDispatch();

  const [profile, setProfile] = useState({
    FirstName: "",
    LastName: "",
    Email: "",
  });

  const [originalProfile, setOriginalProfile] = useState({
    FirstName: "",
    LastName: "",
    Email: "",
  });

  const [hasChanges, setHasChanges] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [message, setMessage] = useState({ text: "", type: "" });
  const [isLoading, setIsLoading] = useState(true);

  // Fetch current user profile on component mount
  useEffect(() => {
    fetchCurrentUserProfile();
  }, []);

  const fetchCurrentUserProfile = async () => {
    try {
      setIsLoading(true);
      console.log("👑 ADMIN SETTINGS - Calling AdminGetCurrentUserProfile API...");

      const response = await AdminGetCurrentUserProfile();
      console.log("👑 ADMIN SETTINGS - API Response:", response);

      // Based on your exact API response structure
      if (response?.data?.success && response?.data?.user) {
        const user = response.data.user;
        console.log("👑 ADMIN SETTINGS - User data:", user);

        // Map exactly as shown in your API response
        const profileData = {
          FirstName: user.firstName || "",        // "Thomas" -> FirstName
          LastName: user.lastName || "",          // "ashraf" -> LastName
          Email: user.Email || "",              // "thomas.ashraf975+7878@gmail.com"
        };

        console.log("✅ ADMIN SETTINGS - Setting profile:", profileData);
        setProfile(profileData);
        setOriginalProfile(profileData);
        console.log("✅ ADMIN SETTINGS - Profile state updated!");

      } else {
        console.error("❌ ADMIN SETTINGS - Invalid API response:", response);
      }
    } catch (error) {
      console.error("❌ ADMIN SETTINGS - API Error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  // Check if there are changes
  useEffect(() => {
    const changes = Object.keys(profile).some(
      key => profile[key] !== originalProfile[key]
    );
    setHasChanges(changes);
  }, [profile, originalProfile]);

  const handleInputChange = (field, value) => {
    setProfile(prev => ({
      ...prev,
      [field]: value
    }));
    // Clear message when user starts typing
    if (message.text) {
      setMessage({ text: "", type: "" });
    }
  };

  const handleSave = async () => {
    if (!hasChanges || isSaving) return;

    setIsSaving(true);
    try {
      const token = userData?.token || userData?.userObj;

      const response = await fetch(`${API_BASE_URL}/AdminUpdateUserProfile`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          'accept': 'application/json'
        },
        body: JSON.stringify({
          FirstName: profile.FirstName,
          LastName: profile.LastName,
          Email: profile.Email,
        })
      });

      const result = await response.json();

      if (result.success) {
        // Update Redux store with new profile data
        const updatedUser = {
          ...userData,
          user: {
            ...userData.user,
            FirstName: profile.FirstName,
            LastName: profile.LastName,
            Email: profile.Email,
          },
          FirstName: profile.FirstName,
          LastName: profile.LastName,
          Email: profile.Email,
        };

        dispatch(updateUserData(updatedUser));

        setOriginalProfile({...profile});
        setHasChanges(false);
        setMessage({ text: "Profile updated successfully!", type: "success" });
      } else {
        setMessage({
          text: result.error || "Failed to update profile. Please try again.",
          type: "error"
        });
      }
    } catch (error) {
      console.error('Error updating profile:', error);
      setMessage({
        text: "An error occurred while updating your profile. Please try again.",
        type: "error"
      });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle>Admin Profile</CardTitle>
              <CardDescription>
                Update your personal information
              </CardDescription>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={fetchCurrentUserProfile}
              disabled={isLoading}
            >
              {isLoading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <RefreshCw className="h-4 w-4" />
              )}
              {isLoading ? " Loading..." : " Refresh"}
            </Button>
          </div>
        </CardHeader>

        <CardContent className="space-y-4">
          {isLoading && (
            <div className="flex items-center justify-center py-4 text-sm text-gray-500">
              <Loader2 className="h-4 w-4 animate-spin mr-2" />
              Loading profile data...
            </div>
          )}
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="first-name">First Name</Label>
              <Input
                id="first-name"
                value={profile.FirstName}
                onChange={(e) => handleInputChange('FirstName', e.target.value)}
                placeholder="Enter your first name"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="last-name">Last Name</Label>
              <Input
                id="last-name"
                value={profile.LastName}
                onChange={(e) => handleInputChange('LastName', e.target.value)}
                placeholder="Enter your last name"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={profile.Email}
              onChange={(e) => handleInputChange('Email', e.target.value)}
              placeholder="Enter your email address"
            />
          </div>

          {message.text && (
            <div className={`p-3 rounded-md text-sm ${
              message.type === "success"
                ? "bg-green-50 text-green-800 border border-green-200"
                : "bg-red-50 text-red-800 border border-red-200"
            }`}>
              {message.text}
            </div>
          )}

          <Button
            onClick={handleSave}
            disabled={!hasChanges || isSaving}
            className={!hasChanges ? "opacity-50 cursor-not-allowed" : ""}
          >
            <Save className="h-4 w-4 mr-2" />
            {isSaving ? "Saving..." : "Save Changes"}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}