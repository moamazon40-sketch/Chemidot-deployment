"use client";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Shield, Download, Trash2 } from "lucide-react";
import { useState } from "react";

export function SecuritySettings() {
  const [securitySettings, setSecuritySettings] = useState({
    twoFactorRequired: true,
    sessionTimeout: 24,
    passwordComplexity: true,
    auditLogging: true,
    gdprCompliance: true,
  });
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Security Policies
          </CardTitle>
          <CardDescription>
            Configure security requirements and access controls
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium">Two-Factor Authentication</h4>
              <p className="text-sm text-muted-foreground">
                Require 2FA for all admin users
              </p>
            </div>
            <Switch
              checked={securitySettings.twoFactorRequired}
              onCheckedChange={(checked) =>
                setSecuritySettings((prev) => ({
                  ...prev,
                  twoFactorRequired: checked,
                }))
              }
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium">Password Complexity</h4>
              <p className="text-sm text-muted-foreground">
                Enforce strong password requirements
              </p>
            </div>
            <Switch
              checked={securitySettings.passwordComplexity}
              onCheckedChange={(checked) =>
                setSecuritySettings((prev) => ({
                  ...prev,
                  passwordComplexity: checked,
                }))
              }
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium">Audit Logging</h4>
              <p className="text-sm text-muted-foreground">
                Log all administrative actions
              </p>
            </div>
            <Switch
              checked={securitySettings.auditLogging}
              onCheckedChange={(checked) =>
                setSecuritySettings((prev) => ({
                  ...prev,
                  auditLogging: checked,
                }))
              }
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>GDPR & Data Protection</CardTitle>
          <CardDescription>
            Manage user data and privacy compliance
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium">GDPR Compliance Mode</h4>
              <p className="text-sm text-muted-foreground">
                Enable EU data protection features
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="default">Enabled</Badge>
              <Switch
                checked={securitySettings.gdprCompliance}
                onCheckedChange={(checked) =>
                  setSecuritySettings((prev) => ({
                    ...prev,
                    gdprCompliance: checked,
                  }))
                }
              />
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <Button variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Export User Data
            </Button>
            <Button variant="outline">
              <Trash2 className="h-4 w-4 mr-2" />
              Delete User Data
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Roles & Permissions</CardTitle>
          <CardDescription>
            Configure user roles and access levels
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="p-4 border rounded-lg">
                <h4 className="font-medium mb-2">Administrator</h4>
                <p className="text-sm text-muted-foreground mb-3">
                  Full system access and configuration
                </p>
                <Badge variant="default">5 users</Badge>
              </div>
              <div className="p-4 border rounded-lg">
                <h4 className="font-medium mb-2">Compliance Officer</h4>
                <p className="text-sm text-muted-foreground mb-3">
                  Project review and compliance management
                </p>
                <Badge variant="secondary">3 users</Badge>
              </div>
              <div className="p-4 border rounded-lg">
                <h4 className="font-medium mb-2">Project Owner</h4>
                <p className="text-sm text-muted-foreground mb-3">
                  Submit and manage own projects
                </p>
                <Badge variant="secondary">12 users</Badge>
              </div>
              <div className="p-4 border rounded-lg">
                <h4 className="font-medium mb-2">Finance</h4>
                <p className="text-sm text-muted-foreground mb-3">
                  Transaction and payment management
                </p>
                <Badge variant="secondary">2 users</Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
