"use client";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Save, Edit, Eye, EyeOff, Key, Mail } from "lucide-react";
import { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { updateUserData } from "@/store/userSlice";
import {
  AdminGetCurrentUserProfile,
  AdminChangePassword,
  AdminRequestEmailChange,
  AdminVerifyOTPAndChangeEmail,
} from "@/services/auth/authService";
import { toast } from "sonner";

const API_BASE_URL = "https://ha858aeok8.execute-api.eu-north-1.amazonaws.com/DEV";

export function UnifiedProfileSettings() {
  const userData = useSelector((state) => state.user.userData);
  const dispatch = useDispatch();

  // Profile form states
  const [profile, setProfile] = useState({
    FirstName: "",
    LastName: "",
    CompanyName: "",
    Email: "",
    PhoneNumber: "",
  });

  const [originalProfile, setOriginalProfile] = useState({});
  const [hasChanges, setHasChanges] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [message, setMessage] = useState({ text: "", type: "" });

  // View states
  const [currentView, setCurrentView] = useState('profile'); // 'profile', 'changePassword', 'changeEmail'

  // Change password states
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isChangingPassword, setIsChangingPassword] = useState(false);

  // Email change states
  const [emailForm, setEmailForm] = useState({
    newEmail: "",
    otp: "",
  });
  const [isEmailChangeStep, setIsEmailChangeStep] = useState(1); // 1: enter email, 2: verify OTP
  const [isProcessingEmail, setIsProcessingEmail] = useState(false);
  const [otpTimer, setOtpTimer] = useState(0);

  // Pre-fill from Redux userData on component mount
  useEffect(() => {
    if (userData) {
      console.log("🚀 UNIFIED SETTINGS - Reading from Redux userData:", userData);
      console.log("🚀 ALL USERDATA KEYS:", Object.keys(userData));
      console.log("🚀 userData.firstName:", userData.firstName);
      console.log("🚀 userData.FirstName:", userData.FirstName);
      console.log("🚀 userData.lastName:", userData.lastName);
      console.log("🚀 userData.LastName:", userData.LastName);

      // Pre-fill from Redux first
      const profileData = {
        FirstName: userData.FirstName || userData.firstName || "",
        LastName: userData.LastName || userData.lastName || "",
        CompanyName: userData.CompanyName || userData.companyName || "",
        Email: userData.Email || "",
        PhoneNumber: userData.PhoneNumber || "",
      };

      console.log("🚀 SETTING PROFILE FROM REDUX:", profileData);
      setProfile(profileData);
      setOriginalProfile(profileData);
      setIsLoading(false);

      // Only fetch from API if essential data is missing
      if (!userData.Email || (!userData.FirstName && !userData.firstName)) {
        console.log("🚀 Essential data missing, fetching from API...");
        fetchCurrentUserProfile();
      }
    } else {
      // No userData, fetch from API
      console.log("🚀 No userData available, fetching from API...");
      fetchCurrentUserProfile();
    }
  }, [userData]);

  // Start OTP timer countdown
  useEffect(() => {
    let interval;
    if (otpTimer > 0) {
      interval = setInterval(() => {
        setOtpTimer((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [otpTimer]);

  const fetchCurrentUserProfile = async () => {
    try {
      setIsLoading(true);
      console.log("🚀 Starting API fetch for user profile...");

      const response = await AdminGetCurrentUserProfile();
      console.log("AdminGetCurrentUserProfile response:", response);
      console.log("Response data:", response.data);

      // Handle different possible response structures
      let user = null;
      if (response?.data?.success && response.data.user) {
        user = response.data.user;
      } else if (response?.data && !response.data.success) {
        // Direct user data in response.data
        user = response.data;
      }

      console.log("Extracted user data:", user);

      if (user) {
        const profileData = {
          FirstName: user.FirstName || "",
          LastName: user.LastName || "",
          CompanyName: user.CompanyName || "",
          Email: user.Email || "",
          PhoneNumber: user.PhoneNumber || "",
        };

        console.log("Setting profile data from API:", profileData);
        setProfile(profileData);
        setOriginalProfile(profileData);

        // Update Redux store with fresh data
        dispatch(updateUserData({
          ...userData,
          ...user,
        }));
      } else {
        console.log("No user data found in API response");
        // Don't show error if we already have userData from Redux
        if (!userData) {
          setMessage({
            text: "Failed to load user profile. Please refresh the page.",
            type: "error"
          });
        }
      }
    } catch (error) {
      console.error("Error fetching user profile:", error);
      // Don't show error if we already have userData from Redux
      if (!userData) {
        setMessage({
          text: "Failed to load user profile. Please refresh the page.",
          type: "error"
        });
      }
    } finally {
      console.log("🚀 API fetch completed, setting loading to false");
      setIsLoading(false);
    }
  };

  // Check if there are changes in profile
  useEffect(() => {
    const changes = Object.keys(profile).some(
      key => profile[key] !== originalProfile[key]
    );
    setHasChanges(changes);
  }, [profile, originalProfile]);

  const handleProfileChange = (field, value) => {
    setProfile(prev => ({
      ...prev,
      [field]: value
    }));
    // Clear message when user starts typing
    if (message.text) {
      setMessage({ text: "", type: "" });
    }
  };

  const handleSaveProfile = async () => {
    if (!hasChanges || isSaving) return;

    setIsSaving(true);
    try {
      const response = await fetch(`${API_BASE_URL}/AdminUpdateUserProfile`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${userData?.token}`,
          'accept': 'application/json'
        },
        body: JSON.stringify({
          FirstName: profile.FirstName,
          LastName: profile.LastName,
          Email: profile.Email,
          PhoneNumber: profile.PhoneNumber,
          CompanyName: profile.CompanyName,
        })
      });

      const result = await response.json();

      if (result.success) {
        // Update Redux store
        dispatch(updateUserData({
          ...userData,
          ...result.user,
        }));

        setOriginalProfile({...profile});
        setHasChanges(false);
        setMessage({ text: "Profile updated successfully!", type: "success" });
      } else {
        setMessage({
          text: result.error || "Failed to update profile. Please try again.",
          type: "error"
        });
      }
    } catch (error) {
      console.error('Error updating profile:', error);
      setMessage({
        text: "An error occurred while updating your profile. Please try again.",
        type: "error"
      });
    } finally {
      setIsSaving(false);
    }
  };

  const validatePassword = (password) => {
    const minLength = 8;
    const hasUpperCase = /[A-Z]/.test(password);
    const hasLowerCase = /[a-z]/.test(password);
    const hasNumbers = /\d/.test(password);
    const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);

    if (password.length < minLength) {
      return "Password must be at least 8 characters long";
    }
    if (!hasUpperCase) {
      return "Password must contain at least one uppercase letter";
    }
    if (!hasLowerCase) {
      return "Password must contain at least one lowercase letter";
    }
    if (!hasNumbers) {
      return "Password must contain at least one number";
    }
    if (!hasSpecialChar) {
      return "Password must contain at least one special character";
    }
    return null;
  };

  const handleChangePassword = async () => {
    if (!passwordForm.currentPassword || !passwordForm.newPassword || !passwordForm.confirmPassword) {
      setMessage({ text: "Please fill in all password fields.", type: "error" });
      return;
    }

    const passwordValidation = validatePassword(passwordForm.newPassword);
    if (passwordValidation) {
      setMessage({ text: passwordValidation, type: "error" });
      return;
    }

    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      setMessage({ text: "New passwords do not match.", type: "error" });
      return;
    }

    if (passwordForm.currentPassword === passwordForm.newPassword) {
      setMessage({ text: "New password must be different from current password.", type: "error" });
      return;
    }

    setIsChangingPassword(true);
    try {
      console.log("Attempting to change password...");
      const response = await AdminChangePassword({
        currentPassword: passwordForm.currentPassword,
        newPassword: passwordForm.newPassword,
      });

      console.log("Password change response:", response);
      console.log("Response data:", response.data);

      if (response.data.success || response.data.Success) {
        console.log("Password change successful!");
        setPasswordForm({ currentPassword: "", newPassword: "", confirmPassword: "" });
        setCurrentView('profile');
        setMessage({ text: "Password changed successfully!", type: "success" });
        toast.success("Password changed successfully!");
      } else {
        console.log("Password change failed - response.data.success/Success is false");
        setMessage({
          text: "Failed to change password. Please try again.",
          type: "error"
        });
      }
    } catch (error) {
      console.error("Password change error:", error);
      console.error("Error response:", error.response);
      setMessage({
        text: error.message || "Failed to change password. Please try again.",
        type: "error"
      });
    } finally {
      setIsChangingPassword(false);
    }
  };

  const handleRequestEmailChange = async () => {
    if (!emailForm.newEmail) {
      setMessage({ text: "Please enter a new email address.", type: "error" });
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(emailForm.newEmail)) {
      setMessage({ text: "Please enter a valid email address.", type: "error" });
      return;
    }

    if (emailForm.newEmail === profile.Email) {
      setMessage({ text: "New email must be different from current email.", type: "error" });
      return;
    }

    setIsProcessingEmail(true);
    try {
      const response = await AdminRequestEmailChange(emailForm.newEmail);

      if (response.data.Success || response.data.success) {
        setIsEmailChangeStep(2);
        setOtpTimer(30); // 30 second cooldown for resend
        setMessage({
          text: `OTP sent to ${profile.Email}. Please check your current email.`,
          type: "success"
        });
      }
    } catch (error) {
      setMessage({
        text: error.message || "Failed to send OTP. Please try again.",
        type: "error"
      });
    } finally {
      setIsProcessingEmail(false);
    }
  };

  const handleVerifyOTP = async () => {
    if (!emailForm.otp) {
      setMessage({ text: "Please enter the OTP.", type: "error" });
      return;
    }

    if (emailForm.otp.length !== 6) {
      setMessage({ text: "OTP must be 6 digits.", type: "error" });
      return;
    }

    setIsProcessingEmail(true);
    try {
      const response = await AdminVerifyOTPAndChangeEmail(emailForm.otp);

      if (response.data.success) {
        // Update profile with new email
        const newProfile = { ...profile, Email: response.data.user.Email };
        setProfile(newProfile);
        setOriginalProfile(newProfile);

        // Update Redux store
        dispatch(updateUserData({
          ...userData,
          ...response.data.user,
        }));

        // Reset email change form
        setEmailForm({ newEmail: "", otp: "" });
        setCurrentView('profile');
        setIsEmailChangeStep(1);
        setMessage({ text: "Email changed successfully!", type: "success" });
      }
    } catch (error) {
      setMessage({
        text: error.message || "Invalid or expired OTP. Please try again.",
        type: "error"
      });
    } finally {
      setIsProcessingEmail(false);
    }
  };

  const handleResendOTP = async () => {
    if (otpTimer > 0) return;

    setIsProcessingEmail(true);
    try {
      const response = await AdminRequestEmailChange(emailForm.newEmail);

      if (response.data.Success || response.data.success) {
        setOtpTimer(30);
        setMessage({ text: "OTP resent successfully!", type: "success" });
      }
    } catch (error) {
      setMessage({
        text: error.message || "Failed to resend OTP. Please try again.",
        type: "error"
      });
    } finally {
      setIsProcessingEmail(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-32">
        <span>Loading profile...</span>
      </div>
    );
  }

  // Render based on current view
  if (currentView === 'changePassword') {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Change Password</CardTitle>
          <CardDescription>
            Enter your current password and choose a new one
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="current-password">Current Password</Label>
            <div className="relative">
              <Input
                id="current-password"
                type={showCurrentPassword ? "text" : "password"}
                value={passwordForm.currentPassword}
                onChange={(e) => setPasswordForm(prev => ({...prev, currentPassword: e.target.value}))}
                placeholder="Enter current password"
              />
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                onClick={() => setShowCurrentPassword(!showCurrentPassword)}
              >
                {showCurrentPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="new-password">New Password</Label>
            <div className="relative">
              <Input
                id="new-password"
                type={showNewPassword ? "text" : "password"}
                value={passwordForm.newPassword}
                onChange={(e) => setPasswordForm(prev => ({...prev, newPassword: e.target.value}))}
                placeholder="Enter new password"
              />
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                onClick={() => setShowNewPassword(!showNewPassword)}
              >
                {showNewPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="confirm-new-password">Confirm New Password</Label>
            <div className="relative">
              <Input
                id="confirm-new-password"
                type={showConfirmPassword ? "text" : "password"}
                value={passwordForm.confirmPassword}
                onChange={(e) => setPasswordForm(prev => ({...prev, confirmPassword: e.target.value}))}
                placeholder="Confirm new password"
              />
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
              >
                {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </Button>
            </div>
          </div>

          <div className="text-xs text-gray-500 space-y-1">
            <p>Password must contain:</p>
            <ul className="list-disc list-inside space-y-1">
              <li>At least 8 characters</li>
              <li>One uppercase letter (A-Z)</li>
              <li>One lowercase letter (a-z)</li>
              <li>One number (0-9)</li>
              <li>One special character (!@#$%^&*)</li>
            </ul>
          </div>

          {message.text && (
            <div className={`p-3 rounded-md text-sm ${
              message.type === "success"
                ? "bg-green-50 text-green-800 border border-green-200"
                : "bg-red-50 text-red-800 border border-red-200"
            }`}>
              {message.text}
            </div>
          )}

          <div className="flex gap-4">
            <Button
              onClick={handleChangePassword}
              disabled={isChangingPassword}
            >
              {isChangingPassword ? "Changing..." : "Change Password"}
            </Button>

            <Button
              variant="outline"
              onClick={() => {
                setCurrentView('profile');
                setPasswordForm({ currentPassword: "", newPassword: "", confirmPassword: "" });
                setMessage({ text: "", type: "" });
              }}
            >
              Back
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (currentView === 'changeEmail') {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Change Email Address</CardTitle>
          <CardDescription>
            {isEmailChangeStep === 1
              ? "Enter your new email address to receive an OTP"
              : "Enter the OTP sent to your current email"
            }
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-4">
          {isEmailChangeStep === 1 ? (
            <>
              <div className="space-y-2">
                <Label htmlFor="new-email">New Email Address</Label>
                <Input
                  id="new-email"
                  type="email"
                  value={emailForm.newEmail}
                  onChange={(e) => setEmailForm(prev => ({...prev, newEmail: e.target.value}))}
                  placeholder="Enter new email address"
                />
              </div>

              {message.text && (
                <div className={`p-3 rounded-md text-sm ${
                  message.type === "success"
                    ? "bg-green-50 text-green-800 border border-green-200"
                    : "bg-red-50 text-red-800 border border-red-200"
                }`}>
                  {message.text}
                </div>
              )}

              <div className="flex gap-4">
                <Button
                  onClick={handleRequestEmailChange}
                  disabled={isProcessingEmail}
                >
                  <Mail className="h-4 w-4 mr-2" />
                  {isProcessingEmail ? "Sending..." : "Send OTP"}
                </Button>

                <Button
                  variant="outline"
                  onClick={() => {
                    setCurrentView('profile');
                    setEmailForm({ newEmail: "", otp: "" });
                    setIsEmailChangeStep(1);
                    setMessage({ text: "", type: "" });
                  }}
                >
                  Back
                </Button>
              </div>
            </>
          ) : (
            <>
              <div className="space-y-2">
                <Label htmlFor="otp">Verification Code</Label>
                <Input
                  id="otp"
                  type="text"
                  maxLength="6"
                  value={emailForm.otp}
                  onChange={(e) => setEmailForm(prev => ({...prev, otp: e.target.value.replace(/\D/g, '')}))}
                  placeholder="Enter 6-digit OTP"
                />
                <p className="text-sm text-gray-500">
                  OTP sent to {profile.Email}
                </p>
              </div>

              {message.text && (
                <div className={`p-3 rounded-md text-sm ${
                  message.type === "success"
                    ? "bg-green-50 text-green-800 border border-green-200"
                    : "bg-red-50 text-red-800 border border-red-200"
                }`}>
                  {message.text}
                </div>
              )}

              <div className="flex gap-4">
                <Button
                  onClick={handleVerifyOTP}
                  disabled={isProcessingEmail}
                >
                  {isProcessingEmail ? "Verifying..." : "Verify OTP"}
                </Button>

                <Button
                  variant="outline"
                  onClick={handleResendOTP}
                  disabled={otpTimer > 0 || isProcessingEmail}
                >
                  {otpTimer > 0 ? `Resend in ${otpTimer}s` : "Resend OTP"}
                </Button>

                <Button
                  variant="outline"
                  onClick={() => {
                    setIsEmailChangeStep(1);
                    setEmailForm(prev => ({...prev, otp: ""}));
                    setMessage({ text: "", type: "" });
                  }}
                >
                  Back to Email
                </Button>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    );
  }

  // Default profile view
  return (
    <Card>
      <CardHeader>
        <CardTitle>Profile Settings</CardTitle>
        <CardDescription>
          Manage your personal information and account settings
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Debug info */}
        {console.log("Current profile state:", profile)}
        {console.log("UserType:", userData?.UserType)}

        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="first-name">First Name</Label>
            <Input
              id="first-name"
              value={profile.FirstName}
              onChange={(e) => handleProfileChange('FirstName', e.target.value)}
              placeholder="Enter your first name"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="last-name">Last Name</Label>
            <Input
              id="last-name"
              value={profile.LastName}
              onChange={(e) => handleProfileChange('LastName', e.target.value)}
              placeholder="Enter your last name"
            />
          </div>
        </div>

        {userData?.UserType === "ProjectOwner" && (
          <div className="space-y-2">
            <Label htmlFor="company-name">Company Name</Label>
            <Input
              id="company-name"
              value={profile.CompanyName}
              onChange={(e) => handleProfileChange('CompanyName', e.target.value)}
              placeholder="Enter your company name"
            />
          </div>
        )}

        <div className="space-y-2">
          <Label htmlFor="email">Email</Label>
          <div className="relative">
            <Input
              id="email"
              type="email"
              value={profile.Email}
              readOnly
              className="pr-10 bg-gray-50"
            />
            <Button
              type="button"
              variant="ghost"
              size="sm"
              className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
              onClick={() => setCurrentView('changeEmail')}
            >
              <Edit className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="phone">Phone Number</Label>
          <Input
            id="phone"
            value={profile.PhoneNumber}
            onChange={(e) => handleProfileChange('PhoneNumber', e.target.value)}
            placeholder="Enter your phone number"
          />
        </div>

        {message.text && (
          <div className={`p-3 rounded-md text-sm ${
            message.type === "success"
              ? "bg-green-50 text-green-800 border border-green-200"
              : "bg-red-50 text-red-800 border border-red-200"
          }`}>
            {message.text}
          </div>
        )}

        <div className="flex gap-4">
          <Button
            onClick={handleSaveProfile}
            disabled={!hasChanges || isSaving}
            className={!hasChanges ? "opacity-50 cursor-not-allowed" : ""}
          >
            <Save className="h-4 w-4 mr-2" />
            {isSaving ? "Saving..." : "Save Changes"}
          </Button>

          <Button
            variant="outline"
            onClick={() => setCurrentView('changePassword')}
          >
            <Key className="h-4 w-4 mr-2" />
            Change Password
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}