"use client";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Eye, EyeOff, TestTube, Save } from "lucide-react";
import { useState } from "react";

export function IntegrationSettings() {
  const [showSecrets, setShowSecrets] = useState({
    stripe: false,
    s3: false,
    sendgrid: false,
  });
  const [integrations, setIntegrations] = useState({
    stripe: {
      enabled: true,
      publishableKey: "pk_test_...",
      secretKey: "sk_test_...",
      webhookSecret: "whsec_...",
    },
    s3: {
      enabled: true,
      accessKey: "AKIA...",
      secretKey: "...",
      bucket: "carbon-marketplace-docs",
      region: "us-east-1",
    },
    sendgrid: {
      enabled: true,
      apiKey: "SG...",
      fromEmail: "noreply@carbonmarketplace.com",
      fromName: "Carbon Marketplace",
    },
  });
  const toggleSecret = (integration) => {
    setShowSecrets((prev) => ({
      ...prev,
      [integration]: !prev[integration],
    }));
  };
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                Stripe Payment Processing
                <Badge
                  variant={
                    integrations.stripe.enabled ? "default" : "secondary"
                  }
                >
                  {integrations.stripe.enabled ? "Connected" : "Disabled"}
                </Badge>
              </CardTitle>
              <CardDescription>
                Configure Stripe for payment processing and subscriptions
              </CardDescription>
            </div>
            <Switch
              checked={integrations.stripe.enabled}
              onCheckedChange={(checked) =>
                setIntegrations((prev) => ({
                  ...prev,
                  stripe: {
                    ...prev.stripe,
                    enabled: checked,
                  },
                }))
              }
            />
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Publishable Key</Label>
            <Input value={integrations.stripe.publishableKey} readOnly />
          </div>

          <div className="space-y-2">
            <Label>Secret Key</Label>
            <div className="flex gap-2">
              <Input
                type={showSecrets.stripe ? "text" : "password"}
                value={integrations.stripe.secretKey}
                readOnly
              />
              <Button
                variant="outline"
                size="icon"
                onClick={() => toggleSecret("stripe")}
              >
                {showSecrets.stripe ? (
                  <EyeOff className="h-4 w-4" />
                ) : (
                  <Eye className="h-4 w-4" />
                )}
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Webhook Secret</Label>
            <div className="flex gap-2">
              <Input
                type={showSecrets.stripe ? "text" : "password"}
                value={integrations.stripe.webhookSecret}
                readOnly
              />
              <Button variant="outline" size="sm">
                <TestTube className="h-4 w-4 mr-2" />
                Test Connection
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                AWS S3 Storage
                <Badge
                  variant={integrations.s3.enabled ? "default" : "secondary"}
                >
                  {integrations.s3.enabled ? "Connected" : "Disabled"}
                </Badge>
              </CardTitle>
              <CardDescription>
                File storage for project documents and assets
              </CardDescription>
            </div>
            <Switch
              checked={integrations.s3.enabled}
              onCheckedChange={(checked) =>
                setIntegrations((prev) => ({
                  ...prev,
                  s3: {
                    ...prev.s3,
                    enabled: checked,
                  },
                }))
              }
            />
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label>Access Key ID</Label>
              <Input value={integrations.s3.accessKey} readOnly />
            </div>
            <div className="space-y-2">
              <Label>Secret Access Key</Label>
              <div className="flex gap-2">
                <Input
                  type={showSecrets.s3 ? "text" : "password"}
                  value={integrations.s3.secretKey}
                  readOnly
                />
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => toggleSecret("s3")}
                >
                  {showSecrets.s3 ? (
                    <EyeOff className="h-4 w-4" />
                  ) : (
                    <Eye className="h-4 w-4" />
                  )}
                </Button>
              </div>
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label>Bucket Name</Label>
              <Input value={integrations.s3.bucket} readOnly />
            </div>
            <div className="space-y-2">
              <Label>Region</Label>
              <Input value={integrations.s3.region} readOnly />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                SendGrid Email Service
                <Badge
                  variant={
                    integrations.sendgrid.enabled ? "default" : "secondary"
                  }
                >
                  {integrations.sendgrid.enabled ? "Connected" : "Disabled"}
                </Badge>
              </CardTitle>
              <CardDescription>
                Email delivery for notifications and communications
              </CardDescription>
            </div>
            <Switch
              checked={integrations.sendgrid.enabled}
              onCheckedChange={(checked) =>
                setIntegrations((prev) => ({
                  ...prev,
                  sendgrid: {
                    ...prev.sendgrid,
                    enabled: checked,
                  },
                }))
              }
            />
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>API Key</Label>
            <div className="flex gap-2">
              <Input
                type={showSecrets.sendgrid ? "text" : "password"}
                value={integrations.sendgrid.apiKey}
                readOnly
              />
              <Button
                variant="outline"
                size="icon"
                onClick={() => toggleSecret("sendgrid")}
              >
                {showSecrets.sendgrid ? (
                  <EyeOff className="h-4 w-4" />
                ) : (
                  <Eye className="h-4 w-4" />
                )}
              </Button>
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label>From Email</Label>
              <Input value={integrations.sendgrid.fromEmail} readOnly />
            </div>
            <div className="space-y-2">
              <Label>From Name</Label>
              <Input value={integrations.sendgrid.fromName} readOnly />
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button>
          <Save className="h-4 w-4 mr-2" />
          Save All Settings
        </Button>
      </div>
    </div>
  );
}
