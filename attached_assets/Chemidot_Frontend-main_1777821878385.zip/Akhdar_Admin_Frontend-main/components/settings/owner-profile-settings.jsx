"use client";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Save, Edit, Eye, EyeOff, Key, Mail } from "lucide-react";
import { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { updateUserData } from "@/store/userSlice";
import {
  AdminGetCurrentUserProfile,
  AdminChangePassword,
  AdminRequestEmailChange,
  AdminVerifyOTPAndChangeEmail,
} from "@/services/auth/authService";
import { toast } from "sonner";

const API_BASE_URL = "https://ha858aeok8.execute-api.eu-north-1.amazonaws.com/DEV";

export function OwnerProfileSettings() {
  const userData = useSelector((state) => state.user.userData);
  const dispatch = useDispatch();

  // Profile form states
  const [profile, setProfile] = useState({
    FirstName: "",
    LastName: "",
    CompanyName: "",
    Email: "",
    PhoneNumber: "",
  });

  const [originalProfile, setOriginalProfile] = useState({});
  const [hasChanges, setHasChanges] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [message, setMessage] = useState({ text: "", type: "" });

  // View states
  const [currentView, setCurrentView] = useState('profile'); // 'profile', 'changePassword', 'changeEmail'

  // Change password states
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isChangingPassword, setIsChangingPassword] = useState(false);

  // Email change states
  const [emailForm, setEmailForm] = useState({
    newEmail: "",
    otp: "",
  });
  const [isEmailChangeStep, setIsEmailChangeStep] = useState(1); // 1: enter email, 2: verify OTP
  const [isProcessingEmail, setIsProcessingEmail] = useState(false);
  const [otpTimer, setOtpTimer] = useState(0);

  // Pre-fill from Redux userData on component mount
  useEffect(() => {
    if (userData) {
      console.log("🚀 OWNER SETTINGS - Reading from Redux userData:", userData);
      console.log("🚀 ALL USERDATA KEYS:", Object.keys(userData));

      // Pre-fill from Redux first
      const profileData = {
        FirstName: userData.FirstName || userData.firstName || "",
        LastName: userData.LastName || userData.lastName || "",
        CompanyName: userData.CompanyName || userData.companyName || "",
        Email: userData.Email || "",
        PhoneNumber: userData.PhoneNumber || "",
      };

      console.log("🚀 SETTING PROFILE FROM REDUX:", profileData);
      setProfile(profileData);
      setOriginalProfile(profileData);
      setIsLoading(false);
    }

    // Also fetch from API as backup
    fetchCurrentUserProfile();
  }, [userData]);

  // Start OTP timer countdown
  useEffect(() => {
    let interval;
    if (otpTimer > 0) {
      interval = setInterval(() => {
        setOtpTimer((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [otpTimer]);

  const fetchCurrentUserProfile = async () => {
    try {
      setIsLoading(true);
      const response = await AdminGetCurrentUserProfile();
      console.log("AdminGetCurrentUserProfile response:", response);

      // Handle different possible response structures
      let user = null;
      if (response.data.success && response.data.user) {
        user = response.data.user;
      } else if (response.data && !response.data.success) {
        user = response.data;
      }

      if (user) {
        const profileData = {
          FirstName: user.FirstName || "",
          LastName: user.LastName || "",
          CompanyName: user.CompanyName || "",
          Email: user.Email || "",
          PhoneNumber: user.PhoneNumber || "",
        };

        setProfile(profileData);
        setOriginalProfile(profileData);

        // Update Redux store with fresh data
        dispatch(updateUserData({
          ...userData,
          ...user,
        }));
      }
    } catch (error) {
      console.error("Error fetching user profile:", error);
      setMessage({
        text: "Failed to load user profile. Please refresh the page.",
        type: "error"
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Check if there are changes in profile
  useEffect(() => {
    const changes = Object.keys(profile).some(
      key => profile[key] !== originalProfile[key]
    );
    setHasChanges(changes);
  }, [profile, originalProfile]);

  const handleProfileChange = (field, value) => {
    setProfile(prev => ({
      ...prev,
      [field]: value
    }));
    // Clear message when user starts typing
    if (message.text) {
      setMessage({ text: "", type: "" });
    }
  };

  const handleSaveProfile = async () => {
    if (!hasChanges || isSaving) return;

    setIsSaving(true);
    try {
      const response = await fetch(`${API_BASE_URL}/AdminUpdateUserProfile`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${userData?.token}`,
          'accept': 'application/json'
        },
        body: JSON.stringify({
          FirstName: profile.FirstName,
          LastName: profile.LastName,
          Email: profile.Email,
          PhoneNumber: profile.PhoneNumber,
          CompanyName: profile.CompanyName,
        })
      });

      const result = await response.json();

      if (result.success) {
        // Update Redux store
        dispatch(updateUserData({
          ...userData,
          ...result.user,
        }));

        setOriginalProfile({...profile});
        setHasChanges(false);
        setMessage({ text: "Profile updated successfully!", type: "success" });
      } else {
        setMessage({
          text: result.error || "Failed to update profile. Please try again.",
          type: "error"
        });
      }
    } catch (error) {
      console.error('Error updating profile:', error);
      setMessage({
        text: "An error occurred while updating your profile. Please try again.",
        type: "error"
      });
    } finally {
      setIsSaving(false);
    }
  };

  const validatePassword = (password) => {
    const minLength = 8;
    const hasUpperCase = /[A-Z]/.test(password);
    const hasLowerCase = /[a-z]/.test(password);
    const hasNumbers = /\d/.test(password);
    const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);

    if (password.length < minLength) {
      return "Password must be at least 8 characters long";
    }
    if (!hasUpperCase) {
      return "Password must contain at least one uppercase letter";
    }
    if (!hasLowerCase) {
      return "Password must contain at least one lowercase letter";
    }
    if (!hasNumbers) {
      return "Password must contain at least one number";
    }
    if (!hasSpecialChar) {
      return "Password must contain at least one special character";
    }
    return null;
  };

  const handleChangePassword = async () => {
    if (!passwordForm.currentPassword || !passwordForm.newPassword || !passwordForm.confirmPassword) {
      setMessage({ text: "Please fill in all password fields.", type: "error" });
      return;
    }

    const passwordValidation = validatePassword(passwordForm.newPassword);
    if (passwordValidation) {
      setMessage({ text: passwordValidation, type: "error" });
      return;
    }

    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      setMessage({ text: "New passwords do not match.", type: "error" });
      return;
    }

    if (passwordForm.currentPassword === passwordForm.newPassword) {
      setMessage({ text: "New password must be different from current password.", type: "error" });
      return;
    }

    setIsChangingPassword(true);
    try {
      const response = await AdminChangePassword({
        currentPassword: passwordForm.currentPassword,
        newPassword: passwordForm.newPassword,
      });

      if (response.data.success || response.data.Success) {
        setPasswordForm({ currentPassword: "", newPassword: "", confirmPassword: "" });
        setCurrentView('profile');
        setMessage({ text: "Password changed successfully!", type: "success" });
        toast.success("Password changed successfully!");
      } else {
        setMessage({
          text: "Failed to change password. Please try again.",
          type: "error"
        });
      }
    } catch (error) {
      console.error("Password change error:", error);
      setMessage({
        text: error.message || "Failed to change password. Please try again.",
        type: "error"
      });
    } finally {
      setIsChangingPassword(false);
    }
  };

  const handleRequestEmailChange = async () => {
    if (!emailForm.newEmail) {
      setMessage({ text: "Please enter a new email address.", type: "error" });
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(emailForm.newEmail)) {
      setMessage({ text: "Please enter a valid email address.", type: "error" });
      return;
    }

    if (emailForm.newEmail === profile.Email) {
      setMessage({ text: "New email must be different from current email.", type: "error" });
      return;
    }

    setIsProcessingEmail(true);
    try {
      const response = await AdminRequestEmailChange(emailForm.newEmail);

      if (response.data.Success || response.data.success) {
        setIsEmailChangeStep(2);
        setOtpTimer(30);
        setMessage({
          text: `OTP sent to ${profile.Email}. Please check your current email.`,
          type: "success"
        });
      }
    } catch (error) {
      setMessage({
        text: error.message || "Failed to send OTP. Please try again.",
        type: "error"
      });
    } finally {
      setIsProcessingEmail(false);
    }
  };

  const handleVerifyOTP = async () => {
    if (!emailForm.otp) {
      setMessage({ text: "Please enter the OTP.", type: "error" });
      return;
    }

    if (emailForm.otp.length !== 6) {
      setMessage({ text: "OTP must be 6 digits.", type: "error" });
      return;
    }

    setIsProcessingEmail(true);
    try {
      const response = await AdminVerifyOTPAndChangeEmail(emailForm.otp);

      if (response.data.success) {
        const newProfile = { ...profile, Email: response.data.user.Email };
        setProfile(newProfile);
        setOriginalProfile(newProfile);

        dispatch(updateUserData({
          ...userData,
          ...response.data.user,
        }));

        setEmailForm({ newEmail: "", otp: "" });
        setCurrentView('profile');
        setIsEmailChangeStep(1);
        setMessage({ text: "Email changed successfully!", type: "success" });
      }
    } catch (error) {
      setMessage({
        text: error.message || "Invalid or expired OTP. Please try again.",
        type: "error"
      });
    } finally {
      setIsProcessingEmail(false);
    }
  };

  const handleResendOTP = async () => {
    if (otpTimer > 0) return;

    setIsProcessingEmail(true);
    try {
      const response = await AdminRequestEmailChange(emailForm.newEmail);

      if (response.data.Success || response.data.success) {
        setOtpTimer(30);
        setMessage({ text: "OTP resent successfully!", type: "success" });
      }
    } catch (error) {
      setMessage({
        text: error.message || "Failed to resend OTP. Please try again.",
        type: "error"
      });
    } finally {
      setIsProcessingEmail(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle>Owner Profile</CardTitle>
              <CardDescription>
                Update your personal and company information
              </CardDescription>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={fetchCurrentUserProfile}
              disabled={isLoading}
            >
              {isLoading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <RefreshCw className="h-4 w-4" />
              )}
              {isLoading ? " Loading..." : " Refresh"}
            </Button>
          </div>
        </CardHeader>

        <CardContent className="space-y-4">
          {isLoading && (
            <div className="flex items-center justify-center py-4 text-sm text-gray-500">
              <Loader2 className="h-4 w-4 animate-spin mr-2" />
              Loading profile data...
            </div>
          )}
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="first-name">First Name</Label>
              <Input
                id="first-name"
                value={profile.firstName}
                onChange={(e) => handleInputChange('firstName', e.target.value)}
                placeholder="Enter your first name"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="last-name">Last Name</Label>
              <Input
                id="last-name"
                value={profile.lastName}
                onChange={(e) => handleInputChange('lastName', e.target.value)}
                placeholder="Enter your last name"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="company-name">Company Name</Label>
            <Input
              id="company-name"
              value={profile.companyName}
              onChange={(e) => handleInputChange('companyName', e.target.value)}
              placeholder="Enter your company name"
            />
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={profile.Email}
                onChange={(e) => handleInputChange('Email', e.target.value)}
                placeholder="Enter your email address"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <Input
                id="phone"
                value={profile.PhoneNumber}
                onChange={(e) => handleInputChange('PhoneNumber', e.target.value)}
                placeholder="Enter your phone number"
              />
            </div>
          </div>

          {message.text && (
            <div className={`p-3 rounded-md text-sm ${
              message.type === "success"
                ? "bg-green-50 text-green-800 border border-green-200"
                : "bg-red-50 text-red-800 border border-red-200"
            }`}>
              {message.text}
            </div>
          )}

          <Button
            onClick={handleSave}
            disabled={!hasChanges || isSaving}
            className={!hasChanges ? "opacity-50 cursor-not-allowed" : ""}
          >
            <Save className="h-4 w-4 mr-2" />
            {isSaving ? "Saving..." : "Save Changes"}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}