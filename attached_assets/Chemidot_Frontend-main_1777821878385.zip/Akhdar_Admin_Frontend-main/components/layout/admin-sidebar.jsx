"use client";

import {
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarGroupContent,
} from "@/components/ui/sidebar";
import {
  FolderTree,
  Users,
  CreditCard,
  UserCheck,
  Settings,
  Leaf,
  Database,
  FileSpreadsheet,
} from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useSidebar } from "@/components/ui/sidebar";
const menuItems = [
  {
    title: "Management",
    items: [
      {
        title: "Projects",
        icon: FolderTree,
        href: "/admin/projects",
      },
      {
        title: "Users & Owners",
        icon: Users,
        href: "/admin/users",
      },
      {
        title: "Transactions",
        icon: CreditCard,
        href: "/admin/transactions",
      },
      {
        title: "Customers",
        icon: UserCheck,
        href: "/admin/customers",
      },
    ],
  },
  {
    title: "Data Analytics",
    items: [
      {
        title: "contactUs form data",
        icon: Database,
        href: "/admin/contactUs-form-data",
      },
      {
        title: "ESG Form data",
        icon: FileSpreadsheet,
        href: "/admin/ESG-Form-data",
      },
    ],
  },
  {
    title: "Operations",
    items: [
      {
        title: "Settings",
        icon: Settings,
        href: "/admin/settings",
      },
    ],
  },
];
export function AdminSidebar() {
  const pathname = usePathname();
  const { state } = useSidebar();

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader className="p-4">
        <div className="flex items-center gap-2">
          <Leaf className="h-10 w-10 text-primary" />
          {state === "expanded" && (
            <span className="font-bold text-lg">Akhdar dashboard</span>
          )}
        </div>
      </SidebarHeader>

      <SidebarContent>
        {menuItems
          .filter((group) => group.items && group.items.length > 0)
          .map((group) => (
            <SidebarGroup key={group.title}>
              <SidebarGroupLabel>{group.title}</SidebarGroupLabel>

              <SidebarGroupContent>
                <SidebarMenu>
                  {group.items.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton
                        asChild
                        isActive={pathname === item.href}
                        tooltip={item.title}
                      >
                        <Link
                          href={item.href}
                          className="flex items-center gap-2"
                        >
                          <item.icon className="h-4 w-4" />
                          {item.title}
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          ))}
      </SidebarContent>
    </Sidebar>
  );
}
