"use client";

import {
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarGroupContent,
} from "@/components/ui/sidebar";
import { FolderTree, CreditCard, FileText, Leaf, Settings } from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useSidebar } from "@/components/ui/sidebar";
const menuItems = [
  {
    title: "Projects",
    items: [
      {
        title: "My Projects",
        icon: FolderTree,
        href: "/owner/projects",
      },
    ],
  },
  {
    title: "Financial",
    items: [
      {
        title: "Transactions",
        icon: CreditCard,
        href: "/owner/transactions",
      },
    ],
  },
  {
    title: "Account",
    items: [
      {
        title: "Settings",
        icon: Settings,
        href: "/owner/settings",
      },
    ],
  },
];
export function OwnerSidebar() {
  const pathname = usePathname();
  const { state } = useSidebar();

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader className="p-4">
        <div className="flex items-center gap-2">
          <Leaf className="h-6 w-6 text-primary" />
          {state === "expanded" && (
            <span className="font-bold text-lg">Akhdar Dashboard</span>
          )}
        </div>
      </SidebarHeader>

      <SidebarContent>
        {menuItems
          .filter((group) => group.items && group.items.length > 0)
          .map((group) => (
            <SidebarGroup key={group.title}>
              <SidebarGroupLabel>{group.title}</SidebarGroupLabel>

              <SidebarGroupContent>
                <SidebarMenu>
                  {group.items.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton
                        asChild
                        isActive={pathname === item.href}
                        tooltip={item.title}
                      >
                        <Link
                          href={item.href}
                          className="flex items-center gap-2"
                        >
                          <item.icon className="h-4 w-4" />
                          {item.title}
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          ))}
      </SidebarContent>
    </Sidebar>
  );
}
