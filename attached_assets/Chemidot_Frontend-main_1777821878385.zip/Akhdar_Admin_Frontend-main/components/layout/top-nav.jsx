"use client";

import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { SidebarTrigger, useSidebar } from "@/components/ui/sidebar";
import { User, LogOut } from "lucide-react";
import { useRouter } from "next/navigation";
import { useDispatch, useSelector } from "react-redux";
import { clearUser } from "@/store/userSlice";
import { clearAuthData, getSessionType } from "@/utils/authStorage";
export function TopNav() {
  const router = useRouter();
  const dispatch = useDispatch();
  const userData = useSelector((state) => state.user.userData);
  const sessionType = getSessionType();
  const { state } = useSidebar();

  const handleLogout = () => {
    // Clear Redux state
    dispatch(clearUser());

    // Clear localStorage
    clearAuthData();

    // Redirect to main login page
    router.push("/");
  };
  return (
    <header className="border-b bg-background px-6 py-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <SidebarTrigger />
          <h2 className="text-lg font-semibold">
            Hello,{" "}
            {(userData?.FirstName || userData?.firstName) && (userData?.LastName || userData?.lastName)
              ? `${userData.FirstName || userData.firstName} ${userData.LastName || userData.lastName}`
              : userData?.FirstName || userData?.firstName || "User"}
          </h2>
        </div>

        <div className="flex items-center gap-4">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                <Avatar className="h-8 w-8">
                  <AvatarFallback>
                    {userData?.FirstName || userData?.firstName
                      ? `${(userData.FirstName || userData.firstName)[0]}${(userData.LastName || userData.lastName)?.[0] || ''}`
                      : 'U'}
                  </AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>

            <DropdownMenuContent className="w-56" align="end" forceMount>
              <DropdownMenuLabel className="font-normal">
                <div className="flex flex-col space-y-1">
                  <p className="text-sm font-medium leading-none">
                    {(userData?.FirstName || userData?.firstName) && (userData?.LastName || userData?.lastName)
                      ? `${userData.FirstName || userData.firstName} ${userData.LastName || userData.lastName}`
                      : userData?.Email || "User"}
                  </p>
                  <p className="text-xs leading-none text-muted-foreground">
                    {userData?.Email || "user@example.com"}
                  </p>
                  {userData?.UserType && (
                    <p className="text-xs text-blue-600 leading-none font-medium">
                      {userData.UserType === "SuperAdmin"
                        ? "Super Admin"
                        : userData.UserType === "Admin"
                        ? "Admin"
                        : userData.UserType === "ProjectOwner"
                        ? "Project Owner"
                        : userData.UserType}
                    </p>
                  )}
                  {sessionType === "sessionStorage" && (
                    <p className="text-xs text-orange-600 leading-none">
                      Session expires when browser closes
                    </p>
                  )}
                  {sessionType === "localStorage" && (
                    <p className="text-xs text-green-600 leading-none">
                      Remembered for 30 days
                    </p>
                  )}
                </div>
              </DropdownMenuLabel>

              <DropdownMenuSeparator />

              <DropdownMenuItem onClick={handleLogout}>
                <LogOut className="mr-2 h-4 w-4" />
                Log out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}
