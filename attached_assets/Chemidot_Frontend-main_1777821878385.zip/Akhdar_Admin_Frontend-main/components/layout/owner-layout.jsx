import { SidebarProvider } from "@/components/ui/sidebar";
import { OwnerSidebar } from "./owner-sidebar";
import { TopNav } from "./top-nav";
export function OwnerLayout({ children }) {
  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full overflow-hidden">
        <OwnerSidebar />

        <div className="flex-1 flex flex-col min-w-0">
          <TopNav />

          <main className="flex-1 p-6 bg-muted/50 overflow-auto">{children}</main>
        </div>
      </div>
    </SidebarProvider>
  );
}
