"use client";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { DataTable } from "@/components/ui/data-table";
import { TablePagination } from "@/components/ui/table-pagination";
import {
  ArrowUpDown,
  MoreHorizontal,
  Eye,
  Edit,
  Send,
  Download,
  FileText,
  Loader2,
} from "lucide-react";
import Link from "next/link";
import { useState, useEffect } from "react";
import { projectsService } from "@/services/api/projectsService";
import { toast } from "sonner";
import { useSelector } from "react-redux";

const formatProjectData = (apiProject) => {
  const getStatusFromProject = (project) => {
    if (project.Status === "Rejected" || project.ProjectStatus === "rejected") return "rejected";
    if (project.Status === "Active" && project.IsActive) return "active";
    if (project.Status === "Suspended" && !project.IsActive) return "suspended";
    if (project.ProjectStatus === "active" && project.IsActive) return "active";
    return "pending";
  };

  const getVintageDisplay = (project) => {
    if (project.Vintages && project.Vintages.length > 0) {
      const years = project.Vintages.map(vintage => vintage.Year).filter(year => year).sort((a, b) => b - a);
      return years.length > 0 ? years[0].toString() : "N/A";
    }
    return "N/A";
  };

  const getPrice = (project) => {
    if (project.DefaultCarbonPricePerTon && project.DefaultCarbonPricePerTon > 0) {
      return `${project.DefaultCarbonPricePerTon.toFixed(2)} SAR`;
    }
    if (project.Vintages && project.Vintages.length > 0) {
      const firstVintage = project.Vintages[0];
      if (firstVintage.CarbonPricePerTon && firstVintage.CarbonPricePerTon > 0) {
        return `${firstVintage.CarbonPricePerTon.toFixed(2)} SAR`;
      }
    }
    return "-";
  };

  return {
    id: apiProject.id || "N/A",
    name: apiProject.ProjectName || "Unnamed Project",
    standard: apiProject.StandardType || "N/A",
    country: apiProject.Country || "N/A",
    vintage: getVintageDisplay(apiProject),
    available: apiProject.AvailableStock
      ? `${apiProject.AvailableStock.toLocaleString()} tCO₂e`
      : "0 tCO₂e",
    price: getPrice(apiProject),
    status: getStatusFromProject(apiProject),
    submittedAt: apiProject.CreatedAt
      ? new Date(apiProject.CreatedAt).toLocaleDateString()
      : "N/A",
    lastUpdated: apiProject.UpdatedAt
      ? new Date(apiProject.UpdatedAt).toLocaleDateString()
      : apiProject.CreatedAt
      ? new Date(apiProject.CreatedAt).toLocaleDateString()
      : "N/A",
    original: apiProject,
  };
};

export function OwnerProjectsTable() {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [hasNextPage, setHasNextPage] = useState(false);
  const [totalCount, setTotalCount] = useState(0);
  const [documentsDialogOpen, setDocumentsDialogOpen] = useState(false);
  const [currentProjectDocuments, setCurrentProjectDocuments] = useState([]);
  const [documentsLoading, setDocumentsLoading] = useState(false);
  const userData = useSelector((state) => state.user.userData);
  const pageSize = 10;

  const fetchProjects = async (page = 1) => {
    try {
      setLoading(true);
      const ownerEmail = userData?.Email || userData?.email;
      if (!ownerEmail) {
        setError("Owner email not available");
        return;
      }

      const response = await projectsService.getProjects({
        pageNumber: page,
        pageSize: pageSize,
        filters: {
          projectOwnerEmail: ownerEmail
        }
      });

      if (response.success) {
        const formattedProjects = response.projects.map(formatProjectData);
        setProjects(formattedProjects);
        setHasNextPage(response.hasNextPage);
        setTotalCount(response.totalCount);
        setCurrentPage(page);
        setError(null);
      } else {
        setError("Failed to fetch projects");
      }
    } catch (err) {
      console.error("Error fetching owner projects:", err);
      setError("Failed to load projects");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProjects(1);
  }, [userData]);

  const handleNextPage = () => {
    if (hasNextPage) {
      fetchProjects(currentPage + 1);
    }
  };

  const handlePreviousPage = () => {
    if (currentPage > 1) {
      fetchProjects(currentPage - 1);
    }
  };

  const fetchProjectDocuments = async (projectId) => {
    setDocumentsLoading(true);
    try {
      const response = await projectsService.getProjectById(projectId);
      if (response.data?.success && response.data?.data?.Documents) {
        setCurrentProjectDocuments(response.data.data.Documents);
        setDocumentsDialogOpen(true);
      } else {
        toast.error("No documents found for this project");
        setCurrentProjectDocuments([]);
      }
    } catch (error) {
      console.error("Error fetching project documents:", error);
      toast.error("Failed to fetch project documents");
    } finally {
      setDocumentsLoading(false);
    }
  };

  const downloadDocument = (documentUrl, fileName) => {
    window.open(documentUrl, '_blank');
    toast.success(`${fileName} download started`);
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getFileIcon = (mimeType) => {
    if (mimeType?.includes('pdf')) return '📄';
    if (mimeType?.includes('image')) return '🖼️';
    if (mimeType?.includes('text') || mimeType?.includes('csv')) return '📊';
    if (mimeType?.includes('word')) return '📝';
    if (mimeType?.includes('excel') || mimeType?.includes('spreadsheet')) return '📈';
    return '📄';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-32">
        <Loader2 className="h-6 w-6 animate-spin" />
        <span className="ml-2">Loading projects...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-32 text-red-500">
        <span>{error}</span>
        <Button
          variant="outline"
          className="ml-4"
          onClick={() => fetchProjects(currentPage)}
        >
          Retry
        </Button>
      </div>
    );
  }

  const columns = [
    {
      id: "select",
      header: ({ table }) => <></>,
      cell: ({ row }) => <></>,
      enableSorting: false,
      enableHiding: false,
    },
    {
      accessorKey: "id",
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Project ID
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      ),
      cell: ({ row }) => <div className="font-mono">{row.getValue("id")}</div>,
    },
    {
      accessorKey: "name",
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Name
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      ),
      cell: ({ row }) => (
        <div className="font-medium max-w-[200px] truncate">
          {row.getValue("name")}
        </div>
      ),
    },
    {
      accessorKey: "standard",
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Standard
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      ),
      cell: ({ row }) => <div>{row.getValue("standard")}</div>,
    },
    {
      accessorKey: "country",
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Country
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      ),
      cell: ({ row }) => <div>{row.getValue("country")}</div>,
    },
    {
      accessorKey: "vintage",
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Vintage
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      ),
      cell: ({ row }) => <div>{row.getValue("vintage")}</div>,
    },
    {
      accessorKey: "available",
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Available
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      ),
      cell: ({ row }) => (
        <div className="font-mono">{row.getValue("available")}</div>
      ),
    },
    {
      accessorKey: "price",
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Price
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      ),
      cell: ({ row }) => <div className="font-mono">{row.getValue("price")}</div>,
    },
    {
      accessorKey: "status",
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Status
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      ),
      cell: ({ row }) => {
        const status = row.getValue("status");
        return (
          <Badge
            variant={
              status === "active"
                ? "default"
                : status === "pending"
                ? "secondary"
                : status === "rejected"
                ? "destructive"
                : "outline"
            }
          >
            {status}
          </Badge>
        );
      },
    },
    {
      accessorKey: "lastUpdated",
      header: ({ column }) => (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Last Updated
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      ),
      cell: ({ row }) => <div>{row.getValue("lastUpdated")}</div>,
    },
    {
      id: "actions",
      enableHiding: false,
      cell: ({ row }) => {
        const project = row.original;
        return (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-8 w-8 p-0">
                <span className="sr-only">Open menu</span>
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Actions</DropdownMenuLabel>
              <Link href={`/owner/projects?id=${project.original?.id || project.id}`}>
                <DropdownMenuItem>
                  <Eye className="mr-2 h-4 w-4" />
                  View Details
                </DropdownMenuItem>
              </Link>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onClick={() => fetchProjectDocuments(project.original?.id || project.id)}
                disabled={documentsLoading}
              >
                <FileText className="mr-2 h-4 w-4" />
                {documentsLoading ? "Loading..." : "View Documents"}
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Download className="mr-2 h-4 w-4" />
                Download CSV
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        );
      },
    },
  ];

  return (
    <div className="space-y-4">
      <DataTable
        columns={columns}
        data={projects}
        searchKey="name"
        searchPlaceholder="Search projects..."
        hideDefaultPagination={true}
      />

      <TablePagination
        currentItems={projects.length}
        totalCount={totalCount}
        currentPage={currentPage}
        itemName="projects"
        onPreviousPage={handlePreviousPage}
        onNextPage={handleNextPage}
        canPreviousPage={currentPage > 1}
        canNextPage={hasNextPage}
      />

      {/* Documents Dialog */}
      <Dialog open={documentsDialogOpen} onOpenChange={setDocumentsDialogOpen}>
        <DialogContent className="sm:max-w-[700px] max-h-[80vh] overflow-hidden">
          <DialogHeader>
            <DialogTitle>Project Documents</DialogTitle>
            <DialogDescription>
              View and download project documents
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 overflow-y-auto max-h-[60vh] py-4">
            {documentsLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin mr-2" />
                <span>Loading documents...</span>
              </div>
            ) : currentProjectDocuments.length > 0 ? (
              <div className="grid gap-4">
                {currentProjectDocuments.map((doc, index) => (
                  <div key={index} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 flex-1 min-w-0">
                        <div className="text-2xl flex-shrink-0">
                          {getFileIcon(doc.mimeType)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium text-gray-900 truncate">
                            {doc.originalName || doc.fileName || 'Unnamed Document'}
                          </h4>
                          <div className="flex items-center space-x-4 text-sm text-gray-500 mt-1">
                            <span>Size: {formatFileSize(doc.size || 0)}</span>
                            {doc.mimeType && (
                              <span>Type: {doc.mimeType.split('/')[1]?.toUpperCase() || 'Unknown'}</span>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="flex-shrink-0 ml-4">
                        <Button
                          onClick={() => downloadDocument(doc.url, doc.originalName || doc.fileName)}
                          size="sm"
                          variant="outline"
                          className="flex items-center space-x-2"
                        >
                          <Download className="h-4 w-4" />
                          <span>Download</span>
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                <FileText className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                <p>No documents found for this project</p>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setDocumentsDialogOpen(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}