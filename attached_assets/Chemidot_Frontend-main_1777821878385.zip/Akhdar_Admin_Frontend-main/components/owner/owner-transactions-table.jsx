"use client";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DataTable } from "@/components/ui/data-table";
import { ArrowUpDown, Eye, Download } from "lucide-react";
const data = [
  {
    id: "TXN-001",
    buyer: "john.doe@example.com",
    project: "Solar Farm Initiative",
    quantity: "100 tCO₂e",
    unitPrice: "45.00 SAR",
    total: "4,500.00 SAR",
    commission: "450.00 SAR",
    earnings: "4,050.00 SAR",
    status: "completed",
    date: "2024-03-15",
  },
  {
    id: "TXN-003",
    buyer: "mike.johnson@green.org",
    project: "Solar Farm Initiative",
    quantity: "75 tCO₂e",
    unitPrice: "45.00 SAR",
    total: "3,375.00 SAR",
    commission: "337.50 SAR",
    earnings: "3,037.50 SAR",
    status: "completed",
    date: "2024-03-13",
  },
  {
    id: "TXN-006",
    buyer: "sarah.smith@corp.com",
    project: "Wind Energy Farm",
    quantity: "200 tCO₂e",
    unitPrice: "52.00 SAR",
    total: "10,400.00 SAR",
    commission: "1,040.00 SAR",
    earnings: "9,360.00 SAR",
    status: "pending",
    date: "2024-03-12",
  },
];
export const columns = [
  {
    accessorKey: "id",
    header: ({ column }) => (
      <Button
        variant="ghost"
        onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
      >
        Transaction ID
        <ArrowUpDown className="ml-2 h-4 w-4" />
      </Button>
    ),
    cell: ({ row }) => <div className="font-mono">{row.getValue("id")}</div>,
  },
  {
    accessorKey: "project",
    header: "Project",
    cell: ({ row }) => <div>{row.getValue("project")}</div>,
  },
  {
    accessorKey: "quantity",
    header: ({ column }) => (
      <Button
        variant="ghost"
        onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
      >
        Quantity
        <ArrowUpDown className="ml-2 h-4 w-4" />
      </Button>
    ),
    cell: ({ row }) => (
      <div className="font-mono">{row.getValue("quantity")}</div>
    ),
  },
  {
    accessorKey: "unitPrice",
    header: "Unit Price",
    cell: ({ row }) => (
      <div className="font-mono">{row.getValue("unitPrice")}</div>
    ),
  },
  {
    accessorKey: "total",
    header: ({ column }) => (
      <Button
        variant="ghost"
        onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
      >
        Total Sale
        <ArrowUpDown className="ml-2 h-4 w-4" />
      </Button>
    ),
    cell: ({ row }) => <div className="font-mono">{row.getValue("total")}</div>,
  },
  {
    accessorKey: "commission",
    header: "Platform Fee",
    cell: ({ row }) => (
      <div className="font-mono text-muted-foreground">
        -{row.getValue("commission")}
      </div>
    ),
  },
  {
    accessorKey: "earnings",
    header: ({ column }) => (
      <Button
        variant="ghost"
        onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
      >
        Your Earnings
        <ArrowUpDown className="ml-2 h-4 w-4" />
      </Button>
    ),
    cell: ({ row }) => (
      <div className="font-mono font-medium text-green-600">
        {row.getValue("earnings")}
      </div>
    ),
  },
  {
    accessorKey: "status",
    header: "Status",
    cell: ({ row }) => {
      const status = row.getValue("status");
      return (
        <Badge
          variant={
            status === "completed"
              ? "default"
              : status === "pending"
              ? "secondary"
              : "destructive"
          }
        >
          {status}
        </Badge>
      );
    },
  },
  {
    accessorKey: "date",
    header: ({ column }) => (
      <Button
        variant="ghost"
        onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
      >
        Date
        <ArrowUpDown className="ml-2 h-4 w-4" />
      </Button>
    ),
    cell: ({ row }) => <div>{row.getValue("date")}</div>,
  },
  {
    id: "actions",
    enableHiding: false,
    cell: ({ row }) => {
      return (
        <div className="flex gap-2">
          <Button variant="ghost" size="sm">
            <Eye className="h-4 w-4" />
          </Button>

          <Button variant="ghost" size="sm">
            <Download className="h-4 w-4" />
          </Button>
        </div>
      );
    },
  },
];
export function OwnerTransactionsTable() {
  return (
    <div className="space-y-4">
      <DataTable
        columns={columns}
        data={data}
        searchKey="project"
        searchPlaceholder="Search by project..."
        hideDefaultPagination={true}
      />

      <div className="flex items-center justify-between">
        <div className="text-sm text-muted-foreground">
          Showing {data.length} of {data.length} transactions (Page 1)
        </div>
        <div className="flex space-x-2">
          <Button
            variant="outline"
            size="sm"
            disabled={true}
          >
            Previous
          </Button>
          <Button
            variant="outline"
            size="sm"
            disabled={true}
          >
            Next
          </Button>
        </div>
      </div>
    </div>
  );
}
