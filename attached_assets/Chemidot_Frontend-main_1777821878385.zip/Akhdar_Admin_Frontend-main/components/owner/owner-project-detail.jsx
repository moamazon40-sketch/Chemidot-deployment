"use client";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  ArrowLeft,
  Edit,
  Download,
  MapPin,
  Calendar,
  Award,
} from "lucide-react";
import Link from "next/link";
import { toast } from "sonner";
// Mock project data for owner view
const project = {
  id: "PRJ-002",
  name: "Solar Farm Initiative",
  description:
    "Large-scale solar energy project generating clean electricity and carbon credits.",
  standard: "Gold Standard",
  country: "India",
  vintage: "2024",
  available: "1,890 tCO₂e",
  price: "45.00 SAR",
  status: "active",
  submittedAt: "2024-02-20",
  approvedAt: "2024-03-01",
  location: {
    lat: 28.6139,
    lng: 77.209,
  },
  earnings: "85,050.00 SAR",
  totalSold: "1,890 tCO₂e",
};
export function OwnerProjectDetail({ projectId }) {
  const downloadProjectCSV = () => {
    const csvData = [
      ["Field", "Value"],
      ["Project ID", project.id],
      ["Name", project.name],
      ["Description", project.description],
      ["Standard", project.standard],
      ["Country", project.country],
      ["Vintage", project.vintage],
      ["Available Stock", project.available],
      ["Price", project.price],
      ["Status", project.status],
      ["Submitted Date", project.submittedAt],
      ["Approved Date", project.approvedAt],
      ["Total Earnings", project.earnings],
      ["Total Sold", project.totalSold],
    ];

    const csvContent = csvData
      .map((row) => row.map((cell) => `"${cell}"`).join(","))
      .join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute(
      "download",
      `${project.name.replace(/[^a-z0-9]/gi, '_')}_${new Date().toISOString().split("T")[0]}.csv`
    );
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    toast.success(`${project.name} data exported successfully`);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" asChild>
          <Link href="/owner/projects">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Projects
          </Link>
        </Button>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
            <div className="space-y-2 flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <CardTitle className="text-2xl">{project.name}</CardTitle>
                <Badge
                  variant={
                    project.status === "active"
                      ? "default"
                      : project.status === "pending"
                      ? "secondary"
                      : "destructive"
                  }
                >
                  {project.status}
                </Badge>
              </div>

              <CardDescription>
                <div className="flex items-center gap-4 text-sm flex-wrap">
                  <span className="flex items-center gap-1">
                    <MapPin className="h-4 w-4" />
                    {project.country}
                  </span>
                  <span className="flex items-center gap-1">
                    <Award className="h-4 w-4" />
                    {project.standard}
                  </span>
                  <span className="flex items-center gap-1">
                    <Calendar className="h-4 w-4" />
                    Vintage {project.vintage}
                  </span>
                </div>
              </CardDescription>
            </div>

            <div className="flex gap-2 flex-shrink-0">
              <Button variant="outline" asChild>
                <Link href={`/owner/projects/${projectId}/edit`}>
                  <Edit className="h-4 w-4 mr-2" />
                  Edit
                </Link>
              </Button>

              <Button variant="outline" onClick={downloadProjectCSV}>
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
          </div>
        </CardHeader>

        <CardContent>
          <div className="grid gap-4 md:grid-cols-4">
            <div className="text-center p-4 border rounded-lg">
              <div className="text-2xl font-bold text-primary">
                {project.available}
              </div>
              <div className="text-sm text-muted-foreground">Available</div>
            </div>

            <div className="text-center p-4 border rounded-lg">
              <div className="text-2xl font-bold text-green-600">
                {project.totalSold}
              </div>
              <div className="text-sm text-muted-foreground">Total Sold</div>
            </div>

            <div className="text-center p-4 border rounded-lg">
              <div className="text-2xl font-bold">{project.price}</div>
              <div className="text-sm text-muted-foreground">
                Price per tCO₂e
              </div>
            </div>

            <div className="text-center p-4 border rounded-lg">
              <div className="text-2xl font-bold text-green-600">
                {project.earnings}
              </div>
              <div className="text-sm text-muted-foreground">
                Total Earnings
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="sales">Sales History</TabsTrigger>
          <TabsTrigger value="documents">Documents</TabsTrigger>
          <TabsTrigger value="compliance">Compliance Status</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Project Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-medium mb-2">Description</h4>
                  <p className="text-sm text-muted-foreground">
                    {project.description}
                  </p>
                </div>

                <div className="grid gap-3">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Project ID:</span>
                    <span className="font-mono">{project.id}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Standard:</span>
                    <span>{project.standard}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Submitted:</span>
                    <span>{project.submittedAt}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Approved:</span>
                    <span>{project.approvedAt}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Performance Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Credits Sold</span>
                    <span className="font-mono">{project.totalSold}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Total Revenue</span>
                    <span className="font-mono text-green-600">
                      {project.earnings}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Average Price</span>
                    <span className="font-mono">{project.price}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Status</span>
                    <Badge variant="default">{project.status}</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="sales">
          <Card>
            <CardHeader>
              <CardTitle>Sales History</CardTitle>
              <CardDescription>
                Recent transactions for this project
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <p className="text-muted-foreground">
                  Sales history would be displayed here
                </p>
                <Button variant="outline" className="mt-4 bg-transparent">
                  View All Transactions
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="documents">
          <Card>
            <CardHeader>
              <CardTitle>Project Documents</CardTitle>
              <CardDescription>
                All uploaded project documentation
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <p className="text-muted-foreground">
                  Document management would be displayed here
                </p>
                <Button variant="outline" className="mt-4 bg-transparent">
                  Manage Documents
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="compliance">
          <Card>
            <CardHeader>
              <CardTitle>Compliance Status</CardTitle>
              <CardDescription>
                Current compliance and verification status
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <p className="font-medium">Initial Verification</p>
                    <p className="text-sm text-muted-foreground">
                      Completed by T V S D
                    </p>
                  </div>
                  <Badge variant="default">Completed</Badge>
                </div>

                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <p className="font-medium">Annual Monitoring</p>
                    <p className="text-sm text-muted-foreground">
                      Due: March 2025
                    </p>
                  </div>
                  <Badge variant="secondary">Upcoming</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
