"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Download, CreditCard, FileText } from "lucide-react";
export function OwnerQuickActions() {
  const actions = [
    {
      title: "Submit New Project",
      description: "Add a new carbon credit project",
      icon: Plus,
      action: "Get Started",
    },
    {
      title: "View Transactions",
      description: "See all your sales and payments",
      icon: CreditCard,
      action: "View All",
    },
    {
      title: "Export Data",
      description: "Download your project data",
      icon: Download,
      action: "Export CSV",
    },
    {
      title: "Documentation",
      description: "Learn about project requirements",
      icon: FileText,
      action: "Read Docs",
    },
  ];
  return (
    <Card>
      <CardHeader>
        <CardTitle>Quick Actions</CardTitle>
      </CardHeader>

      <CardContent>
        <div className="space-y-3">
          {actions.map((action, index) => {
            const Icon = action.icon;
            return (
              <div
                key={index}
                className="flex items-center justify-between p-3 border rounded-lg"
              >
                <div className="flex items-center gap-3">
                  <Icon className="h-5 w-5 text-muted-foreground" />
                  <div className="space-y-1">
                    <p className="text-sm font-medium leading-none">
                      {action.title}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {action.description}
                    </p>
                  </div>
                </div>

                <Button variant="outline" size="sm">
                  {action.action}
                </Button>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
