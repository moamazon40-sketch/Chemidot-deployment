"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Filter, X } from "lucide-react";
import { useState } from "react";

export function OwnerTransactionFilters({ onFiltersChange }) {
  const [filters, setFilters] = useState({
    transactionId: "",
    project: "",
    status: "",
    dateRange: "",
  });
  const [hasChanges, setHasChanges] = useState(false);
  const [appliedFilters, setAppliedFilters] = useState({
    transactionId: "",
    project: "",
    status: "",
    dateRange: "",
  });

  const handleFilterChange = (key, value) => {
    const newFilters = {
      ...filters,
      [key]: value,
    };
    setFilters(newFilters);

    // Check if filters have changed from applied filters
    const filtersChanged = JSON.stringify(newFilters) !== JSON.stringify(appliedFilters);
    setHasChanges(filtersChanged);

    onFiltersChange?.(newFilters);
  };

  const applyFilters = () => {
    console.log("Applying transaction filters:", filters);
    setAppliedFilters(filters);
    setHasChanges(false);
    onFiltersChange?.(filters, true);
  };

  const clearFilters = () => {
    const clearedFilters = {
      transactionId: "",
      project: "",
      status: "",
      dateRange: "",
    };
    setFilters(clearedFilters);
    setAppliedFilters(clearedFilters);
    setHasChanges(false);
    onFiltersChange?.(clearedFilters, true);
  };

  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center gap-2 mb-4">
          <Filter className="h-4 w-4" />
          <span className="font-medium">Transaction Filters</span>
          <Button
            variant="ghost"
            size="sm"
            onClick={clearFilters}
            className="ml-auto"
          >
            <X className="h-4 w-4 mr-1" />
            Clear All
          </Button>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <div className="space-y-2">
            <Label htmlFor="transactionId">Transaction ID</Label>
            <Input
              id="transactionId"
              placeholder="Enter transaction ID"
              value={filters.transactionId}
              onChange={(e) => handleFilterChange("transactionId", e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="project">Project</Label>
            <Input
              id="project"
              placeholder="Enter project name"
              value={filters.project}
              onChange={(e) => handleFilterChange("project", e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="status">Status</Label>
            <select
              id="status"
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              value={filters.status}
              onChange={(e) => handleFilterChange("status", e.target.value)}
            >
              <option value="">All Statuses</option>
              <option value="completed">Completed</option>
              <option value="pending">Pending</option>
              <option value="failed">Failed</option>
            </select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="dateRange">Date Range</Label>
            <select
              id="dateRange"
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              value={filters.dateRange}
              onChange={(e) => handleFilterChange("dateRange", e.target.value)}
            >
              <option value="">All Time</option>
              <option value="today">Today</option>
              <option value="week">This Week</option>
              <option value="month">This Month</option>
              <option value="quarter">This Quarter</option>
              <option value="year">This Year</option>
            </select>
          </div>
        </div>

        <div className="mt-6 flex justify-end">
          <Button
            onClick={applyFilters}
            disabled={!hasChanges}
            className={hasChanges ? "bg-green-600 hover:bg-green-700" : ""}
          >
            Apply Filters
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}