"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Eye } from "lucide-react";
const projects = [
  {
    name: "Solar Farm Initiative",
    status: "Active",
    credits: "850 tCO₂e",
    revenue: "42,500 SAR",
  },
  {
    name: "Reforestation Project",
    status: "Pending",
    credits: "1,200 tCO₂e",
    revenue: "0 SAR",
  },
  {
    name: "Wind Energy Farm",
    status: "Active",
    credits: "650 tCO₂e",
    revenue: "32,500 SAR",
  },
];
export function OwnerProjects() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>My Projects</CardTitle>
      </CardHeader>

      <CardContent>
        <div className="space-y-4">
          {projects.map((project, index) => (
            <div
              key={index}
              className="flex items-center justify-between p-3 border rounded-lg"
            >
              <div className="space-y-1">
                <p className="text-sm font-medium leading-none">
                  {project.name}
                </p>
                <p className="text-xs text-muted-foreground">
                  {project.credits}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <div className="text-right space-y-1">
                  <p className="text-sm font-medium">{project.revenue}</p>
                  <Badge
                    variant={
                      project.status === "Active" ? "default" : "secondary"
                    }
                  >
                    {project.status}
                  </Badge>
                </div>

                <Button variant="ghost" size="sm">
                  <Eye className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
