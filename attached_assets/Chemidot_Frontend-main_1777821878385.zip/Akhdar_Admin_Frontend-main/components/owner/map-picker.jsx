"use client";

import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { MapPin, Upload } from "lucide-react";
export function MapPicker({
  onLocationChange,
  initialLocation = {
    lat: 0,
    lng: 0,
  },
}) {
  const [location, setLocation] = useState(initialLocation);
  const handleLocationChange = (field, value) => {
    const numValue = Number.parseFloat(value) || 0;
    const newLocation = {
      ...location,
      [field]: numValue,
    };
    setLocation(newLocation);
    onLocationChange(newLocation);
  };
  return (
    <div className="space-y-4">
      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="latitude">Latitude *</Label>
          <Input
            id="latitude"
            type="number"
            step="any"
            value={location.lat}
            onChange={(e) => handleLocationChange("lat", e.target.value)}
            placeholder="e.g., -3.4653"
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="longitude">Longitude *</Label>
          <Input
            id="longitude"
            type="number"
            step="any"
            value={location.lng}
            onChange={(e) => handleLocationChange("lng", e.target.value)}
            placeholder="e.g., -62.2159"
            required
          />
        </div>
      </div>

      <Card>
        <CardContent className="p-6">
          <div className="aspect-video bg-muted rounded-lg flex items-center justify-center">
            <div className="text-center">
              <MapPin className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-lg font-medium mb-2">Interactive Map</p>
              <p className="text-sm text-muted-foreground mb-4">
                Click on the map to set project location
                <br />
                Current: {location.lat.toFixed(6)}, {location.lng.toFixed(6)}
              </p>

              <Button variant="outline" size="sm">
                <MapPin className="h-4 w-4 mr-2" />
                Use Current Location
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium">Project Boundaries (Optional)</h4>
              <p className="text-sm text-muted-foreground">
                Upload shapefile (.zip) or GeoJSON for project area
              </p>
            </div>

            <Button variant="outline" size="sm">
              <Upload className="h-4 w-4 mr-2" />
              Upload Shapefile
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
