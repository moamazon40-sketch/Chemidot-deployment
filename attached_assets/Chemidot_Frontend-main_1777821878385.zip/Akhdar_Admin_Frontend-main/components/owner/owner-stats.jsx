"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, TrendingDown } from "lucide-react";
function StatCard({ title, value, change, changeLabel, trend }) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
      </CardHeader>

      <CardContent>
        <div className="text-2xl font-bold">{value}</div>

        {change !== undefined && (
          <div
            className={`flex items-center gap-1 text-xs ${
              trend === "up" ? "text-green-600" : "text-red-600"
            }`}
          >
            {trend === "up" ? (
              <TrendingUp className="h-3 w-3" />
            ) : (
              <TrendingDown className="h-3 w-3" />
            )}
            <span>{Math.abs(change)}%</span>
            {changeLabel && (
              <span className="text-muted-foreground">{changeLabel}</span>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
export function OwnerStats() {
  const stats = [
    {
      title: "Active Projects",
      value: "3",
      change: 0,
      changeLabel: "no change",
    },
    {
      title: "Credits Available",
      value: "1,247 tCO₂e",
      change: -5.2,
      changeLabel: "from last month",
      trend: "down",
    },
    {
      title: "Sales This Period",
      value: "18,450 SAR",
      change: 12.3,
      changeLabel: "from last month",
      trend: "up",
    },
    {
      title: "Pending Payouts",
      value: "2,100 SAR",
      change: 8.7,
      changeLabel: "from last week",
      trend: "up",
    },
  ];
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat, index) => (
        <StatCard key={index} {...stat} />
      ))}
    </div>
  );
}
