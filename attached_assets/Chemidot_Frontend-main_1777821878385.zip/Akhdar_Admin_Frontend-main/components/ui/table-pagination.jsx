"use client";

import { Button } from "@/components/ui/button";

export function TablePagination({
  currentItems,
  totalCount,
  currentPage,
  itemName = "items",
  onPreviousPage,
  onNextPage,
  canPreviousPage = true,
  canNextPage = true
}) {
  return (
    <div className="flex items-center justify-between">
      <div className="text-sm text-muted-foreground">
        Showing {currentItems} of {totalCount} {itemName} (Page {currentPage})
      </div>
      <div className="flex space-x-2">
        <Button
          variant="outline"
          size="sm"
          onClick={onPreviousPage}
          disabled={!canPreviousPage || currentPage === 1}
        >
          Previous
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={onNextPage}
          disabled={!canNextPage}
        >
          Next
        </Button>
      </div>
    </div>
  );
}