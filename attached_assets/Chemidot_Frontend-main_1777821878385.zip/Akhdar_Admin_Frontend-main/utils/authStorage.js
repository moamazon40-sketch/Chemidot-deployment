/**
 * Authentication storage utility functions
 * Uses localStorage as the primary storage method for better UX
 */

const AUTH_KEY = "User";

/**
 * Store user authentication data
 * @param {Object} userData - User authentication data
 * @param {boolean} rememberMe - Whether to use persistent storage (localStorage)
 */
export const setAuthData = (userData, rememberMe = true) => {
  try {
    if (rememberMe) {
      // Use localStorage for persistent storage
      localStorage.setItem(AUTH_KEY, JSON.stringify(userData));
      // Clean up sessionStorage
      sessionStorage.removeItem(AUTH_KEY);
    } else {
      // Use sessionStorage for session-only storage
      sessionStorage.setItem(AUTH_KEY, JSON.stringify(userData));
      // Clean up localStorage
      localStorage.removeItem(AUTH_KEY);
    }
  } catch (error) {
    console.error("Error storing auth data:", error);
    // Fallback to the other storage method
    try {
      if (rememberMe) {
        sessionStorage.setItem(AUTH_KEY, JSON.stringify(userData));
      } else {
        localStorage.setItem(AUTH_KEY, JSON.stringify(userData));
      }
    } catch (fallbackError) {
      console.error("Error with fallback storage:", fallbackError);
    }
  }
};

/**
 * Get user authentication data
 * @returns {Object|null} - User authentication data or null
 */
export const getAuthData = () => {
  try {
    // Try localStorage first, then sessionStorage for backward compatibility
    const authData =
      localStorage.getItem(AUTH_KEY) || sessionStorage.getItem(AUTH_KEY);
    return authData ? JSON.parse(authData) : null;
  } catch (error) {
    console.error("Error reading auth data:", error);
    return null;
  }
};

/**
 * Remove user authentication data
 */
export const clearAuthData = () => {
  try {
    localStorage.removeItem(AUTH_KEY);
    sessionStorage.removeItem(AUTH_KEY);
  } catch (error) {
    console.error("Error clearing auth data:", error);
  }
};

/**
 * Get authentication token
 * @returns {string|null} - Authentication token or null
 */
export const getAuthToken = () => {
  const authData = getAuthData();
  return authData?.token || authData?.accessToken || authData || null;
};

/**
 * Check if user is authenticated
 * @returns {boolean} - True if user is authenticated
 */
export const isAuthenticated = () => {
  return !!getAuthToken();
};

/**
 * Check if the current session is persistent (localStorage)
 * @returns {boolean} - True if user chose to be remembered
 */
export const isPersistentSession = () => {
  try {
    return !!localStorage.getItem(AUTH_KEY);
  } catch (error) {
    return false;
  }
};

/**
 * Get the storage type being used for the current session
 * @returns {string} - "localStorage", "sessionStorage", or "none"
 */
export const getSessionType = () => {
  try {
    if (localStorage.getItem(AUTH_KEY)) {
      return "localStorage";
    }
    if (sessionStorage.getItem(AUTH_KEY)) {
      return "sessionStorage";
    }
    return "none";
  } catch (error) {
    return "none";
  }
};

/**
 * Migrate old sessionStorage data to localStorage
 * This is a one-time migration utility
 */
export const migrateAuthStorage = () => {
  try {
    const sessionData = sessionStorage.getItem(AUTH_KEY);
    const localData = localStorage.getItem(AUTH_KEY);

    // If we have session data but no local data, migrate it
    if (sessionData && !localData) {
      localStorage.setItem(AUTH_KEY, sessionData);
      sessionStorage.removeItem(AUTH_KEY);
      console.log("Auth data migrated from sessionStorage to localStorage");
    }
  } catch (error) {
    console.error("Error migrating auth storage:", error);
  }
};

// Auto-migrate on import
migrateAuthStorage();