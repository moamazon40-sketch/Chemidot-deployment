import { createSlice } from "@reduxjs/toolkit";

const getInitialUserData = () => {
  if (typeof window === 'undefined') return null;

  try {
    return (
      JSON.parse(localStorage.getItem("User")) ||
      JSON.parse(sessionStorage.getItem("User")) || // Fallback for migration
      null
    );
  } catch {
    return null;
  }
};

const initialState = {
  userData: getInitialUserData(),
};

const userSlice = createSlice({
  name: "User",
  initialState,
  reducers: {
    setUserData: (state, action) => {
      // Combine the token and UserID into a single user object
      const userData = {
        token: action.payload.userObj || action.payload.token,
        UserID: action.payload.UserID,
        ...action.payload, // Include any additional user data
      };

      state.userData = userData;

      // Handle remember me functionality properly
      if (typeof window !== 'undefined') {
        if (action.payload.RememberMe === false) {
          // User chose NOT to be remembered - use sessionStorage only
          sessionStorage.setItem("User", JSON.stringify(userData));
          // Remove from localStorage if it exists
          localStorage.removeItem("User");
        } else {
          // User chose to be remembered (default) - use localStorage
          localStorage.setItem("User", JSON.stringify(userData));
          // Remove from sessionStorage to avoid confusion
          sessionStorage.removeItem("User");
        }
      }
    },
    clearUser: (state) => {
      state.userData = null;
      if (typeof window !== 'undefined') {
        localStorage.removeItem("User");
        sessionStorage.removeItem("User"); // Cleanup both for migration
      }
    },
    updateUserData: (state, action) => {
      state.userData = { ...state.userData, ...action.payload };
      if (state.userData && typeof window !== 'undefined') {
        // Always store in localStorage
        localStorage.setItem("User", JSON.stringify(state.userData));
      }
    },
    setUserSubscriptions: (state, action) => {
      if (state.userData) {
        state.userData.Subscriptions = action.payload;
        // Update localStorage
        if (typeof window !== 'undefined') {
          localStorage.setItem("User", JSON.stringify(state.userData));
        }
      }
    },
  },
});

export const { setUserData, clearUser, updateUserData, setUserSubscriptions } =
  userSlice.actions;
export default userSlice.reducer;
