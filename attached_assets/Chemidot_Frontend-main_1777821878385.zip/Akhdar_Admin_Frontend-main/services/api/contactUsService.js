import { apiInstance } from "./apiInstance";

const CONTACT_US_CACHE = new Map();
let lastCacheUpdate = 0;
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

export const contactUsService = {
  async getContactUsRequests({ pageNumber = 1, pageSize = 10, filters = null }) {
    if (typeof window === 'undefined') {
      return {
        success: false,
        requests: [],
        totalCount: 0,
        currentPage: pageNumber,
        pageSize: pageSize,
        hasNextPage: false
      };
    }

    // Build query parameters
    const params = new URLSearchParams({
      PageNumber: pageNumber.toString(),
      PageSize: pageSize.toString()
    });

    // Add filter parameters if they exist and are not empty
    if (filters) {
      console.log("Processing contact us filters:", filters);

      if (filters.userEmail && filters.userEmail.toString().trim()) {
        params.append('UserEmail', filters.userEmail.toString().trim());
      }
    }

    const queryString = params.toString();
    const cacheKey = `contact_us_${queryString}`;
    const currentTime = Date.now();

    // For filtered requests, skip cache to ensure fresh data
    const useCache = !filters && CONTACT_US_CACHE.has(cacheKey) && (currentTime - lastCacheUpdate) < CACHE_DURATION;
    if (useCache) {
      return CONTACT_US_CACHE.get(cacheKey);
    }

    try {
      console.log(`Fetching contact us requests with filters:`, filters);
      console.log(`Full query string: ${queryString}`);
      console.log(`Complete API URL: AdminGetAllContactUsRequests?${queryString}`);

      const response = await apiInstance.get(`AdminGetAllContactUsRequests?${queryString}`);
      console.log('Contact Us API Response:', response.data);
      console.log('Response status:', response.status);

      const result = {
        success: response.data.Success,
        requests: response.data.Requests || [],
        totalCount: response.data.AllRequestsCount || response.data.TotalRequestsCount || 0,
        currentPage: pageNumber,
        pageSize: pageSize,
        hasNextPage: false
      };

      // Check for next page if we got full page size
      if (result.requests.length === pageSize) {
        try {
          const nextPageParams = new URLSearchParams({
            PageNumber: (pageNumber + 1).toString(),
            PageSize: pageSize.toString()
          });

          // Add same filter parameters for next page check
          if (filters) {
            if (filters.userEmail && filters.userEmail.toString().trim()) {
              nextPageParams.append('UserEmail', filters.userEmail.toString().trim());
            }
          }

          const nextPageResponse = await apiInstance.get(`AdminGetAllContactUsRequests?${nextPageParams.toString()}`);
          result.hasNextPage = nextPageResponse.data.Requests && nextPageResponse.data.Requests.length > 0;
        } catch (error) {
          result.hasNextPage = false;
        }
      }

      CONTACT_US_CACHE.set(cacheKey, result);
      lastCacheUpdate = currentTime;

      return result;
    } catch (error) {
      console.error('Error fetching contact us requests:', error);
      throw error;
    }
  },

  clearCache() {
    CONTACT_US_CACHE.clear();
    lastCacheUpdate = 0;
  },

  async exportContactUsRequests({ pageNumber = 1, pageSize = 1000, filters = null, customFilename = null }) {
    if (typeof window === 'undefined') {
      throw new Error('Not available on server side');
    }

    // Build query parameters
    const params = new URLSearchParams({
      PageNumber: pageNumber.toString(),
      PageSize: pageSize.toString(),
      ExportCSV: 'true'
    });

    // Add filter parameters if they exist and are not empty
    if (filters) {
      console.log("Processing export contact us filters:", filters);

      if (filters.userEmail && filters.userEmail.toString().trim()) {
        params.append('UserEmail', filters.userEmail.toString().trim());
      }
    }

    try {
      const queryString = params.toString();
      console.log(`Exporting contact us requests with query: ${queryString}`);

      // Get the response with CSV URL
      const response = await apiInstance.get(`AdminGetAllContactUsRequests?${queryString}`);

      // Open the CSV URL directly from API response
      if (response.data.CSVFileURL) {
        window.open(response.data.CSVFileURL, '_blank');
        return { success: true, message: 'Contact Us requests exported successfully' };
      } else {
        throw new Error('CSV URL not found in response');
      }
    } catch (error) {
      console.error('Error exporting contact us requests:', error);
      throw error;
    }
  }
};