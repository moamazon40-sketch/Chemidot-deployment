import { apiInstance } from "./apiInstance";

const ESG_FORMS_CACHE = new Map();
let lastCacheUpdate = 0;
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

export const esgFormsService = {
  async getESGForms({ pageNumber = 1, pageSize = 10, filters = null }) {
    if (typeof window === 'undefined') {
      return {
        success: false,
        forms: [],
        totalCount: 0,
        currentPage: pageNumber,
        pageSize: pageSize,
        hasNextPage: false
      };
    }

    // Build query parameters
    const params = new URLSearchParams({
      PageNumber: pageNumber.toString(),
      PageSize: pageSize.toString()
    });

    // Add filter parameters if they exist and are not empty
    if (filters) {
      console.log("Processing ESG forms filters:", filters);

      if (filters.userEmail && filters.userEmail.toString().trim()) {
        params.append('UserEmail', filters.userEmail.toString().trim());
      }

      if (filters.companyName && filters.companyName.toString().trim()) {
        params.append('CompanyName', filters.companyName.toString().trim());
      }
    }

    const queryString = params.toString();
    const cacheKey = `esg_forms_${queryString}`;
    const currentTime = Date.now();

    // For filtered requests, skip cache to ensure fresh data
    const useCache = !filters && ESG_FORMS_CACHE.has(cacheKey) && (currentTime - lastCacheUpdate) < CACHE_DURATION;
    if (useCache) {
      return ESG_FORMS_CACHE.get(cacheKey);
    }

    try {
      console.log(`Fetching ESG forms with filters:`, filters);
      console.log(`Full query string: ${queryString}`);
      console.log(`Complete API URL: AdminGetAllESGForms?${queryString}`);

      const response = await apiInstance.get(`AdminGetAllESGForms?${queryString}`);
      console.log('ESG Forms API Response:', response.data);
      console.log('Response status:', response.status);

      const result = {
        success: response.data.Success,
        forms: response.data.Forms || [],
        totalCount: response.data.AllFormsCount || response.data.TotalFormsCount || 0,
        currentPage: pageNumber,
        pageSize: pageSize,
        hasNextPage: false
      };

      // Check for next page if we got full page size
      if (result.forms.length === pageSize) {
        try {
          const nextPageParams = new URLSearchParams({
            PageNumber: (pageNumber + 1).toString(),
            PageSize: pageSize.toString()
          });

          // Add same filter parameters for next page check
          if (filters) {
            if (filters.userEmail && filters.userEmail.toString().trim()) {
              nextPageParams.append('UserEmail', filters.userEmail.toString().trim());
            }
            if (filters.companyName && filters.companyName.toString().trim()) {
              nextPageParams.append('CompanyName', filters.companyName.toString().trim());
            }
          }

          const nextPageResponse = await apiInstance.get(`AdminGetAllESGForms?${nextPageParams.toString()}`);
          result.hasNextPage = nextPageResponse.data.Forms && nextPageResponse.data.Forms.length > 0;
        } catch (error) {
          result.hasNextPage = false;
        }
      }

      ESG_FORMS_CACHE.set(cacheKey, result);
      lastCacheUpdate = currentTime;

      return result;
    } catch (error) {
      console.error('Error fetching ESG forms:', error);
      throw error;
    }
  },

  clearCache() {
    ESG_FORMS_CACHE.clear();
    lastCacheUpdate = 0;
  },

  async exportESGForms({ pageNumber = 1, pageSize = 1000, filters = null, customFilename = null }) {
    if (typeof window === 'undefined') {
      throw new Error('Not available on server side');
    }

    // Build query parameters
    const params = new URLSearchParams({
      PageNumber: pageNumber.toString(),
      PageSize: pageSize.toString(),
      ExportCSV: 'true'
    });

    // Add filter parameters if they exist and are not empty
    if (filters) {
      console.log("Processing export ESG forms filters:", filters);

      if (filters.userEmail && filters.userEmail.toString().trim()) {
        params.append('UserEmail', filters.userEmail.toString().trim());
      }

      if (filters.companyName && filters.companyName.toString().trim()) {
        params.append('CompanyName', filters.companyName.toString().trim());
      }
    }

    try {
      const queryString = params.toString();
      console.log(`Exporting ESG forms with query: ${queryString}`);

      // Get the response with CSV URL
      const response = await apiInstance.get(`AdminGetAllESGForms?${queryString}`);

      // Open the CSV URL directly from API response
      if (response.data.CSVFileURL) {
        window.open(response.data.CSVFileURL, '_blank');
        return { success: true, message: 'ESG Forms exported successfully' };
      } else {
        throw new Error('CSV URL not found in response');
      }
    } catch (error) {
      console.error('Error exporting ESG forms:', error);
      throw error;
    }
  }
};