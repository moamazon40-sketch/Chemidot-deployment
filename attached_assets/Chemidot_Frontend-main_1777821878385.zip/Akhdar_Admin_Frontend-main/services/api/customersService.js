import { apiInstance } from "./apiInstance";

const CUSTOMERS_CACHE = new Map();
let lastCacheUpdate = 0;
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

export const customersService = {
  async getCustomers({ pageNumber = 1, pageSize = 10, filters = null }) {
    if (typeof window === 'undefined') {
      return {
        success: false,
        customers: [],
        totalCount: 0,
        currentPage: pageNumber,
        pageSize: pageSize,
        hasNextPage: false
      };
    }

    // Build query parameters
    const params = new URLSearchParams({
      PageNumber: pageNumber.toString(),
      PageSize: pageSize.toString()
    });

    // Add filter parameters if they exist and are not empty
    if (filters) {
      console.log("Processing customer filters:", filters);

      if (filters.userEmail && filters.userEmail.toString().trim()) {
        params.append('UserEmail', filters.userEmail.toString().trim());
        console.log("Added UserEmail:", filters.userEmail.toString().trim());
      }
    }

    const queryString = params.toString();
    const cacheKey = `customers_${queryString}`;
    const currentTime = Date.now();

    // For filtered requests, skip cache to ensure fresh data
    const useCache = !filters && CUSTOMERS_CACHE.has(cacheKey) && (currentTime - lastCacheUpdate) < CACHE_DURATION;
    if (useCache) {
      return CUSTOMERS_CACHE.get(cacheKey);
    }

    try {
      console.log(`Fetching customers with filters:`, filters);
      console.log(`Full query string: ${queryString}`);
      console.log(`Complete API URL: AdminGetAllCustomers?${queryString}`);

      const response = await apiInstance.get(`AdminGetAllCustomers?${queryString}`);
      console.log('Customers API Response:', response.data);
      console.log('Response status:', response.status);

      const result = {
        success: response.data.success,
        customers: response.data.Users || [],
        totalCount: response.data.TotalUsersCount || response.data.AllUsersCount || 0,
        allUsersCount: response.data.AllUsersCount || 0,
        currentPage: pageNumber,
        pageSize: pageSize,
        hasNextPage: false
      };

      // Check for next page if we got full page size
      if (result.customers.length === pageSize) {
        try {
          const nextPageParams = new URLSearchParams({
            PageNumber: (pageNumber + 1).toString(),
            PageSize: pageSize.toString()
          });

          // Add same filter parameters for next page check
          if (filters && filters.userEmail && filters.userEmail.toString().trim()) {
            nextPageParams.append('UserEmail', filters.userEmail.toString().trim());
          }

          const nextPageResponse = await apiInstance.get(`AdminGetAllCustomers?${nextPageParams.toString()}`);
          result.hasNextPage = nextPageResponse.data.Users && nextPageResponse.data.Users.length > 0;
        } catch (error) {
          result.hasNextPage = false;
        }
      }

      CUSTOMERS_CACHE.set(cacheKey, result);
      lastCacheUpdate = currentTime;

      return result;
    } catch (error) {
      console.error('Error fetching customers:', error);
      throw error;
    }
  },

  clearCache() {
    CUSTOMERS_CACHE.clear();
    lastCacheUpdate = 0;
  },

  async exportCustomers({ pageNumber = 1, pageSize = 1000, filters = null }) {
    if (typeof window === 'undefined') {
      throw new Error('Not available on server side');
    }

    // Build query parameters
    const params = new URLSearchParams({
      PageNumber: pageNumber.toString(),
      PageSize: pageSize.toString(),
      ExportCSV: 'true'
    });

    // Add filter parameters if they exist and are not empty
    if (filters) {
      console.log("Processing export customer filters:", filters);
      if (filters.userEmail && filters.userEmail.toString().trim()) {
        params.append('UserEmail', filters.userEmail.toString().trim());
      }
    }

    try {
      const queryString = params.toString();
      console.log(`Exporting customers with query: ${queryString}`);

      // Get the response with CSV URL
      const response = await apiInstance.get(`AdminGetAllCustomers?${queryString}`);

      // Open the CSV URL directly from API response
      if (response.data.CSVFileURL) {
        window.open(response.data.CSVFileURL, '_blank');
        return { success: true, message: 'Customers exported successfully' };
      } else {
        throw new Error('CSV URL not found in response');
      }
    } catch (error) {
      console.error('Error exporting customers:', error);
      throw error;
    }
  }
};