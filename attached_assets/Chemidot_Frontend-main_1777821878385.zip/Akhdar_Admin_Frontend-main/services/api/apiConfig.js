export const baseURL =
  "https://ha858aeok8.execute-api.eu-north-1.amazonaws.com/DEV/";

export const AUTH_URLS = {
  ADMIN_LOGIN: "AdminLogin",
  USER_LOGIN: "UserLogin",
  CREATE_ADMIN: "CreateAdmin",
};

export const CONTACT_URLS = {
  CONTACT_WITHOUT_INTEREST: `SendContactUsReply`,
  CONTACT_WITH_INTEREST: `/Users/Register`,
};

export const CALCULATOR_URLS = {
  CALCULATE_COMPANY_EMISSION: "CalculateCompanyEmission",
  CALCULATE_INDIVIDUAL_EMISSION: "CalculateIndividualEmission",
  SAVE_CALCULATION_RESULT: "SaveCalculationResult",
  GET_CALCULATIONS: "GetUserCalculations",
};

export const CARBON_OFFSET_URLS = {
  GET_USER_CARBON_OFFSETS: "GetUserCarbonOffsets",
  GET_ALL_PROJECTS: "GetAllProjects",
  GET_PROJECT_DETAILS: "GetProjectDetails",
  GET_PROJECT_BY_ID: "GetProjectByID",
  PURCHASE_OFFSET: "PurchaseOffset",
  GET_USER_RECENT_DATA: "GetUserRecentData",
};

export const ESG_URLS = {
  SEND_ESG: "ESGConsultationReply",
};

export const USER_PROFILE_URLS = {
  GET_CURRENT_USER_PROFILE: "GetCurrentUserProfile",
  UPDATE_USER_PROFILE: "UpdateUserProfile",
  CHANGE_PASSWORD: "ChangePassword",
  REQUEST_EMAIL_CHANGE: "RequestEmailChange",
  VERIFY_EMAIL_CHANGE_OTP: "VerifyEmailChangeOTP",
  RESEND_EMAIL_CHANGE_OTP: "ResendEmailChangeOTP",
};