import { apiInstance } from "./apiInstance";

const TRANSACTIONS_CACHE = new Map();
let lastCacheUpdate = 0;
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

export const transactionsService = {
  async getTransactions({ pageNumber = 1, pageSize = 10, filters = null }) {
    if (typeof window === 'undefined') {
      return {
        success: false,
        transactions: [],
        totalCount: 0,
        currentPage: pageNumber,
        pageSize: pageSize,
        hasNextPage: false
      };
    }

    // Build query parameters
    const params = new URLSearchParams({
      PageNumber: pageNumber.toString(),
      PageSize: pageSize.toString()
    });

    // Add filter parameters if they exist and are not empty
    if (filters) {
      console.log("Processing transaction filters:", filters);

      if (filters.projectName && filters.projectName.toString().trim()) {
        params.append('ProjectName', filters.projectName.toString().trim());
      }

      if (filters.paymentStatus && filters.paymentStatus.toString().trim() && filters.paymentStatus !== "all") {
        params.append('PaymentStatus', filters.paymentStatus.toString().trim());
      }

      if (filters.paymentMethod && filters.paymentMethod.toString().trim() && filters.paymentMethod !== "all") {
        params.append('PaymentMethod', filters.paymentMethod.toString().trim());
      }

      if (filters.transactionID && filters.transactionID.toString().trim()) {
        params.append('TransactionID', filters.transactionID.toString().trim());
      }

      if (filters.moyasarPaymentID && filters.moyasarPaymentID.toString().trim()) {
        params.append('MoyasarPaymentID', filters.moyasarPaymentID.toString().trim());
      }

      if (filters.buyerEmail && filters.buyerEmail.toString().trim()) {
        params.append('BuyerEmail', filters.buyerEmail.toString().trim());
      }

      if (filters.dateFrom && filters.dateFrom.toString().trim()) {
        params.append('DateFrom', filters.dateFrom.toString().trim());
      }

      if (filters.dateTo && filters.dateTo.toString().trim()) {
        params.append('DateTo', filters.dateTo.toString().trim());
      }

      if (filters.carbonAmountMin && filters.carbonAmountMin.toString().trim()) {
        params.append('CarbonAmountMin', filters.carbonAmountMin.toString().trim());
      }

      if (filters.carbonAmountMax && filters.carbonAmountMax.toString().trim()) {
        params.append('CarbonAmountMax', filters.carbonAmountMax.toString().trim());
      }
    }

    const queryString = params.toString();
    const cacheKey = `transactions_${queryString}`;
    const currentTime = Date.now();

    // For filtered requests, skip cache to ensure fresh data
    const useCache = !filters && TRANSACTIONS_CACHE.has(cacheKey) && (currentTime - lastCacheUpdate) < CACHE_DURATION;
    if (useCache) {
      return TRANSACTIONS_CACHE.get(cacheKey);
    }

    try {
      console.log(`Fetching transactions with filters:`, filters);
      console.log(`Full query string: ${queryString}`);
      console.log(`Complete API URL: AdminGetAllTransactions?${queryString}`);

      const response = await apiInstance.get(`AdminGetAllTransactions?${queryString}`);
      console.log('Transactions API Response:', response.data);
      console.log('Response status:', response.status);

      const result = {
        success: response.data.Success,
        transactions: response.data.Transactions || [],
        totalCount: response.data.AllItemsCount || response.data.TotalItemsCount || 0,
        currentPage: pageNumber,
        pageSize: pageSize,
        hasNextPage: false
      };

      // Check for next page if we got full page size
      if (result.transactions.length === pageSize) {
        try {
          const nextPageParams = new URLSearchParams({
            PageNumber: (pageNumber + 1).toString(),
            PageSize: pageSize.toString()
          });

          // Add same filter parameters for next page check
          if (filters) {
            if (filters.projectName && filters.projectName.toString().trim()) {
              nextPageParams.append('ProjectName', filters.projectName.toString().trim());
            }
            if (filters.paymentStatus && filters.paymentStatus.toString().trim()) {
              nextPageParams.append('PaymentStatus', filters.paymentStatus.toString().trim());
            }
            if (filters.paymentMethod && filters.paymentMethod.toString().trim()) {
              nextPageParams.append('PaymentMethod', filters.paymentMethod.toString().trim());
            }
            if (filters.transactionID && filters.transactionID.toString().trim()) {
              nextPageParams.append('TransactionID', filters.transactionID.toString().trim());
            }
            if (filters.moyasarPaymentID && filters.moyasarPaymentID.toString().trim()) {
              nextPageParams.append('MoyasarPaymentID', filters.moyasarPaymentID.toString().trim());
            }
            if (filters.buyerEmail && filters.buyerEmail.toString().trim()) {
              nextPageParams.append('BuyerEmail', filters.buyerEmail.toString().trim());
            }
            if (filters.dateFrom && filters.dateFrom.toString().trim()) {
              nextPageParams.append('DateFrom', filters.dateFrom.toString().trim());
            }
            if (filters.dateTo && filters.dateTo.toString().trim()) {
              nextPageParams.append('DateTo', filters.dateTo.toString().trim());
            }
            if (filters.carbonAmountMin && filters.carbonAmountMin.toString().trim()) {
              nextPageParams.append('CarbonAmountMin', filters.carbonAmountMin.toString().trim());
            }
            if (filters.carbonAmountMax && filters.carbonAmountMax.toString().trim()) {
              nextPageParams.append('CarbonAmountMax', filters.carbonAmountMax.toString().trim());
            }
          }

          const nextPageResponse = await apiInstance.get(`AdminGetAllTransactions?${nextPageParams.toString()}`);
          result.hasNextPage = nextPageResponse.data.Transactions && nextPageResponse.data.Transactions.length > 0;
        } catch (error) {
          result.hasNextPage = false;
        }
      }

      TRANSACTIONS_CACHE.set(cacheKey, result);
      lastCacheUpdate = currentTime;

      return result;
    } catch (error) {
      console.error('Error fetching transactions:', error);
      throw error;
    }
  },

  clearCache() {
    TRANSACTIONS_CACHE.clear();
    lastCacheUpdate = 0;
  },

  async exportTransactions({ pageNumber = 1, pageSize = 1000, filters = null, customFilename = null }) {
    if (typeof window === 'undefined') {
      throw new Error('Not available on server side');
    }

    // Build query parameters
    const params = new URLSearchParams({
      PageNumber: pageNumber.toString(),
      PageSize: pageSize.toString(),
      ExportCSV: 'true'
    });

    // Add filter parameters if they exist and are not empty
    if (filters) {
      console.log("Processing export transaction filters:", filters);

      if (filters.projectName && filters.projectName.toString().trim()) {
        params.append('ProjectName', filters.projectName.toString().trim());
      }

      if (filters.paymentStatus && filters.paymentStatus.toString().trim() && filters.paymentStatus !== "all") {
        params.append('PaymentStatus', filters.paymentStatus.toString().trim());
      }

      if (filters.paymentMethod && filters.paymentMethod.toString().trim() && filters.paymentMethod !== "all") {
        params.append('PaymentMethod', filters.paymentMethod.toString().trim());
      }

      if (filters.transactionID && filters.transactionID.toString().trim()) {
        params.append('TransactionID', filters.transactionID.toString().trim());
      }

      if (filters.moyasarPaymentID && filters.moyasarPaymentID.toString().trim()) {
        params.append('MoyasarPaymentID', filters.moyasarPaymentID.toString().trim());
      }

      if (filters.buyerEmail && filters.buyerEmail.toString().trim()) {
        params.append('BuyerEmail', filters.buyerEmail.toString().trim());
      }

      if (filters.dateFrom && filters.dateFrom.toString().trim()) {
        params.append('DateFrom', filters.dateFrom.toString().trim());
      }

      if (filters.dateTo && filters.dateTo.toString().trim()) {
        params.append('DateTo', filters.dateTo.toString().trim());
      }

      if (filters.carbonAmountMin && filters.carbonAmountMin.toString().trim()) {
        params.append('CarbonAmountMin', filters.carbonAmountMin.toString().trim());
      }

      if (filters.carbonAmountMax && filters.carbonAmountMax.toString().trim()) {
        params.append('CarbonAmountMax', filters.carbonAmountMax.toString().trim());
      }
    }

    try {
      const queryString = params.toString();
      console.log(`Exporting transactions with query: ${queryString}`);

      // Get the response with CSV URL
      const response = await apiInstance.get(`AdminGetAllTransactions?${queryString}`);

      // Open the CSV URL directly from API response
      if (response.data.CSVFileURL) {
        window.open(response.data.CSVFileURL, '_blank');
        return { success: true, message: 'Transactions exported successfully' };
      } else {
        throw new Error('CSV URL not found in response');
      }
    } catch (error) {
      console.error('Error exporting transactions:', error);
      throw error;
    }
  }
};