import { apiInstance } from "./apiInstance";

const OWNERS_CACHE = new Map();
let lastCacheUpdate = 0;
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

export const ownersService = {
  async getOwners({ pageNumber = 1, pageSize = 20, filters = null }) {
    if (typeof window === 'undefined') {
      return {
        success: false,
        owners: [],
        totalCount: 0,
        currentPage: pageNumber,
        pageSize: pageSize,
        hasNextPage: false
      };
    }

    // Build query parameters
    const params = new URLSearchParams({
      PageNumber: pageNumber.toString(),
      PageSize: pageSize.toString()
    });

    // Add filter parameters if they exist and are not empty
    if (filters) {
      console.log("Processing owner filters:", filters);
      if (filters.userEmail && filters.userEmail.toString().trim()) {
        params.append('UserEmail', filters.userEmail.toString().trim());
        console.log("Added UserEmail:", filters.userEmail.toString().trim());
      }
    }

    const queryString = params.toString();
    const cacheKey = `owners_${queryString}`;
    const currentTime = Date.now();

    // For filtered requests, skip cache to ensure fresh data
    const useCache = !filters && OWNERS_CACHE.has(cacheKey) && (currentTime - lastCacheUpdate) < CACHE_DURATION;
    if (useCache) {
      return OWNERS_CACHE.get(cacheKey);
    }

    try {
      console.log(`Fetching owners with filters:`, filters);
      console.log(`Full query string: ${queryString}`);
      console.log(`Complete API URL: GetAllAdminAndProjectOwners?${queryString}`);

      const response = await apiInstance.get(`GetAllAdminAndProjectOwners?${queryString}`);
      console.log('Owners API Response:', response.data);
      console.log('Response status:', response.status);

      const result = {
        success: response.data.Success,
        owners: response.data.ProjectOwners || response.data.Users || [],
        totalCount: response.data.TotalCount || 0,
        currentPage: pageNumber,
        pageSize: pageSize,
        hasNextPage: false
      };

      // Check for next page if we got full page size
      if (result.owners.length === pageSize) {
        try {
          const nextPageParams = new URLSearchParams({
            PageNumber: (pageNumber + 1).toString(),
            PageSize: pageSize.toString()
          });

          // Add same filter parameters for next page check
          if (filters && filters.userEmail && filters.userEmail.toString().trim()) {
            nextPageParams.append('UserEmail', filters.userEmail.toString().trim());
          }

          const nextPageResponse = await apiInstance.get(`GetAllAdminAndProjectOwners?${nextPageParams.toString()}`);
          result.hasNextPage = nextPageResponse.data.ProjectOwners && nextPageResponse.data.ProjectOwners.length > 0;
        } catch (error) {
          result.hasNextPage = false;
        }
      }

      OWNERS_CACHE.set(cacheKey, result);
      lastCacheUpdate = currentTime;

      return result;
    } catch (error) {
      console.error('Error fetching owners:', error);
      throw error;
    }
  },

  clearCache() {
    OWNERS_CACHE.clear();
    lastCacheUpdate = 0;
  },

  async exportOwners({ pageNumber = 1, pageSize = 1000, filters = null }) {
    if (typeof window === 'undefined') {
      throw new Error('Not available on server side');
    }

    // Build query parameters
    const params = new URLSearchParams({
      PageNumber: pageNumber.toString(),
      PageSize: pageSize.toString(),
      ExportCSV: 'true'
    });

    // Add filter parameters if they exist and are not empty
    if (filters) {
      console.log("Processing export owner filters:", filters);
      if (filters.userEmail && filters.userEmail.toString().trim()) {
        params.append('UserEmail', filters.userEmail.toString().trim());
      }
    }

    try {
      const queryString = params.toString();
      console.log(`Exporting owners with query: ${queryString}`);

      // Get the response with CSV URL
      const response = await apiInstance.get(`GetAllAdminAndProjectOwners?${queryString}`);

      // Open the CSV URL directly from API response
      if (response.data.CSVFileURL) {
        window.open(response.data.CSVFileURL, '_blank');
        return { success: true, message: 'Owners exported successfully' };
      } else {
        throw new Error('CSV URL not found in response');
      }
    } catch (error) {
      console.error('Error exporting owners:', error);
      throw error;
    }
  }
};