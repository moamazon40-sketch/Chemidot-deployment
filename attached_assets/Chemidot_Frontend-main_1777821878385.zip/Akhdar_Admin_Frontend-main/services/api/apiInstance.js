import axios from "axios";
import { baseURL } from "./apiConfig";

export const publicAxiosInstance = axios.create({
  baseURL,
});

export const privateAxiosInstance = axios.create({
  baseURL,
});

// Export the default instance for general use
export const apiInstance = privateAxiosInstance;

privateAxiosInstance.interceptors.request.use(
  (config) => {
    if (typeof window === 'undefined') return config;

    const userDataString =
      localStorage.getItem("User") || sessionStorage.getItem("User");
    if (userDataString) {
      try {
        const userData = JSON.parse(userDataString);
        // Handle both old format (direct token string) and new format (object with token property)
        const token = typeof userData === "string" ? userData : userData.token;

        if (token) {
          try {
            // Clean the token by removing quotes if they exist and trim whitespace
            const cleanToken = String(token).replace(/"/g, "").trim();
            if (cleanToken) {
              config.headers.authorization = `Bearer ${cleanToken}`;
            }
          } catch (error) {
            console.error("Error processing auth token:", error);
            // Clear invalid token
            if (typeof window !== 'undefined') {
              localStorage.removeItem("User");
              sessionStorage.removeItem("User");
            }
          }
        }
      } catch (error) {
        console.error("Error parsing user data from storage:", error);
        // Clear invalid data
        if (typeof window !== 'undefined') {
          localStorage.removeItem("User");
          sessionStorage.removeItem("User");
        }
      }
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Add response interceptor to handle auth errors
privateAxiosInstance.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Skip auth clearing for password change endpoints
      const url = error.config?.url || '';
      if (url.includes('/AdminChangePassword') || url.includes('ChangePassword')) {
        console.log('401 error on password change endpoint - not clearing auth');
        return Promise.reject(error);
      }

      // Token is invalid or expired, clear storage
      if (typeof window !== 'undefined') {
        console.log('401 error - clearing auth and redirecting to login');
        localStorage.removeItem("User");
        sessionStorage.removeItem("User");
        // Redirect to login page
        window.location.href = "/";
      }
    }
    return Promise.reject(error);
  }
);