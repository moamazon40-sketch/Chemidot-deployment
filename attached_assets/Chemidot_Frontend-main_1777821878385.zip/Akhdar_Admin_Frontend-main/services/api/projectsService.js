import { apiInstance } from "./apiInstance";

const PROJECTS_CACHE = new Map();
let lastCacheUpdate = 0;
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

export const projectsService = {
  async getProjects({ pageNumber, pageSize = 10, filters = null }) {
    if (typeof window === 'undefined') {
      return {
        success: false,
        projects: [],
        totalCount: 0,
        currentPage: pageNumber,
        pageSize: pageSize,
        hasNextPage: false
      };
    }

    // Build query parameters
    const params = new URLSearchParams({
      PageNumber: pageNumber.toString(),
      PageSize: pageSize.toString()
    });

    // Add filter parameters if they exist and are not empty/default values
    if (filters) {
      console.log("Processing filters:", filters);
      if (filters.projectName && filters.projectName.toString().trim()) {
        params.append('ProjectName', filters.projectName.toString().trim());
        console.log("Added ProjectName:", filters.projectName.toString().trim());
      }
      if (filters.projectOwnerEmail && filters.projectOwnerEmail.toString().trim()) {
        params.append('ProjectOwnerEmail', filters.projectOwnerEmail.toString().trim());
        console.log("Added ProjectOwnerEmail:", filters.projectOwnerEmail.toString().trim());
      }
      if (filters.country && filters.country !== 'all' && filters.country.toString().trim()) {
        params.append('Country', filters.country.toString().trim());
        console.log("Added Country:", filters.country.toString().trim());
      }
      if (filters.vintageYear && filters.vintageYear.toString().trim()) {
        params.append('VintageYear', filters.vintageYear.toString().trim());
        console.log("Added VintageYear:", filters.vintageYear.toString().trim());
      }
    }

    const queryString = params.toString();
    const cacheKey = `projects_${queryString}`;
    const currentTime = Date.now();

    // For filtered requests, skip cache to ensure fresh data
    const useCache = !filters && PROJECTS_CACHE.has(cacheKey) && (currentTime - lastCacheUpdate) < CACHE_DURATION;
    if (useCache) {
      return PROJECTS_CACHE.get(cacheKey);
    }

    try {
      console.log(`Fetching projects with filters:`, filters);
      console.log(`Full query string: ${queryString}`);
      console.log(`Complete API URL: AdminGetAllProjects?${queryString}`);

      // Log the actual request that will be made
      console.log('Making API request to:', `AdminGetAllProjects?${queryString}`);

      const response = await apiInstance.get(`AdminGetAllProjects?${queryString}`);
      console.log('API Response:', response.data);
      console.log('Response status:', response.status);

      const result = {
        success: response.data.Success,
        projects: response.data.Projects || [],
        totalCount: response.data.AllProjectsCount || 0,
        currentPage: pageNumber,
        pageSize: pageSize,
        hasNextPage: false
      };

      if (result.projects.length === pageSize) {
        try {
          const nextPageParams = new URLSearchParams({
            PageNumber: (pageNumber + 1).toString(),
            PageSize: pageSize.toString()
          });

          // Add same filter parameters for next page check
          if (filters) {
            if (filters.projectName && filters.projectName.trim()) {
              nextPageParams.append('ProjectName', filters.projectName.trim());
            }
            if (filters.projectOwnerEmail && filters.projectOwnerEmail.trim()) {
              nextPageParams.append('ProjectOwnerEmail', filters.projectOwnerEmail.trim());
            }
            if (filters.country && filters.country !== 'all' && filters.country.trim()) {
              nextPageParams.append('Country', filters.country.trim());
            }
            if (filters.vintageYear && filters.vintageYear.trim()) {
              nextPageParams.append('VintageYear', filters.vintageYear.trim());
            }
          }

          const nextPageResponse = await apiInstance.get(`AdminGetAllProjects?${nextPageParams.toString()}`);
          result.hasNextPage = nextPageResponse.data.Projects && nextPageResponse.data.Projects.length > 0;
        } catch (error) {
          result.hasNextPage = false;
        }
      }

      PROJECTS_CACHE.set(cacheKey, result);
      lastCacheUpdate = currentTime;

      return result;
    } catch (error) {
      console.error('Error fetching projects:', error);
      throw error;
    }
  },

  clearCache() {
    PROJECTS_CACHE.clear();
    lastCacheUpdate = 0;
  },

  getCachedProjects() {
    const cachedData = [];
    for (const [key, value] of PROJECTS_CACHE.entries()) {
      if (value.projects) {
        cachedData.push(...value.projects);
      }
    }
    return cachedData;
  },

  async approveProject(projectId, pricingData = null) {
    if (typeof window === 'undefined') {
      throw new Error('Not available on server side');
    }

    try {
      let requestBody = {};

      if (pricingData) {
        if (pricingData.vintages && pricingData.vintages.length > 0) {
          // Send vintage-specific pricing
          requestBody.Vintages = pricingData.vintages.map(vintage => ({
            Year: vintage.year,
            CarbonPricePerTon: parseFloat(vintage.price)
          }));
        } else if (pricingData.defaultPrice) {
          // Send default pricing
          requestBody.DefaultCarbonPricePerTon = parseFloat(pricingData.defaultPrice);
        }
      }

      console.log('Sending approval request with pricing data:', requestBody);

      const response = await apiInstance.post(`AdminApproveProject?ProjectID=${projectId}`, requestBody);
      this.clearCache(); // Clear cache to refresh data
      return {
        success: response.data.Success,
        message: response.data.message || 'Project approved successfully'
      };
    } catch (error) {
      console.error('Error approving project:', error);
      throw error;
    }
  },

  async rejectProject(projectId) {
    if (typeof window === 'undefined') {
      throw new Error('Not available on server side');
    }

    try {
      const response = await apiInstance.post(`AdminRejectProject?ProjectID=${projectId}`);
      this.clearCache(); // Clear cache to refresh data
      return {
        success: response.data.Success,
        message: response.data.message || 'Project rejected successfully'
      };
    } catch (error) {
      console.error('Error rejecting project:', error);
      throw error;
    }
  },

  async suspendProject(projectId) {
    if (typeof window === 'undefined') {
      throw new Error('Not available on server side');
    }

    try {
      const response = await apiInstance.post(`AdminSuspendProject?ProjectID=${projectId}`);
      this.clearCache(); // Clear cache to refresh data
      return {
        success: response.data.Success,
        message: response.data.message || 'Project suspended successfully'
      };
    } catch (error) {
      console.error('Error suspending project:', error);
      throw error;
    }
  },

  async reactivateProject(projectId) {
    if (typeof window === 'undefined') {
      throw new Error('Not available on server side');
    }

    try {
      const response = await apiInstance.post(`AdminReactivateProject?ProjectID=${projectId}`);
      this.clearCache(); // Clear cache to refresh data
      return {
        success: response.data.Success,
        message: response.data.message || 'Project reactivated successfully'
      };
    } catch (error) {
      console.error('Error reactivating project:', error);
      throw error;
    }
  },

  async deleteProject(projectId) {
    if (typeof window === 'undefined') {
      throw new Error('Not available on server side');
    }

    try {
      const response = await apiInstance.post(`AdminDeleteProject?ProjectID=${projectId}`);
      this.clearCache(); // Clear cache to refresh data
      return {
        success: response.data.Success,
        message: response.data.message || 'Project deleted successfully'
      };
    } catch (error) {
      console.error('Error deleting project:', error);
      throw error;
    }
  },

  async updateProject(projectId, updateData) {
    if (typeof window === 'undefined') {
      throw new Error('Not available on server side');
    }

    try {
      console.log('Updating project with ID:', projectId, 'Data:', updateData);
      const response = await apiInstance.post(`AdminEditProject?ProjectID=${projectId}`, updateData);
      this.clearCache(); // Clear cache to refresh data
      return {
        success: response.data.Success || response.status === 200,
        message: response.data.message || 'Project updated successfully',
        data: response.data
      };
    } catch (error) {
      console.error('Error updating project:', error);
      throw error;
    }
  },

  async updateProjectJSON(projectId, updateData) {
    if (typeof window === 'undefined') {
      throw new Error('Not available on server side');
    }

    try {
      console.log('Updating project with JSON data - ID:', projectId, 'Data:', updateData);

      // Ensure we're sending JSON content-type
      const response = await apiInstance.post(`AdminEditProject?ProjectID=${projectId}`, updateData, {
        headers: {
          'Content-Type': 'application/json'
        }
      });

      this.clearCache(); // Clear cache to refresh data
      return {
        success: response.data.Success || response.status === 200,
        message: response.data.Message || response.data.message || 'Project updated successfully',
        data: response.data.Project || response.data
      };
    } catch (error) {
      console.error('Error updating project with JSON:', error);
      throw error;
    }
  },

  async getProjectById(projectId) {
    if (typeof window === 'undefined') {
      throw new Error('Not available on server side');
    }

    try {
      console.log('GetProjectByID called with projectId:', projectId);
      const response = await apiInstance.get(`GetProjectByID?ProjectID=${projectId}`);
      console.log('GetProjectByID response:', response);
      return response;
    } catch (error) {
      console.error("Error fetching project by ID:", error);
      throw error;
    }
  },

  async exportProjects({ pageNumber = 1, pageSize = 20, filters = null }) {
    if (typeof window === 'undefined') {
      throw new Error('Not available on server side');
    }

    // Build query parameters
    const params = new URLSearchParams({
      PageNumber: pageNumber.toString(),
      PageSize: pageSize.toString(),
      ExportCSV: 'true'
    });

    // Add filter parameters if they exist and are not empty/default values
    if (filters) {
      console.log("Processing export filters:", filters);
      if (filters.projectName && filters.projectName.toString().trim()) {
        params.append('ProjectName', filters.projectName.toString().trim());
      }
      if (filters.projectOwnerEmail && filters.projectOwnerEmail.toString().trim()) {
        params.append('ProjectOwnerEmail', filters.projectOwnerEmail.toString().trim());
      }
      if (filters.country && filters.country !== 'all' && filters.country.toString().trim()) {
        params.append('Country', filters.country.toString().trim());
      }
      if (filters.vintageYear && filters.vintageYear.toString().trim()) {
        params.append('VintageYear', filters.vintageYear.toString().trim());
      }
    }

    try {
      const queryString = params.toString();
      console.log(`Exporting projects with query: ${queryString}`);

      // Get the response with CSV URL
      const response = await apiInstance.get(`AdminGetAllProjects?${queryString}`);

      // Open the CSV URL directly from API response
      if (response.data.CSVFileURL) {
        window.open(response.data.CSVFileURL, '_blank');
        return { success: true, message: 'Projects exported successfully' };
      } else {
        throw new Error('CSV URL not found in response');
      }
    } catch (error) {
      console.error('Error exporting projects:', error);
      throw error;
    }
  }
};