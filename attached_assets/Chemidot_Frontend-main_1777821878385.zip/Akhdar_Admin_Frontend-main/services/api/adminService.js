import { apiInstance } from "./apiInstance";

export const adminService = {
  async createAdmin(adminData) {
    if (typeof window === 'undefined') {
      throw new Error('Not available on server side');
    }

    try {
      console.log('Creating admin with data:', adminData);
      const response = await apiInstance.post('CreateAdmin', adminData);
      console.log('CreateAdmin response:', response);

      return {
        success: response.data.success,
        message: response.data.message || 'Admin user created successfully',
        user: response.data.user,
        temporaryPassword: response.data.temporaryPassword,
        passwordExpiresAt: response.data.passwordExpiresAt,
        note: response.data.note,
        emailSent: response.data.emailSent
      };
    } catch (error) {
      console.error('Error creating admin:', error);
      throw error;
    }
  }
};