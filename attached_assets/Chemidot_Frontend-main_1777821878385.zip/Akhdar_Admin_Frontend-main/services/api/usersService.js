import { apiInstance } from "./apiInstance";

const USERS_CACHE = new Map();
let lastCacheUpdate = 0;
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

export const usersService = {
  async getUsers({ pageNumber = 1, pageSize = 10, filters = null }) {
    if (typeof window === 'undefined') {
      return {
        success: false,
        users: [],
        totalCount: 0,
        currentPage: pageNumber,
        pageSize: pageSize,
        hasNextPage: false
      };
    }

    // Build query parameters
    const params = new URLSearchParams({
      PageNumber: pageNumber.toString(),
      PageSize: pageSize.toString()
    });

    // Add filter parameters if they exist and are not empty
    if (filters) {
      console.log("Processing user filters:", filters);
      if (filters.userEmail && filters.userEmail.toString().trim()) {
        params.append('UserEmail', filters.userEmail.toString().trim());
        console.log("Added UserEmail:", filters.userEmail.toString().trim());
      }
    }

    const queryString = params.toString();
    const cacheKey = `users_${queryString}`;
    const currentTime = Date.now();

    // For filtered requests, skip cache to ensure fresh data
    const useCache = !filters && USERS_CACHE.has(cacheKey) && (currentTime - lastCacheUpdate) < CACHE_DURATION;
    if (useCache) {
      return USERS_CACHE.get(cacheKey);
    }

    try {
      console.log(`Fetching users with filters:`, filters);
      console.log(`Full query string: ${queryString}`);
      console.log(`Complete API URL: GetAllAdminAndProjectOwners?${queryString}`);

      const response = await apiInstance.get(`GetAllAdminAndProjectOwners?${queryString}`);
      console.log('Users API Response:', response.data);
      console.log('Response status:', response.status);

      // Debug: Log the specific count fields from API response
      console.log('API TotalUsersCount:', response.data.TotalUsersCount);
      console.log('API AllUsersCount:', response.data.AllUsersCount);
      console.log('API Total Response Fields:', Object.keys(response.data));
      console.log('Users array length:', response.data.Users?.length || 0);

      const result = {
        success: response.data.success,
        users: response.data.Users || [],
        totalCount: response.data.TotalUsersCount || response.data.AllUsersCount || 0,
        filteredCount: response.data.FilteredCount || response.data.totalCount || response.data.TotalUsersCount || response.data.AllUsersCount || 0,
        currentPage: pageNumber,
        pageSize: pageSize,
        hasNextPage: false
      };

      // Debug: Show what we're using as totalCount
      console.log('Final totalCount being returned:', result.totalCount);
      console.log('Filters applied:', !!filters);

      // Check for next page if we got full page size
      if (result.users.length === pageSize) {
        try {
          const nextPageParams = new URLSearchParams({
            PageNumber: (pageNumber + 1).toString(),
            PageSize: pageSize.toString()
          });

          // Add same filter parameters for next page check
          if (filters && filters.userEmail && filters.userEmail.toString().trim()) {
            nextPageParams.append('UserEmail', filters.userEmail.toString().trim());
          }

          const nextPageResponse = await apiInstance.get(`GetAllAdminAndProjectOwners?${nextPageParams.toString()}`);
          result.hasNextPage = nextPageResponse.data.Users && nextPageResponse.data.Users.length > 0;
        } catch (error) {
          result.hasNextPage = false;
        }
      }

      USERS_CACHE.set(cacheKey, result);
      lastCacheUpdate = currentTime;

      // Debug: Log the final result being returned
      console.log('Users service returning totalCount:', result.totalCount);
      console.log('Users service returning users count:', result.users.length);

      return result;
    } catch (error) {
      console.error('Error fetching users:', error);
      throw error;
    }
  },

  clearCache() {
    USERS_CACHE.clear();
    lastCacheUpdate = 0;
  },

  async exportUsers({ pageNumber = 1, pageSize = 1000, filters = null }) {
    if (typeof window === 'undefined') {
      throw new Error('Not available on server side');
    }

    // Build query parameters
    const params = new URLSearchParams({
      PageNumber: pageNumber.toString(),
      PageSize: pageSize.toString(),
      ExportCSV: 'true'
    });

    // Add filter parameters if they exist and are not empty
    if (filters) {
      console.log("Processing export user filters:", filters);
      if (filters.userEmail && filters.userEmail.toString().trim()) {
        params.append('UserEmail', filters.userEmail.toString().trim());
      }
    }

    try {
      const queryString = params.toString();
      console.log(`Exporting users with query: ${queryString}`);

      // Get the response with CSV URL
      const response = await apiInstance.get(`GetAllAdminAndProjectOwners?${queryString}`);

      // Open the CSV URL directly from API response
      if (response.data.CSVFileURL) {
        window.open(response.data.CSVFileURL, '_blank');
        return { success: true, message: 'Users exported successfully' };
      } else {
        throw new Error('CSV URL not found in response');
      }
    } catch (error) {
      console.error('Error exporting users:', error);
      throw error;
    }
  },

  async deleteUser(userId) {
    if (typeof window === 'undefined') {
      throw new Error('Not available on server side');
    }

    try {
      console.log(`Deleting user with ID: ${userId}`);
      const response = await apiInstance.delete(`AdminDeleteUser?UserID=${userId}`);

      // Clear cache after successful deletion
      this.clearCache();

      return {
        success: response.data.success || response.status === 200,
        message: response.data.message || 'User deleted successfully'
      };
    } catch (error) {
      console.error('Error deleting user:', error);
      throw error;
    }
  },

  async suspendUser(userId) {
    if (typeof window === 'undefined') {
      throw new Error('Not available on server side');
    }

    try {
      console.log(`Suspending user with ID: ${userId}`);
      const response = await apiInstance.post(`AdminSuspendUser?UserID=${userId}`, {});

      // Clear cache after successful suspension
      this.clearCache();

      return {
        success: response.data.success || response.status === 200,
        message: response.data.message || 'User suspended successfully',
        user: response.data.user
      };
    } catch (error) {
      console.error('Error suspending user:', error);
      throw error;
    }
  },

  async reactivateUser(userId) {
    if (typeof window === 'undefined') {
      throw new Error('Not available on server side');
    }

    try {
      console.log(`Reactivating user with ID: ${userId}`);
      const response = await apiInstance.post(`AdminReactivateUser?UserID=${userId}`, {});

      // Clear cache after successful reactivation
      this.clearCache();

      return {
        success: response.data.success || response.status === 200,
        message: response.data.message || 'User reactivated successfully',
        user: response.data.user
      };
    } catch (error) {
      console.error('Error reactivating user:', error);
      throw error;
    }
  },

  async getTotalUsersCount() {
    if (typeof window === 'undefined') {
      return {
        success: false,
        totalCount: 0
      };
    }

    try {
      console.log('Fetching total users count');

      // Use minimal page size to get count efficiently
      const params = new URLSearchParams({
        PageNumber: '1',
        PageSize: '1'
      });

      const response = await apiInstance.get(`GetAllAdminAndProjectOwners?${params.toString()}`);
      console.log('Total users count API Response:', response.data);

      return {
        success: response.data.success || true,
        totalCount: response.data.AllUsersCount || response.data.TotalUsersCount || 0,
        totalAdmins: response.data.TotalAdmins || 0,
        totalProjectOwners: response.data.TotalProjectOwners || 0
      };
    } catch (error) {
      console.error('Error fetching total users count:', error);
      return {
        success: false,
        totalCount: 0,
        error: error.message
      };
    }
  },

  // Utility function to get just the total count number
  async getTotalUsersCountOnly() {
    const result = await this.getTotalUsersCount();
    return result.totalCount || 0;
  }
};