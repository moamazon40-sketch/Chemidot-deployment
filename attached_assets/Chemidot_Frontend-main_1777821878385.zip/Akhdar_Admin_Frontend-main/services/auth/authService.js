import { AUTH_URLS, baseURL } from "../api/apiConfig";
import { publicAxiosInstance, apiInstance } from "../api/apiInstance";
import { toast } from "sonner";

export const AdminLogin = async (userData) => {
  try {
    const adminLoginUrl = AUTH_URLS.ADMIN_LOGIN;

    // Different field combinations to try
    const attemptConfigs = [
      { Email: userData.email, Password: userData.password },
      { email: userData.email, password: userData.password },
      { username: userData.email, password: userData.password },
      { Username: userData.email, Password: userData.password },
    ];

    let lastError = null;

    for (let i = 0; i < attemptConfigs.length; i++) {
      try {
        const requestData = attemptConfigs[i];

        console.log(`AdminLogin attempt ${i + 1} with fields:`, Object.keys(requestData));

        const response = await publicAxiosInstance.post(adminLoginUrl, requestData);

        console.log("AdminLogin successful");
        return response;
      } catch (error) {
        console.log(`Attempt ${i + 1} failed:`, error.response?.data);
        lastError = error;

        // If it's not a field-related error, don't try other combinations
        if (error.response?.status !== 400 ||
            !error.response?.data?.toString().includes("Required")) {
          break;
        }
      }
    }

    // If all attempts failed, throw the last error
    throw lastError;
  } catch (error) {
    console.error("Admin login error:", error);
    console.error("Error response:", error.response?.data);
    console.error("Error status:", error.response?.status);

    if (error.response) {
      const responseData = error.response.data;
      let errorMessage = "Login failed. Please try again.";

      // Handle different error response formats
      if (typeof responseData === 'string') {
        errorMessage = responseData;
      } else if (responseData?.message) {
        errorMessage = responseData.message;
      } else if (responseData?.error) {
        errorMessage = responseData.error;
      } else if (responseData?.Message) {
        errorMessage = responseData.Message;
      } else if (responseData?.Error) {
        errorMessage = responseData.Error;
      }

      // Make error messages more user-friendly
      if (errorMessage.includes("Required")) {
        errorMessage = "The email or password you entered is incorrect. Please try again.";
      } else if (errorMessage.includes("Invalid") || errorMessage.includes("Unauthorized")) {
        errorMessage = "The email or password you entered is incorrect. Please try again.";
      } else if (error.response.status === 400) {
        errorMessage = "The email or password you entered is incorrect. Please try again.";
      } else if (error.response.status === 401) {
        errorMessage = "The email or password you entered is incorrect. Please try again.";
      } else if (error.response.status === 403) {
        errorMessage = "Access denied. Please contact your administrator.";
      } else if (error.response.status === 404) {
        errorMessage = "The email or password you entered is incorrect. Please try again.";
      } else if (error.response.status === 500) {
        errorMessage = "We're experiencing technical difficulties. Please try again in a few minutes.";
      } else {
        errorMessage = "The email or password you entered is incorrect. Please try again.";
      }

      toast.error(errorMessage);
      throw new Error(errorMessage);
    } else if (error.request) {
      const networkError = "Network error - please check your internet connection";
      toast.error(networkError);
      throw new Error(networkError);
    } else {
      const generalError = "An unexpected error occurred. Please try again.";
      toast.error(generalError);
      throw new Error(generalError);
    }
  }
};

export const UserLogin = async (userData) => {
  try {
    const userLoginUrl = AUTH_URLS.USER_LOGIN;

    const response = await publicAxiosInstance.post(userLoginUrl, userData);

    return response;
  } catch (error) {
    console.error("User login error:", error);

    if (error.response) {
      const errorMessage =
        error.response.data?.message ||
        error.response.data?.error ||
        "Invalid credentials. Please try again.";

      toast.error(errorMessage);
      throw new Error(errorMessage);
    } else if (error.request) {
      const networkError = "Network error - please check your connection";
      toast.error(networkError);
      throw new Error(networkError);
    } else {
      toast.error(error.message);
      throw error;
    }
  }
};

export const AdminForgetPassword = async (email) => {
  try {
    const forgetPasswordUrl = `${baseURL}/AdminForgetPassword?Email=${encodeURIComponent(email)}`;

    const response = await publicAxiosInstance.post(forgetPasswordUrl);

    return response;
  } catch (error) {
    console.error("Admin forget password error:", error);

    if (error.response) {
      const errorMessage =
        error.response.data?.message ||
        error.response.data?.error ||
        "Failed to send password reset email. Please try again.";

      toast.error(errorMessage);
      throw new Error(errorMessage);
    } else if (error.request) {
      const networkError = "Network error - please check your connection";
      toast.error(networkError);
      throw new Error(networkError);
    } else {
      toast.error(error.message);
      throw error;
    }
  }
};

export const AdminResetPassword = async (resetData) => {
  try {
    const resetPasswordUrl = `${baseURL}/AdminResetPassword`;

    const response = await publicAxiosInstance.post(resetPasswordUrl, {
      resetToken: resetData.resetToken,
      newPassword: resetData.newPassword,
    });

    return response;
  } catch (error) {
    console.error("Admin reset password error:", error);

    if (error.response) {
      const errorMessage =
        error.response.data?.message ||
        error.response.data?.error ||
        "Failed to reset password. Please try again.";

      toast.error(errorMessage);
      throw new Error(errorMessage);
    } else if (error.request) {
      const networkError = "Network error - please check your connection";
      toast.error(networkError);
      throw new Error(networkError);
    } else {
      toast.error(error.message);
      throw error;
    }
  }
};

export const AdminGetCurrentUserProfile = async () => {
  try {
    const getCurrentUserProfileUrl = `${baseURL}/AdminGetCurrentUserProfile`;

    const response = await apiInstance.get(getCurrentUserProfileUrl);

    return response;
  } catch (error) {
    console.error("Get current user profile error:", error);

    if (error.response) {
      const errorMessage =
        error.response.data?.message ||
        error.response.data?.error ||
        "Failed to fetch user profile. Please try again.";

      toast.error(errorMessage);
      throw new Error(errorMessage);
    } else if (error.request) {
      const networkError = "Network error - please check your connection";
      toast.error(networkError);
      throw new Error(networkError);
    } else {
      toast.error(error.message);
      throw error;
    }
  }
};

export const AdminChangePassword = async (passwordData) => {
  try {
    const changePasswordUrl = `${baseURL}/AdminChangePassword`;

    const response = await apiInstance.post(changePasswordUrl, {
      CurrentPassword: passwordData.currentPassword,
      NewPassword: passwordData.newPassword,
    });

    return response;
  } catch (error) {
    console.error("Change password error:", error);

    if (error.response) {
      const errorMessage =
        error.response.data?.message ||
        error.response.data?.error ||
        "Failed to change password. Please try again.";

      toast.error(errorMessage);
      throw new Error(errorMessage);
    } else if (error.request) {
      const networkError = "Network error - please check your connection";
      toast.error(networkError);
      throw new Error(networkError);
    } else {
      toast.error(error.message);
      throw error;
    }
  }
};

export const AdminRequestEmailChange = async (newEmail) => {
  try {
    const requestEmailChangeUrl = `${baseURL}/AdminRequestEmailChange`;

    const response = await apiInstance.post(requestEmailChangeUrl, {
      NewEmail: newEmail,
    });

    return response;
  } catch (error) {
    console.error("Request email change error:", error);

    if (error.response) {
      const errorMessage =
        error.response.data?.message ||
        error.response.data?.error ||
        "Failed to send OTP to new email. Please try again.";

      toast.error(errorMessage);
      throw new Error(errorMessage);
    } else if (error.request) {
      const networkError = "Network error - please check your connection";
      toast.error(networkError);
      throw new Error(networkError);
    } else {
      toast.error(error.message);
      throw error;
    }
  }
};

export const AdminVerifyOTPAndChangeEmail = async (otp) => {
  try {
    const verifyOTPUrl = `${baseURL}/AdminVerifyOTPAndChangeEmail`;

    const response = await apiInstance.post(verifyOTPUrl, {
      OTP: otp,
    });

    return response;
  } catch (error) {
    console.error("Verify OTP and change email error:", error);

    if (error.response) {
      const errorMessage =
        error.response.data?.message ||
        error.response.data?.error ||
        "Failed to verify OTP. Please try again.";

      toast.error(errorMessage);
      throw new Error(errorMessage);
    } else if (error.request) {
      const networkError = "Network error - please check your connection";
      toast.error(networkError);
      throw new Error(networkError);
    } else {
      toast.error(error.message);
      throw error;
    }
  }
};