import { ArrowRight, Search, ShieldCheck, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";

const Hero = () => {
  return (
    <section className="relative overflow-hidden bg-hero pt-32 pb-24">
      {/* Subtle grid */}
      <div className="absolute inset-0 grid-pattern [mask-image:radial-gradient(ellipse_at_center,black,transparent_75%)]" />

      {/* Soft floating orange blobs */}
      <div className="pointer-events-none absolute -top-24 right-0 h-96 w-96 rounded-full bg-orange/20 blur-3xl" />
      <div className="pointer-events-none absolute bottom-0 -left-24 h-96 w-96 rounded-full bg-navy/10 blur-3xl" />

      <div className="container relative mx-auto px-6">
        <div className="mx-auto max-w-4xl text-center animate-fade-up">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-border bg-white/70 px-4 py-1.5 text-xs font-medium text-navy backdrop-blur">
            <Sparkles className="h-3.5 w-3.5 text-orange" />
            <span>Trusted by 1,200+ procurement teams worldwide</span>
          </div>

          <h1 className="font-display text-5xl font-semibold leading-[1.05] tracking-tight text-navy md:text-7xl">
            The global marketplace for{" "}
            <span className="text-gradient">industrial chemicals</span>
          </h1>

          <p className="mx-auto mt-6 max-w-2xl text-lg text-muted-foreground md:text-xl">
            Source verified suppliers, compare specs, and reduce procurement costs through
            collective ordering — all in one secure B2B platform.
          </p>

          {/* Search */}
          <div className="mx-auto mt-10 max-w-2xl">
            <div className="group relative flex items-center rounded-2xl border border-border bg-white p-2 shadow-elegant transition-smooth focus-within:border-orange/60 focus-within:shadow-glow">
              <Search className="ml-4 h-5 w-5 shrink-0 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search by chemical name, CAS number, or formula…"
                className="flex-1 bg-transparent px-4 py-3 text-base text-navy placeholder:text-muted-foreground/70 focus:outline-none"
              />
              <Button variant="hero" size="lg" className="shrink-0">
                Search
                <ArrowRight className="ml-1 h-4 w-4" />
              </Button>
            </div>
            <div className="mt-4 flex flex-wrap items-center justify-center gap-2 text-xs text-muted-foreground">
              <span>Popular:</span>
              {["Acetone", "Sodium Hydroxide", "Methanol", "CAS 64-17-5", "Citric Acid"].map((t) => (
                <button
                  key={t}
                  className="rounded-full border border-border bg-white px-3 py-1 transition-smooth hover:border-orange/60 hover:text-navy"
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          {/* Trust strip */}
          <div className="mt-12 flex flex-wrap items-center justify-center gap-x-8 gap-y-3 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-orange" />
              <span>REACH & GHS compliant</span>
            </div>
            <div className="h-1 w-1 rounded-full bg-border" />
            <div>ISO 9001 verified suppliers</div>
            <div className="h-1 w-1 rounded-full bg-border" />
            <div>Escrow-secured payments</div>
          </div>
        </div>

        {/* Stats bar */}
        <div className="mx-auto mt-20 grid max-w-4xl grid-cols-2 gap-px overflow-hidden rounded-2xl border border-border bg-border md:grid-cols-4 shadow-card-premium">
          {[
            { v: "48k+", l: "Listed compounds" },
            { v: "1,200", l: "Vetted suppliers" },
            { v: "92", l: "Countries" },
            { v: "$2.4B", l: "Traded annually" },
          ].map((s) => (
            <div key={s.l} className="bg-white p-6 text-center">
              <div className="font-display text-2xl font-semibold text-navy md:text-3xl">{s.v}</div>
              <div className="mt-1 text-xs uppercase tracking-wider text-muted-foreground">{s.l}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Hero;
