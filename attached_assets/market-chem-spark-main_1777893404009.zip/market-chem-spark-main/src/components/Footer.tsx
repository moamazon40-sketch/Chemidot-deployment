import Logo from "@/components/Logo";

const Footer = () => {
  return (
    <footer className="border-t border-border bg-white">
      <div className="container mx-auto px-6 py-12">
        <div className="flex flex-col items-start justify-between gap-6 md:flex-row md:items-center">
          <div className="flex items-center gap-2.5">
            <Logo className="h-8 w-8" />
            <span className="font-display text-base font-semibold text-navy">Molecule</span>
          </div>
          <div className="font-mono text-xs text-muted-foreground">
            © 2026 Molecule Trading Ltd. — Compounded with precision.
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
