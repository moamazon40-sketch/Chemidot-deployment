import logo from "@/assets/logo.svg";

const Logo = ({ className = "h-9 w-9" }: { className?: string }) => (
  <img src={logo} alt="Molecule logo" className={className} width={36} height={36} />
);

export default Logo;
