import { Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import Logo from "@/components/Logo";

const Navbar = () => {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 glass">
      <div className="container mx-auto flex h-16 items-center justify-between px-6">
        <a href="#" className="flex items-center gap-2.5">
          <Logo className="h-9 w-9" />
          <span className="font-display text-lg font-semibold tracking-tight text-navy">Molecule</span>
        </a>

        <nav className="hidden items-center gap-8 md:flex">
          <a href="#marketplace" className="text-sm text-muted-foreground transition-smooth hover:text-navy">Marketplace</a>
          <a href="#collective" className="text-sm text-muted-foreground transition-smooth hover:text-navy">Collective Orders</a>
          <a href="#suppliers" className="text-sm text-muted-foreground transition-smooth hover:text-navy">Suppliers</a>
          <a href="#compliance" className="text-sm text-muted-foreground transition-smooth hover:text-navy">Compliance</a>
        </nav>

        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" className="hidden md:inline-flex text-navy hover:bg-secondary">Sign in</Button>
          <Button variant="hero" size="sm">Request access</Button>
          <button className="md:hidden text-navy" aria-label="Open menu">
            <Menu className="h-5 w-5" />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Navbar;
