import { ArrowUpRight, Store, Users } from "lucide-react";
import { Button } from "@/components/ui/button";

const CtaSection = () => {
  return (
    <section className="relative py-24 bg-surface-soft">
      <div className="container mx-auto px-6">
        <div className="mb-14 max-w-2xl">
          <div className="mb-3 font-mono text-xs uppercase tracking-[0.2em] text-orange">// Two ways to buy</div>
          <h2 className="font-display text-4xl font-semibold tracking-tight text-navy md:text-5xl">
            Built for the way procurement actually works.
          </h2>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          {/* Marketplace */}
          <article id="marketplace" className="group relative overflow-hidden rounded-3xl border border-border bg-white p-10 shadow-card-premium transition-smooth hover:border-orange/40 hover:shadow-glow">
            <div className="absolute -right-20 -top-20 h-72 w-72 rounded-full bg-orange/10 blur-3xl transition-smooth group-hover:bg-orange/20" />
            <div className="relative">
              <div className="mb-6 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-primary shadow-glow">
                <Store className="h-6 w-6 text-white" />
              </div>
              <div className="mb-2 font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground">Marketplace</div>
              <h3 className="mb-4 font-display text-3xl font-semibold tracking-tight text-navy">
                Direct sourcing from verified suppliers.
              </h3>
              <p className="mb-8 text-muted-foreground">
                Browse 48,000+ compounds with full COA, MSDS, and traceability. Request quotes,
                compare offers side-by-side, and place orders with confidence.
              </p>

              <ul className="mb-10 space-y-3 text-sm">
                {["Real-time pricing from 1,200+ suppliers", "Full documentation & batch traceability", "Escrow protection on every order"].map((f) => (
                  <li key={f} className="flex items-start gap-3 text-muted-foreground">
                    <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-orange" />
                    {f}
                  </li>
                ))}
              </ul>

              <Button variant="hero" size="lg">
                Browse marketplace
                <ArrowUpRight className="ml-1 h-4 w-4" />
              </Button>
            </div>
          </article>

          {/* Collective Order */}
          <article id="collective" className="group relative overflow-hidden rounded-3xl border border-border bg-gradient-navy p-10 shadow-card-premium transition-smooth hover:shadow-glow">
            <div className="absolute -left-20 -bottom-20 h-72 w-72 rounded-full bg-orange/30 blur-3xl transition-smooth group-hover:bg-orange/40" />
            <div className="relative text-white">
              <div className="mb-6 inline-flex h-12 w-12 items-center justify-center rounded-xl border border-orange/40 bg-white/5">
                <Users className="h-6 w-6 text-orange" />
              </div>
              <div className="mb-2 flex items-center gap-2 font-mono text-xs uppercase tracking-[0.2em] text-white/60">
                <span>Collective Order</span>
                <span className="rounded-full bg-orange/20 px-2 py-0.5 text-[10px] text-orange">New</span>
              </div>
              <h3 className="mb-4 font-display text-3xl font-semibold tracking-tight">
                Pool demand. Unlock industrial pricing.
              </h3>
              <p className="mb-8 text-white/70">
                Join other buyers in shared procurement campaigns. Reach bulk thresholds together
                and access pricing usually reserved for major industrials — up to 38% lower.
              </p>

              {/* Active campaign card */}
              <div className="mb-10 rounded-2xl border border-white/10 bg-white/5 p-5 backdrop-blur">
                <div className="mb-3 flex items-center justify-between">
                  <div>
                    <div className="font-medium">Isopropyl Alcohol 99.9%</div>
                    <div className="font-mono text-xs text-white/50">CAS 67-63-0 · 14 buyers joined</div>
                  </div>
                  <div className="text-right">
                    <div className="font-display text-lg font-semibold text-orange">−27%</div>
                    <div className="text-[10px] uppercase tracking-wider text-white/50">vs. spot</div>
                  </div>
                </div>
                <div className="h-1.5 overflow-hidden rounded-full bg-white/10">
                  <div className="h-full w-[68%] rounded-full bg-gradient-primary" />
                </div>
                <div className="mt-2 flex justify-between text-xs text-white/50">
                  <span>17.2 / 25 tonnes</span>
                  <span>Closes in 4 days</span>
                </div>
              </div>

              <Button variant="hero" size="lg">
                Join a collective order
                <ArrowUpRight className="ml-1 h-4 w-4" />
              </Button>
            </div>
          </article>
        </div>
      </div>
    </section>
  );
};

export default CtaSection;
